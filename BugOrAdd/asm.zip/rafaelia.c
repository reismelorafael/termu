/*
 * RAFAELIA ARCHITECT KERNEL v4.0 - ATOMIC & ENTROPY
 * Solução para Checksum 0x0 + Sincronização de Memória
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>

#define GRID_DIM        256
#define STRIDE          (GRID_DIM / 8)
#define NUM_THREADS     8
#define BITRAF_MASK     0x5A5A5A5A5A5A5A5AULL

typedef struct {
    uint64_t bit_matrix[GRID_DIM][STRIDE] __attribute__((aligned(64)));
} BitRaf_Engine;

static BitRaf_Engine kernel_v;

typedef struct {
    int id;
    int start_row;
    int end_row;
    uint64_t thread_checksum;
} ThreadData;

/* Inicializador de Entropia (Semeando a Matriz) */
void seed_matrix() {
    uint64_t seed = 0xDEADC0DEBAADF00DULL;
    for (int r = 0; r < GRID_DIM; r++) {
        for (int i = 0; i < STRIDE; i++) {
            seed = (seed * 6364136223846793005ULL) + 1;
            kernel_v.bit_matrix[r][i] = seed ^ BITRAF_MASK;
        }
    }
}

static inline uint64_t get_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1e9 + ts.tv_nsec;
}

/* Worker v4.0 com barreira de memória implícita */
void* vectra_worker(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    data->thread_checksum = 0;
    
    for (int loop = 0; loop < 5000; loop++) {
        for (int r = data->start_row; r < data->end_row; r++) {
            for (int i = 0; i < STRIDE; i++) {
                // Operação de mutação complexa
                uint64_t d = kernel_v.bit_matrix[r][i];
                d = (d << 1) | (d >> 63); // Rotação
                d ^= (d * 0x2545F4914F6CDD1DULL);
                d = ~(d ^ BITRAF_MASK);
                
                kernel_v.bit_matrix[r][i] = d;
                data->thread_checksum ^= d;
            }
        }
        // Memory Barrier conceitual (compilador não reordena loops)
        __asm__ volatile("" : : : "memory");
    }
    return NULL;
}

void run_v4_suite() {
    printf("\033[1;33m[SYSTEM] Executando Rafaelia v4.0 - Integridade Atômica...\033[0m\n");
    
    seed_matrix(); // CRITICAL: Popula a matriz antes do teste

    pthread_t threads[NUM_THREADS];
    ThreadData t_data[NUM_THREADS];
    int rows_per_thread = GRID_DIM / NUM_THREADS;

    uint64_t start = get_ns();

    for (int i = 0; i < NUM_THREADS; i++) {
        t_data[i].id = i;
        t_data[i].start_row = i * rows_per_thread;
        t_data[i].end_row = (i + 1) * rows_per_thread;
        pthread_create(&threads[i], NULL, vectra_worker, &t_data[i]);
    }

    uint64_t final_checksum = 0;
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
        final_checksum ^= t_data[i].thread_checksum;
    }

    uint64_t end = get_ns();
    
    printf("\n\033[1;32m--- RELATÓRIO DE INTEGRIDADE v4.0 ---\033[0m\n");
    printf("Status: Matriz Semeada & Processada\n");
    printf("Tempo Total: %.2f ms\n", (double)(end - start) / 1e6);
    printf("BitRaf Global Checksum: 0x%llX\n", final_checksum);
    
    if (final_checksum == 0) 
        printf("\033[1;31mERRO: Checksum nulo. Falha lógica detectada.\033[0m\n");
    else 
        printf("\033[1;32mSUCESSO: Integridade validada com entropia.\033[0m\n");
    printf("\033[1;32m-------------------------------------\033[0m\n");
}

int main() {
    run_v4_suite();
    return 0;
}
