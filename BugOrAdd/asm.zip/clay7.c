#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// =======================
// 1. P vs NP (3-SAT)
// =======================
typedef struct { int a,b,c; } Clause;

int eval_clause(Clause cl, int a){
    int va=(a>>(abs(cl.a)-1))&1;
    int vb=(a>>(abs(cl.b)-1))&1;
    int vc=(a>>(abs(cl.c)-1))&1;
    if(cl.a<0) va=!va;
    if(cl.b<0) vb=!vb;
    if(cl.c<0) vc=!vc;
    return va||vb||vc;
}

int solve_sat(Clause *c,int n,int vars){
    for(int a=0;a<(1<<vars);a++){
        int ok=1;
        for(int i=0;i<n;i++)
            if(!eval_clause(c[i],a)) ok=0;
        if(ok) return 1;
    }
    return 0;
}

// =======================
// 2. Navier-Stokes (difusão)
// =======================
#define N 4
void navier(float *u){
    float t[N*N];
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            int idx=i*N+j;
            int up=((i-1+N)%N)*N+j;
            int down=((i+1)%N)*N+j;
            int left=i*N+(j-1+N)%N;
            int right=i*N+(j+1)%N;
            t[idx]=u[idx]+0.1f*(u[up]+u[down]+u[left]+u[right]-4*u[idx]);
        }
    }
    for(int i=0;i<N*N;i++) u[i]=t[i];
}

float energia(float *u){
    float e=0;
    for(int i=0;i<N*N;i++) e+=u[i]*u[i];
    return e;
}

// =======================
// 3. Yang-Mills (plaquette)
// =======================
float plaquette(float U[4]){
    return 1.0f-(U[0]*U[1]*U[2]*U[3]);
}

// =======================
// 4. Riemann (teste zeta simples)
// =======================
double zeta(double s){
    double sum=0;
    for(int n=1;n<1000;n++)
        sum+=1.0/pow(n,s);
    return sum;
}

// =======================
// 5. Birch–Swinnerton-Dyer (toy)
// =======================
double elliptic(double x){
    return x*x*x - x + 1;
}

// =======================
// 6. Hodge (toy consistência)
// =======================
int hodge_check(){
    return 1; // placeholder estrutural
}

// =======================
// 7. Yang-Mills Mass Gap (toy energia)
// =======================
float mass_gap(float e){
    return fabs(e-0.5f);
}

// =======================
// MAIN
// =======================
int main(){

    printf("=== P vs NP ===\n");
    Clause sat[]={{1,2,3},{-1,2,3}};
    Clause unsat[]={{1,1,1},{-1,-1,-1}};
    printf("SAT: %d\n",solve_sat(sat,2,3));
    printf("UNSAT: %d\n",solve_sat(unsat,2,1));

    printf("\n=== Navier-Stokes ===\n");
    float u[N*N]={0};
    u[5]=1.0f;
    for(int i=0;i<5;i++){
        navier(u);
        printf("t=%d energia=%f\n",i,energia(u));
    }

    printf("\n=== Yang-Mills ===\n");
    float U[4]={1,1,1,1};
    float V[4]={0.7,1,1,1};
    printf("flat: %f\n",plaquette(U));
    printf("curvo: %f\n",plaquette(V));

    printf("\n=== Riemann ===\n");
    printf("zeta(2) ~ %f\n",zeta(2.0));

    printf("\n=== BSD ===\n");
    printf("elliptic(2) = %f\n",elliptic(2));

    printf("\n=== Hodge ===\n");
    printf("check = %d\n",hodge_check());

    printf("\n=== Mass Gap ===\n");
    printf("gap = %f\n",mass_gap(0.3f));

    return 0;
}
