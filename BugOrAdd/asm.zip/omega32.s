.global _start
.section .bss
.align 4
T:       .skip 100000*4
Flow:    .skip 100000*4
Residual:.skip 100000*1
Counters:.skip 16

.section .text
_start:
    mov r0,#0                  @ índice base

init_loop:
    ldr r1,=T
    str r0,[r1,r0,LSL #2]      @ T[i] = i
    add r0,r0,#1
    cmp r0,#100000
    blt init_loop

    @ Benchmark proxy
    mov r2,#0
    mov r3,#0

avalanche_loop:
    ldr r4,=T
    ldr r5,[r4,r3,LSL #2]
    sub r5,r5,#1               @ decay simples
    str r5,[r4,r3,LSL #2]

    add r3,r3,#1
    cmp r3,#100000
    blt avalanche_loop

    ldr r6,=Counters
    str r3,[r6]

hang:
    b hang
