.syntax unified
.cpu cortex-a7
.fpu neon
.thumb

.global _start

.equ SYS_WRITE, 4
.equ SYS_EXIT, 1
.equ STDOUT, 1

.section .data
msg:
    .ascii "RAFAELOS ARMv7 ANDROID\\n"
len = . - msg

.section .bss
    .align 4
state:
    .space 28

.section .text

_start:

    @ write(STDOUT,msg,len)
    mov r0, #STDOUT
    ldr r1, =msg
    ldr r2, =len
    mov r7, #SYS_WRITE
    svc #0

    @ init state
    bl state_init

    mov r4, #0

loop_main:
    cmp r4, #42
    beq end

    mov r0, r4
    bl generate_input

    bl state_update

    bl calc_phi

    add r4, r4, #1
    b loop_main

end:
    mov r0, #0
    mov r7, #SYS_EXIT
    svc #0

@ ------------------------------------------------
@ state_init
@ r0-r3 temporários
@ ------------------------------------------------

state_init:

    ldr r0, =state

    mov r1, #1
    str r1, [r0]

    mov r1, #2
    str r1, [r0,#4]

    mov r1, #3
    str r1, [r0,#8]

    mov r1, #4
    str r1, [r0,#12]

    mov r1, #5
    str r1, [r0,#16]

    mov r1, #6
    str r1, [r0,#20]

    mov r1, #7
    str r1, [r0,#24]

    bx lr

@ ------------------------------------------------
@ generate_input
@ r0 = step
@ ------------------------------------------------

generate_input:

    push {r4-r7,lr}

    mov r4, r0

    @ xorshift32
    eor r4, r4, r4, lsl #13
    eor r4, r4, r4, lsr #17
    eor r4, r4, r4, lsl #5

    ldr r5, =state

    str r4, [r5]

    pop {r4-r7,lr}
    bx lr

@ ------------------------------------------------
@ state_update
@ ------------------------------------------------

state_update:

    push {r4-r8,lr}

    ldr r4, =state

    mov r5, #0

update_loop:

    cmp r5, #28
    beq update_end

    ldr r6, [r4,r5]

    add r6, r6, #3

    and r6, r6, #255

    str r6, [r4,r5]

    add r5, r5, #4

    b update_loop

update_end:

    pop {r4-r8,lr}
    bx lr

@ ------------------------------------------------
@ calc_phi
@ ------------------------------------------------

calc_phi:

    push {r4-r8,lr}

    ldr r4, =state

    mov r5, #0
    mov r6, #0

phi_loop:

    cmp r5, #28
    beq phi_done

    ldr r7, [r4,r5]

    add r6, r6, r7

    add r5, r5, #4

    b phi_loop

phi_done:

    pop {r4-r8,lr}
    bx lr

