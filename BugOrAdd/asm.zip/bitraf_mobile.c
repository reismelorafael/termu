#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#ifdef __ARM_NEON
#include <arm_neon.h>
#define USE_NEON 1
#else
#define USE_NEON 0
#endif

// ================= CONFIG MOBILE SAFE =================
#define DIM 64
#define TOTAL (DIM * DIM * DIM)

// ================= TIMER =================
double now() {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

// ================= KERNEL SIMPLIFICADO =================
// Mantém tua ideia: coerência + transformação + estabilidade

static inline void kernel(float *data, int len) {
#if USE_NEON
    int i;
    float32x4_t c = vdupq_n_f32(0.6180339887f);

    for (i = 0; i + 4 <= len; i += 4) {
        float32x4_t v = vld1q_f32(data + i);
        v = vaddq_f32(v, vmulq_f32(v, c));
        vst1q_f32(data + i, v);
    }
#else
    for (int i = 0; i < len; i++) {
        data[i] += data[i] * 0.6180339887f;
    }
#endif
}

// ================= STREAM PROCESSOR =================
void process(float *buf) {
    for (int z = 0; z < DIM; z++) {
        for (int y = 0; y < DIM; y++) {

            int base = z * DIM * DIM + y * DIM;

            // prefetch leve (Android friendly)
            __builtin_prefetch(&buf[base + DIM], 0, 1);

            kernel(&buf[base], DIM);
        }
    }
}

int main() {
    printf("🚀 BitRaf Mobile v2 iniciando...\n");

    float *buf = (float*)malloc(sizeof(float) * TOTAL);
    if (!buf) {
        printf("Erro de memória\n");
        return 1;
    }

    // init leve (sem explosão matemática)
    for (int i = 0; i < TOTAL; i++) {
        buf[i] = (i % 100) * 0.01f;
    }

    double t0 = now();

    process(buf);

    double t1 = now();

    double sum = 0;
    for (int i = 0; i < TOTAL; i += 128) {
        sum += buf[i];
    }

    printf("⏱ Tempo: %.6f s\n", t1 - t0);
    printf("📊 checksum: %f\n", sum);

    free(buf);

    printf("✔ Execução concluída\n");
    return 0;
}
