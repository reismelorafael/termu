/* rafael.c
   Protótipo do Sistema Rafael (C puro, baixo nível)
   Compilar: clang rafael.c -O2 -lm -o rafael
   Rodar: ./rafael
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

/* Parâmetros operacionais (ajustáveis) */
#define H_DIM 16        /* dimensão de H (pequena para ARM32) */
#define G_DIM 64        /* grade discreta aproximando T^7 (coarse-grain) */
#define PARTS 8         /* número de partições para entropia local (divisor de G_DIM) */
#define T_STEPS 200     /* passos de simulação */
#define ALPHA 0.25      /* coeficiente de correção */
#define NOISE_P 0.05    /* taxa de ruído */
#define SEED 123456789  /* semente RNG */

/* Utilitários RNG simples (xorshift32) */
static unsigned int rng_state = SEED;
unsigned int xorshift32() {
    unsigned int x = rng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_state = x;
    return x;
}
double rand01() { return (xorshift32() & 0xFFFFFF) / (double)0x1000000; }

/* Vetores e matrizes simples */
void zero_vec(double *v, int n){ for(int i=0;i<n;i++) v[i]=0.0; }
void copy_vec(double *dst, double *src, int n){ for(int i=0;i<n;i++) dst[i]=src[i]; }

/* Construir H hermitiana (real simétrica aqui) */
void build_H(double H[H_DIM][H_DIM]) {
    for(int i=0;i<H_DIM;i++) for(int j=0;j<H_DIM;j++) H[i][j]=0.0;
    /* tridiagonal + small random couplings */
    for(int i=0;i<H_DIM;i++){
        H[i][i] = 1.0 + 0.1 * (rand01()-0.5); /* energia local */
        if(i+1<H_DIM){
            double v = 0.2 * (rand01()-0.5);
            H[i][i+1] = v;
            H[i+1][i] = v;
        }
    }
    /* small random symmetric fill */
    for(int k=0;k< H_DIM; k++){
        int i = xorshift32()%H_DIM;
        int j = xorshift32()%H_DIM;
        double v = 0.05*(rand01()-0.5);
        H[i][j]+=v; H[j][i]+=v;
    }
}

/* Aplica H a vetor (multiplicação) */
void apply_H(double H[H_DIM][H_DIM], double *in, double *out){
    for(int i=0;i<H_DIM;i++){
        double s=0.0;
        for(int j=0;j<H_DIM;j++) s += H[i][j]*in[j];
        out[i]=s;
    }
}

/* Normaliza vetor (L2) */
void normalize(double *v, int n){
    double s=0.0;
    for(int i=0;i<n;i++) s += v[i]*v[i];
    if(s<=0) return;
    double norm = sqrt(s);
    for(int i=0;i<n;i++) v[i]/=norm;
}

/* Construir estado combinado H x G como vetor real (amplitude por célula G) */
void init_state(double *psiH, double *rhoG){
    /* psiH: estado em H (amplitudes reais) */
    for(int i=0;i<H_DIM;i++) psiH[i] = (rand01()-0.5);
    normalize(psiH,H_DIM);
    /* rhoG: distribuição sobre grade G (probabilidades) */
    double sum=0.0;
    for(int i=0;i<G_DIM;i++){ rhoG[i] = 0.1 + 0.9*rand01(); sum += rhoG[i]; }
    for(int i=0;i<G_DIM;i++) rhoG[i] /= sum;
}

/* Operador U_T: permutação simples (circular shift by k) */
void apply_U_T(double *rho, double *out, int shift){
    for(int i=0;i<G_DIM;i++){
        int j = (i+shift) % G_DIM;
        out[j] = rho[i];
    }
}

/* Operador D on G: reflection modular (involution) */
void apply_D_T(double *rho, double *out){
    for(int i=0;i<G_DIM;i++){
        int j = (G_DIM - i) % G_DIM;
        out[j] = rho[i];
    }
}

/* Operador D on H: Pauli-like involution (swap pairs) */
void apply_D_H(double *psi, double *out){
    for(int i=0;i<H_DIM;i++) out[i]=0.0;
    for(int i=0;i<H_DIM;i+=2){
        if(i+1 < H_DIM){
            out[i]   = psi[i+1];
            out[i+1] = psi[i];
        } else out[i]=psi[i];
    }
}

/* Operador de correção C: convex combination com estado alvo (mixing) */
void apply_C_G(double *rho, double *rho_in, double *out){
    for(int i=0;i<G_DIM;i++){
        out[i] = (1.0-ALPHA)*rho[i] + ALPHA*rho_in[i];
    }
}

/* Ruído simples: mistura com ruído uniforme com prob p */
void apply_noise(double *rho, double p){
    if(p<=0) return;
    double uniform = 1.0 / (double)G_DIM;
    for(int i=0;i<G_DIM;i++){
        rho[i] = (1.0-p)*rho[i] + p*uniform;
    }
}

/* Entropia de Shannon (base e) para distribuição discreta */
double shannon_entropy(double *rho, int n){
    double H=0.0;
    for(int i=0;i<n;i++){
        double p = rho[i];
        if(p>0) H -= p * log(p);
    }
    return H;
}

/* Entropia local por partição (PARTS partes iguais) */
void local_entropies(double *rho, double *Hloc){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double sum=0.0;
        for(int i=0;i<cell;i++) sum += rho[k*cell + i];
        if(sum<=0){ Hloc[k]=0.0; continue; }
        /* renormalize and compute entropy */
        double H=0.0;
        for(int i=0;i<cell;i++){
            double p = rho[k*cell + i] / sum;
            if(p>0) H -= p * log(p);
        }
        Hloc[k] = H;
    }
}

/* SNR per partition: signal = mean(probabilities in cell), noise ~ variance */
void snr_per_partition(double *rho, double *snr){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double mean=0.0;
        for(int i=0;i<cell;i++) mean += rho[k*cell + i];
        mean /= cell;
        double var=0.0;
        for(int i=0;i<cell;i++){
            double d = rho[k*cell + i] - mean;
            var += d*d;
        }
        var /= cell;
        if(var<=1e-12) snr[k] = 1e6;
        else snr[k] = mean*mean / var;
    }
}

/* grava CSV com séries temporais */
void write_csv_timeseries(double *Hloc_ts, double *Hglob_ts, int steps){
    FILE *f = fopen("rafael_timeseries.csv","w");
    if(!f) return;
    /* header */
    fprintf(f,"step,Hglob");
    for(int k=0;k<PARTS;k++) fprintf(f,",Hloc_%d",k);
    fprintf(f,"\n");
    for(int t=0;t<steps;t++){
        fprintf(f,"%d,%.12f", t, Hglob_ts[t]);
        for(int k=0;k<PARTS;k++) fprintf(f,",%.12f", Hloc_ts[t*PARTS + k]);
        fprintf(f,"\n");
    }
    fclose(f);
}

/* main: simulação */
int main(){
    /* alocações estáticas para simplicidade */
    static double H[H_DIM][H_DIM];
    static double psi[H_DIM], psi_tmp[H_DIM];
    static double rho[G_DIM], rho_tmp[G_DIM], rho_in[G_DIM];
    static double Hloc[PARTS], snr[PARTS];
    static double *Hloc_ts = NULL;
    static double *Hglob_ts = NULL;

    Hloc_ts = (double*)malloc(sizeof(double)*T_STEPS*PARTS);
    Hglob_ts = (double*)malloc(sizeof(double)*T_STEPS);

    rng_state = SEED ^ (unsigned int)time(NULL);

    /* construir operadores e estados iniciais */
    build_H(H);
    init_state(psi, rho);

    /* estado alvo para correção: cópia inicial (pode ser outra) */
    for(int i=0;i<G_DIM;i++) rho_in[i] = rho[i];

    /* normaliza psi */
    normalize(psi,H_DIM);

    /* simulação */
    for(int t=0;t<T_STEPS;t++){
        /* 1) aplicar U_T (shift) */
        int shift = (t % (G_DIM/4)) + 1; /* variação de shift */
        apply_U_T(rho, rho_tmp, shift);

        /* 2) aplicar dualidade D (em alguns passos) */
        if(t % 10 == 0){
            apply_D_T(rho_tmp, rho);
        } else {
            for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];
        }

        /* 3) aplicar correção C em direção a rho_in */
        apply_C_G(rho, rho_in, rho_tmp);

        /* 4) aplicar ruído */
        apply_noise(rho_tmp, NOISE_P);

        /* 5) normalizar (garantir soma 1) */
        double sum=0.0;
        for(int i=0;i<G_DIM;i++) sum += rho_tmp[i];
        if(sum<=0) sum=1.0;
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i]/sum;

        /* 6) medir entropias e SNR */
        double Hglob = shannon_entropy(rho, G_DIM);
        local_entropies(rho, Hloc);
        snr_per_partition(rho, snr);

        /* salvar séries */
        Hglob_ts[t] = Hglob;
        for(int k=0;k<PARTS;k++) Hloc_ts[t*PARTS + k] = Hloc[k];

        /* imprimir resumo periódico */
        if(t % 20 == 0){
            printf("step=%3d Hglob=%.6f Hloc[0]=%.6f SNR[0]=%.3f\n", t, Hglob, Hloc[0], snr[0]);
        }
    }

    /* grava CSV */
    write_csv_timeseries(Hloc_ts, Hglob_ts, T_STEPS);

    /* resumo final */
    printf("Simulação completa. Arquivo gerado: rafael_timeseries.csv\n");
    printf("Parâmetros: H_DIM=%d G_DIM=%d PARTS=%d T_STEPS=%d ALPHA=%.2f NOISE_P=%.3f\n",
           H_DIM, G_DIM, PARTS, T_STEPS, ALPHA, NOISE_P);

    free(Hloc_ts); free(Hglob_ts);
    return 0;
}
