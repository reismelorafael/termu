#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __aarch64__
#include <arm_neon.h>
#endif

// =============================
// CORE: CRC32 HW + NEON
// =============================
static inline uint32_t core_crc32(uint8_t *p, size_t n) {
    uint32_t c = 0;

#if defined(__aarch64__)
    size_t i = 0;

    // Alinhamento inicial
    for (; ((uintptr_t)(p+i) & 7) && i < n; i++) {
        __asm__ volatile(
            "crc32b %w[c], %w[c], %w[v]\n"
            : [c] "+r"(c)
            : [v] "r"(p[i])
        );
    }

    // Loop principal (64-bit stride)
    for (; i + 8 <= n; i += 8) {
        uint64_t v = *(uint64_t*)(p + i);
        __asm__ volatile(
            "crc32x %w[c], %w[c], %x[v]\n"
            : [c] "+r"(c)
            : [v] "r"(v)
        );
    }

    // Resto
    for (; i < n; i++) {
        __asm__ volatile(
            "crc32b %w[c], %w[c], %w[v]\n"
            : [c] "+r"(c)
            : [v] "r"(p[i])
        );
    }
#else
    for (size_t i = 0; i < n; i++) {
        c ^= p[i];
        for (int j = 0; j < 8; j++)
            c = (c >> 1) ^ (0xEDB88320 & -(c & 1));
    }
#endif

    return c;
}

// =============================
// CORE: NEON VECTOR MIX
// =============================
#ifdef __aarch64__
static inline void core_mix(uint8_t *p, size_t n) {
    size_t i = 0;

    for (; i + 16 <= n; i += 16) {
        uint8x16_t v = vld1q_u8(p + i);

        // transformação: xor + shift (fase)
        uint8x16_t r = veorq_u8(v, vextq_u8(v, v, 7));

        vst1q_u8(p + i, r);
    }
}
#endif

// =============================
// CORE: PREFETCH + CACHE FLOW
// =============================
static inline void core_prefetch(uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i += 64) {
        __builtin_prefetch(p + i, 0, 3);
    }
}

// =============================
// ENTRY
// =============================
int main() {
    size_t n = 1 << 20; // 1MB
    uint8_t *p;

    // alinhamento cacheline
    posix_memalign((void**)&p, 64, n);

    // inicialização
    for (size_t i = 0; i < n; i++) {
        p[i] = (uint8_t)(i * 131);
    }

    // PREFETCH (L1/L2 warmup)
    core_prefetch(p, n);

#ifdef __aarch64__
    core_mix(p, n);
#endif

    uint32_t c = core_crc32(p, n);

    printf("CRC32: %08x\n", c);

    free(p);
    return 0;
}
