// ============================================================
// BITOMEGA – ENUMERADOR DE ATRATORES (FIX)
// ============================================================

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>   // <<< FIX PRINCIPAL

#define Q 10
#define STEPS 1000

typedef struct {
    uint8_t q;
    float C;
    float H;
} State;

// dinâmica
State step(State s, uint32_t input) {
    State out;

    float Cin = (input & 0xF) / 15.0f;
    float Hin = ((input >> 4) & 0xF) / 15.0f;

    // contração
    out.C = 0.75f * s.C + 0.25f * Cin;
    out.H = 0.75f * s.H + 0.25f * Hin;

    // mistura
    uint32_t mix = ((uint32_t)(out.C * 255) ^
                    (uint32_t)(out.H * 255) ^
                    input);

    out.q = (s.q + mix) % Q;

    return out;
}

// detecção de ciclo (Floyd)
int detect_cycle(State s0) {
    State tortoise = step(s0, 1);
    State hare = step(step(s0, 1), 2);

    int iter = 0;

    while (iter < STEPS) {

        if (tortoise.q == hare.q &&
            fabs(tortoise.C - hare.C) < 1e-3 &&
            fabs(tortoise.H - hare.H) < 1e-3) {
            return 1;
        }

        tortoise = step(tortoise, iter + 3);
        hare = step(step(hare, iter + 4), iter + 5);

        iter++;
    }

    return 0;
}

int main() {
    printf("=== BITOMEGA ATRACTOR SCAN ===\n");

    int attractors = 0;

    for (int q = 0; q < Q; q++) {
        for (int c = 0; c < 10; c++) {
            for (int h = 0; h < 10; h++) {

                State s;
                s.q = q;
                s.C = c / 10.0f;
                s.H = h / 10.0f;

                if (detect_cycle(s)) {
                    attractors++;
                }
            }
        }
    }

    printf("Atratores detectados: %d\n", attractors);
    printf("================================\n");

    return 0;
}
