#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <arm_neon.h>
#include <arm_acle.h>
#include <sched.h>
#include <time.h>

#define CELLS 1024
#define ITERS 100000

typedef struct {
    float32x4_t pos_lo; 
    float32x4_t pos_hi; 
    uint64_t bitraf;    
} __attribute__((aligned(64))) Cell;

static Cell torus[CELLS];

static inline void pulse_step(Cell *c, float32x4_t w) {
    // Usamos __builtin_prefetch para evitar erros de sintaxe de assembly manual
    // 0 = read, 3 = high temporal locality (keep in L1)
    __builtin_prefetch(c + 2, 0, 3);

    float32x4_t diff = vsubq_f32(c->pos_lo, vdupq_n_f32(0.5f));
    c->pos_lo = vmlaq_f32(c->pos_lo, diff, w);

    // Integridade via CRC32 - Unidade de Inteiros
    c->bitraf = __crc32d(c->bitraf, *(uint64_t*)&c->pos_lo);
}

int main() {
    // Trava no núcleo 7 (Big Core do Helio G25)
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(7, &cpuset);
    sched_setaffinity(0, sizeof(cpu_set_t), &cpuset);

    float32x4_t weights = vdupq_n_f32(0.001f);
    printf("\033[1;34m[VECTRA] Iniciando Unidade Fusionada...\033[0m\n");
    
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for(int t=0; t<ITERS; t++) {
        for(int i=0; i<CELLS; i++) {
            pulse_step(&torus[i], weights);
        }
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double elapsed = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("\n\033[1;32m--- EXACORDEX FINAL ---\033[0m\n");
    printf("Throughput: %.2f M-Pulsos/s\n", (CELLS * ITERS) / elapsed / 1e6);
    printf("Status: Pipeline Sincronizado\n");
    return 0;
}
