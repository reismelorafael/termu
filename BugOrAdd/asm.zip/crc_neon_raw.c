#include <stdint.h>
#include <sys/mman.h>
#include <unistd.h>

// Syscalls em inline assembly (sem libc)
static long mmap_raw(void *addr, size_t len, int prot, int flags, int fd, off_t off) {
    long ret;
    __asm__ volatile (
        "mov x0, %1\n"
        "mov x1, %2\n"
        "mov x2, %3\n"
        "mov x3, %4\n"
        "mov x4, %5\n"
        "mov x5, %6\n"
        "mov x8, #222\n"
        "svc #0\n"
        "mov %0, x0\n"
        : "=r"(ret)
        : "r"(addr), "r"(len), "r"(prot), "r"(flags), "r"(fd), "r"(off)
        : "x0","x1","x2","x3","x4","x5","x8","memory"
    );
    return ret;
}

static long write_raw(int fd, const void *buf, size_t count) {
    long ret;
    __asm__ volatile (
        "mov x0, %1\n"
        "mov x1, %2\n"
        "mov x2, %3\n"
        "mov x8, #64\n"
        "svc #0\n"
        "mov %0, x0\n"
        : "=r"(ret)
        : "r"(fd), "r"(buf), "r"(count)
        : "x0","x1","x2","x8","memory"
    );
    return ret;
}

static void exit_raw(int code) {
    __asm__ volatile (
        "mov x0, %0\n"
        "mov x8, #93\n"
        "svc #0\n"
        : : "r"(code) : "x0","x8"
    );
}

int main() {
    // mmap anônimo de 1MB, alinhado a 64 bytes (cache line)
    uint8_t *buf = (uint8_t*)mmap_raw(0, 1<<20, 0x3, 0x22, -1, 0);
    if ((long)buf == -1) exit_raw(1);

    // Preencher buffer com i*131 (sem loop for/while, usando goto)
    uint64_t i = 0;
    const uint64_t size = 1<<20;
    const uint64_t mul = 131;
fill_start:
    if (i >= size) goto fill_done;
    ((uint8_t*)buf)[i] = (uint8_t)(i * mul);
    i++;
    goto fill_start;
fill_done:

    // Prefetch (opcional, sem loop)
    for (uint64_t p = 0; p < size; p += 64) {
        __builtin_prefetch(buf + p, 0, 3);
    }

    // Medir ciclos início
    uint64_t t0;
    __asm__ volatile("mrs %0, cntvct_el0" : "=r"(t0));

    // CRC32 loop principal (64 bytes por iteração, NEON)
    uint32_t crc = 0;
    uint64_t pos = 0;
crc_loop:
    if (pos + 64 > size) goto crc_remainder;
    uint8_t *p = buf + pos;
    __asm__ volatile (
        "ld1 {v0.16b, v1.16b, v2.16b, v3.16b}, [%[ptr]]\n"
        "umov x4, v0.d[0]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v0.d[1]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v1.d[0]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v1.d[1]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v2.d[0]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v2.d[1]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v3.d[0]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        "umov x4, v3.d[1]\n"
        "crc32x %w[crc], %w[crc], x4\n"
        : [crc] "+r"(crc)
        : [ptr] "r"(p)
        : "x4", "v0","v1","v2","v3","memory"
    );
    pos += 64;
    goto crc_loop;

crc_remainder:
    // Bytes restantes (<64) com crc32b
    if (pos >= size) goto crc_done;
    uint8_t byte = buf[pos];
    __asm__ volatile("crc32b %w[crc], %w[crc], %w[byte]"
                     : [crc] "+r"(crc) : [byte] "r"(byte));
    pos++;
    goto crc_remainder;

crc_done:
    uint64_t t1;
    __asm__ volatile("mrs %0, cntvct_el0" : "=r"(t1));

    // Montar string de saída: "CRC=XXXXXXXX\nCYCLES=YYYYYYYYYY\n"
    char out[64];
    char *ptr = out;
    // CRC=
    *ptr++ = 'C'; *ptr++ = 'R'; *ptr++ = 'C'; *ptr++ = '=';
    // Converter CRC para hex (8 dígitos)
    uint32_t tmp = crc;
    for (int shift = 28; shift >= 0; shift -= 4) {
        int nibble = (tmp >> shift) & 0xF;
        *ptr++ = (nibble < 10) ? ('0' + nibble) : ('A' + nibble - 10);
    }
    *ptr++ = '\n';
    // CYCLES=
    *ptr++ = 'C'; *ptr++ = 'Y'; *ptr++ = 'C'; *ptr++ = 'L'; *ptr++ = 'E'; *ptr++ = 'S'; *ptr++ = '=';
    // Converter ciclos para decimal
    uint64_t cycles = t1 - t0;
    char tmpbuf[20];
    char *tptr = tmpbuf + sizeof(tmpbuf) - 1;
    *tptr = '\0';
    do {
        *--tptr = '0' + (cycles % 10);
        cycles /= 10;
    } while (cycles);
    while (*tptr) *ptr++ = *tptr++;
    *ptr++ = '\n';
    // Escrever na saída
    write_raw(1, out, ptr - out);
    exit_raw(0);
    return 0;
}
