#include <stdio.h>
#include <math.h>

// dados do seu experimento
double n[] = {10,15,20,25,30,35,40};
double S[] = {0.94,0.97,0.96,0.99,0.98,0.83,0.35};

int main(){

    for(int i=0;i<7;i++){
        double y = log((1.0/S[i]) - 1.0);
        printf("n=%f logit=%f\n",n[i],y);
    }

    printf("\nFit linear: logit = alpha*(n - nc)\n");

    return 0;
}
