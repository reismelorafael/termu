#!/usr/bin/env python3
"""
download_voynich_images.py
Baixa imagens de alta resolução do Manuscrito de Voynich
e salva em ~/voynich_data/images/
Uso: python download_voynich_images.py
"""

import os
import sys
import json
import requests
from tqdm import tqdm
from pathlib import Path

# Configurações
BASE_DIR = Path.home() / "voynich_data"
IMAGES_DIR = BASE_DIR / "images"
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# URLs das fontes (prioridade: Internet Archive)
# 1. Internet Archive – digitalização completa
ARCHIVE_ID = "BeineckeMS408_47"
ARCHIVE_METADATA_URL = f"https://archive.org/metadata/{ARCHIVE_ID}"
# 2. Fallback: Yale Beinecke IIIF (exemplo, pode ser usado se o Archive falhar)
# IIIF base: https://brbl-dl.library.yale.edu/iiif/... (não usaremos diretamente por simplicidade)

def get_archive_file_list():
    """Obtém a lista de arquivos de imagem do Internet Archive."""
    resp = requests.get(ARCHIVE_METADATA_URL)
    resp.raise_for_status()
    data = resp.json()
    files = data.get("files", [])
    # Filtra apenas arquivos de imagem (jpg, jpeg, png, tiff)
    image_extensions = ('.jpg', '.jpeg', '.png', '.tif', '.tiff')
    image_files = [f for f in files if f['name'].lower().endswith(image_extensions)]
    return image_files

def download_file(url, dest_path):
    """Baixa um arquivo com barra de progresso."""
    response = requests.get(url, stream=True)
    response.raise_for_status()
    total_size = int(response.headers.get('content-length', 0))
    block_size = 8192
    with open(dest_path, 'wb') as f:
        with tqdm(total=total_size, unit='B', unit_scale=True, desc=dest_path.name) as pbar:
            for chunk in response.iter_content(chunk_size=block_size):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
    return True

def main():
    print("🔍 Obtendo lista de imagens do Internet Archive...")
    try:
        images = get_archive_file_list()
    except Exception as e:
        print(f"❌ Erro ao acessar Internet Archive: {e}")
        print("Tentando método alternativo (lista fixa)...")
        # Lista fixa de páginas conhecidas (fallback)
        # Gera URLs baseadas no padrão do Internet Archive
        # Ex: https://archive.org/download/BeineckeMS408_47/BeineckeMS408_47_0001.jpg
        images = [{'name': f'BeineckeMS408_47_{i:04d}.jpg'} for i in range(1, 241)]
    
    print(f"📸 Encontradas {len(images)} imagens.")
    
    for img in images:
        filename = img['name']
        dest = IMAGES_DIR / filename
        if dest.exists():
            print(f"⏭️  Arquivo já existe: {filename}")
            continue
        
        # Constrói URL de download (Internet Archive)
        url = f"https://archive.org/download/{ARCHIVE_ID}/{filename}"
        print(f"⬇️  Baixando {filename}...")
        try:
            download_file(url, dest)
            print(f"✅ Salvo: {dest}")
        except Exception as e:
            print(f"⚠️  Falha ao baixar {filename}: {e}")
            continue
    
    print("\n🎉 Download concluído!")
    print(f"📂 Imagens salvas em: {IMAGES_DIR}")
    print("Agora você pode executar o programa C 'voynich_toroidal' para navegar no toro.")

if __name__ == "__main__":
    main()
