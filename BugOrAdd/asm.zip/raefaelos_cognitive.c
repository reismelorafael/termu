#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define DIM 64
#define TOTAL (DIM * DIM * DIM)

typedef struct {
    float state;
    float memory;
    float momentum;
} Node;

// ⏱ timer
double now() {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

// 🧠 kernel cognitivo RAFAELOS
static inline void cognitive_step(Node *n, int len) {
    for (int i = 0; i < len; i++) {

        // percepção local (entrada + memória)
        float perception = n[i].state + n[i].memory * 0.5f;

        // atualização de momentum (inércia cognitiva)
        n[i].momentum = n[i].momentum * 0.7f + perception * 0.3f;

        // nova state (dinâmica não-linear)
        n[i].state = tanhf(n[i].momentum);

        // memória evolutiva
        n[i].memory = n[i].memory * 0.9f + n[i].state * 0.1f;
    }
}

// 🌌 propagação de coerência entre vizinhos
static inline void coherence(Node *n) {
    for (int i = 1; i < TOTAL - 1; i++) {
        float avg = (n[i-1].state + n[i].state + n[i+1].state) / 3.0f;
        n[i].state = n[i].state * 0.8f + avg * 0.2f;
    }
}

int main() {

    printf("🧠 RAFAELOS Cognitive Engine v1 iniciando...\n");

    Node *net = malloc(sizeof(Node) * TOTAL);
    if (!net) return 1;

    // 🔧 inicialização (estado caótico controlado)
    for (int i = 0; i < TOTAL; i++) {
        net[i].state = (i % 100) * 0.01f;
        net[i].memory = 0.0f;
        net[i].momentum = 0.0f;
    }

    double t0 = now();

    // 🔁 ciclo cognitivo
    for (int step = 0; step < 8; step++) {
        cognitive_step(net, TOTAL);
        coherence(net);
    }

    double t1 = now();

    // 📊 compressão de estado global (consciência agregada)
    double global = 0;
    for (int i = 0; i < TOTAL; i += 128) {
        global += net[i].state;
    }

    printf("⏱ Tempo cognitivo: %.6f s\n", t1 - t0);
    printf("🧠 Estado global: %f\n", global);

    free(net);

    printf("✔ RAFAELOS ciclo concluído\n");
    return 0;
}
