/* rafael_stats.c
   Agrega o último Htotal de múltiplos CSVs gerados por rafael_complex.
   Uso: ./rafael_stats file1.csv file2.csv ...
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

double parse_last_Htotal(const char *fname){
    FILE *f = fopen(fname,"r");
    if(!f) return NAN;
    char line[2048];
    double last = NAN;
    /* skip header */
    if(!fgets(line,sizeof(line),f)){ fclose(f); return NAN; }
    while(fgets(line,sizeof(line),f)){
        /* CSV: step,Hglob,Hpsi,Htotal,spec_peak,... */
        char *p = line;
        /* skip step */
        for(int i=0;i<3 && p; i++){
            p = strchr(p, ',');
            if(p) p++;
        }
        if(!p) continue;
        double Htotal = atof(p);
        last = Htotal;
    }
    fclose(f);
    return last;
}

int main(int argc, char **argv){
    if(argc < 2){
        printf("Usage: %s file1.csv file2.csv ...\n", argv[0]);
        return 1;
    }
    int n = argc - 1;
    double *vals = (double*)malloc(sizeof(double)*n);
    int count = 0;
    for(int i=1;i<argc;i++){
        double v = parse_last_Htotal(argv[i]);
        if(isnan(v)){
            fprintf(stderr,"Warning: could not parse %s\n", argv[i]);
            continue;
        }
        vals[count++] = v;
    }
    if(count == 0){
        fprintf(stderr,"No valid files parsed.\n");
        free(vals);
        return 1;
    }
    double mean=0.0;
    for(int i=0;i<count;i++) mean += vals[i];
    mean /= count;
    double var=0.0;
    for(int i=0;i<count;i++){ double d = vals[i]-mean; var += d*d; }
    var /= count;
    printf("Aggregated runs: %d\n", count);
    printf("Htotal mean = %.6f\n", mean);
    printf("Htotal var  = %.6f\n", var);
    free(vals);
    return 0;
}
