/* rafael_complex.c
   Sistema Rafael — versão complexa (ψ complexo, evolução quase-unitária),
   DFT em G, acoplamento bidirecional, dualidade probabilística,
   detecção simples de atrator por variância de H_total.
   Compilar: clang rafael_complex.c -O2 -lm -std=c99 -o rafael_complex
   Uso: ./rafael_complex <seed> <out_csv>
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <complex.h>
#include <string.h>

#define H_DIM 16
#define G_DIM 64
#define PARTS 8
#define T_STEPS 300
#define ALPHA 0.25
#define NOISE_P 0.05
#define DT 0.05
#define COUPLING 0.12
#define GAMMA 0.03
#define LAMBDA_PSI 0.8
#define P_DUAL 0.12
#define ATTR_WINDOW 60   /* janela para detectar atrator (últimos passos) */

static unsigned int rng_state = 123456789u;
unsigned int xorshift32(){ unsigned int x=rng_state; x^=x<<13; x^=x>>17; x^=x<<5; rng_state=x; return x; }
double rand01(){ return (xorshift32() & 0xFFFFFF) / (double)0x1000000; }

void normalize_real(double *v,int n){
    double s=0.0; for(int i=0;i<n;i++) s += v[i]*v[i];
    if(s<=0) return;
    double norm = sqrt(s);
    for(int i=0;i<n;i++) v[i] /= norm;
}
void normalize_complex(double complex *v,int n){
    double s=0.0;
    for(int i=0;i<n;i++){ double mag = creal(v[i])*creal(v[i]) + cimag(v[i])*cimag(v[i]); s += mag; }
    if(s<=0) return;
    double norm = sqrt(s);
    for(int i=0;i<n;i++) v[i] /= norm;
}

/* Construir H real simétrica */
void build_H(double H[H_DIM][H_DIM]){
    for(int i=0;i<H_DIM;i++) for(int j=0;j<H_DIM;j++) H[i][j]=0.0;
    for(int i=0;i<H_DIM;i++){
        H[i][i] = 1.0 + 0.1*(rand01()-0.5);
        if(i+1 < H_DIM){
            double v = 0.2*(rand01()-0.5);
            H[i][i+1] = v; H[i+1][i] = v;
        }
    }
}

/* Aplica H a vetor complexo: out = H * in */
void apply_H(double H[H_DIM][H_DIM], double complex *in, double complex *out){
    for(int i=0;i<H_DIM;i++){
        double complex s = 0.0 + 0.0*I;
        for(int j=0;j<H_DIM;j++) s += H[i][j] * in[j];
        out[i] = s;
    }
}

/* Inicializa psi (complexo) e rho (real prob.) */
void init_state(double complex *psi, double *rho){
    for(int i=0;i<H_DIM;i++){
        double re = (rand01()-0.5);
        double im = (rand01()-0.5);
        psi[i] = re + im * I;
    }
    normalize_complex(psi, H_DIM);
    double sum=0.0;
    for(int i=0;i<G_DIM;i++){ rho[i] = rand01(); sum += rho[i]; }
    for(int i=0;i<G_DIM;i++) rho[i] /= sum;
}

/* U_T: circular shift */
void apply_U_T(double *rho, double *out, int shift){
    for(int i=0;i<G_DIM;i++){ int j=(i+shift)%G_DIM; out[j]=rho[i]; }
}

/* D on G: reflection modular (involution) */
void apply_D_T(double *rho, double *out){
    for(int i=0;i<G_DIM;i++){ int j=(G_DIM - i) % G_DIM; out[j] = rho[i]; }
}

/* D on H: swap pairs (involution) */
void apply_D_H(double complex *psi, double complex *out){
    for(int i=0;i<H_DIM;i++) out[i]=0.0 + 0.0*I;
    for(int i=0;i<H_DIM;i+=2){
        if(i+1 < H_DIM){ out[i] = psi[i+1]; out[i+1] = psi[i]; }
        else out[i] = psi[i];
    }
}

/* Correção C em G */
void apply_C_G(double *rho, double *rho_in, double *out){
    for(int i=0;i<G_DIM;i++) out[i] = (1.0-ALPHA)*rho[i] + ALPHA*rho_in[i];
}

/* Ruído: mistura com uniforme */
void apply_noise(double *rho, double p){
    if(p <= 0.0) return;
    double u = 1.0 / (double)G_DIM;
    for(int i=0;i<G_DIM;i++) rho[i] = (1.0-p)*rho[i] + p*u;
}

/* Entropia de Shannon */
double shannon_entropy(double *rho, int n){
    double H=0.0;
    for(int i=0;i<n;i++){
        double p = rho[i];
        if(p>0) H -= p * log(p);
    }
    return H;
}

/* Entropia de psi via |psi|^2 */
double psi_entropy(double complex *psi){
    double sum=0.0;
    for(int i=0;i<H_DIM;i++){ double mag = creal(psi[i])*creal(psi[i]) + cimag(psi[i])*cimag(psi[i]); sum += mag; }
    if(sum<=0) return 0.0;
    double H=0.0;
    for(int i=0;i<H_DIM;i++){
        double mag = creal(psi[i])*creal(psi[i]) + cimag(psi[i])*cimag(psi[i]);
        double p = mag / sum;
        if(p>0) H -= p * log(p);
    }
    return H;
}

/* Entropias locais por partição */
void local_entropies(double *rho, double *Hloc){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double sum=0.0;
        for(int i=0;i<cell;i++) sum += rho[k*cell + i];
        if(sum <= 0.0){ Hloc[k] = 0.0; continue; }
        double H=0.0;
        for(int i=0;i<cell;i++){
            double p = rho[k*cell + i] / sum;
            if(p>0) H -= p * log(p);
        }
        Hloc[k] = H;
    }
}

/* SNR por partição */
void snr_per_partition(double *rho, double *snr){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double mean=0.0;
        for(int i=0;i<cell;i++) mean += rho[k*cell + i];
        mean /= cell;
        double var=0.0;
        for(int i=0;i<cell;i++){ double d = rho[k*cell + i] - mean; var += d*d; }
        var /= cell;
        snr[k] = (var <= 1e-12) ? 1e6 : (mean*mean / var);
    }
}

/* DFT (naive) de rho: retorna índice do pico espectral (magnitude) */
int dft_peak_index(double *rho){
    /* compute complex spectrum X[k] = sum_n rho[n] * exp(-2πi k n / N) */
    int N = G_DIM;
    double maxmag = -1.0;
    int argmax = 0;
    for(int k=0;k<N;k++){
        double real = 0.0, imag = 0.0;
        for(int n=0;n<N;n++){
            double angle = -2.0 * M_PI * k * n / (double)N;
            real += rho[n] * cos(angle);
            imag += rho[n] * sin(angle);
        }
        double mag = sqrt(real*real + imag*imag);
        if(mag > maxmag){ maxmag = mag; argmax = k; }
    }
    return argmax;
}

/* grava CSV com séries temporais */
void write_csv_header(FILE *f){
    fprintf(f,"step,Hglob,Hpsi,Htotal,spec_peak");
    for(int k=0;k<PARTS;k++) fprintf(f,",Hloc_%d",k);
    fprintf(f,"\n");
}

int main(int argc, char **argv){
    unsigned int seed = (unsigned int)time(NULL) ^ 0xA5A5A5A5u;
    const char *outname = "rafael_complex_timeseries.csv";
    if(argc >= 2) seed = (unsigned int)atoi(argv[1]);
    if(argc >= 3) outname = argv[2];
    rng_state = seed;

    static double H[H_DIM][H_DIM];
    static double complex psi[H_DIM], psi_tmp[H_DIM], psi2[H_DIM];
    static double rho[G_DIM], rho_tmp[G_DIM], rho_in[G_DIM];
    static double Hloc[PARTS], snr[PARTS];

    build_H(H);
    init_state(psi, rho);
    for(int i=0;i<G_DIM;i++) rho_in[i] = rho[i];

    FILE *f = fopen(outname, "w");
    if(!f){ perror("fopen"); return 1; }
    write_csv_header(f);

    /* buffer para detecção de atrator */
    double Htotal_buffer[ATTR_WINDOW];
    int buf_idx = 0;

    for(int t=0;t<T_STEPS;t++){
        /* U_T */
        int shift = (t % (G_DIM/4)) + 1;
        apply_U_T(rho, rho_tmp, shift);
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];

        /* Dualidade probabilística */
        if(rand01() < P_DUAL){
            apply_D_T(rho, rho_tmp);
            for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];
            apply_D_H(psi, psi_tmp);
            for(int i=0;i<H_DIM;i++) psi[i] = psi_tmp[i];
        }

        /* Acoplamento H -> G: influence = |psi|^2 */
        for(int i=0;i<G_DIM;i++){
            double mag = creal(psi[i % H_DIM])*creal(psi[i % H_DIM]) + cimag(psi[i % H_DIM])*cimag(psi[i % H_DIM]);
            rho[i] *= (1.0 + COUPLING * mag);
        }
        /* renormaliza rho */
        double sum = 0.0;
        for(int i=0;i<G_DIM;i++) sum += rho[i];
        if(sum <= 0.0) sum = 1.0;
        for(int i=0;i<G_DIM;i++) rho[i] /= sum;

        /* Correção e ruído */
        apply_C_G(rho, rho_in, rho_tmp);
        apply_noise(rho_tmp, NOISE_P);
        sum = 0.0;
        for(int i=0;i<G_DIM;i++) sum += rho_tmp[i];
        if(sum <= 0.0) sum = 1.0;
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i] / sum;

        /* Evolução quase-unitária de psi: psi <- (1 - i H dt - 0.5 H^2 dt^2) psi + feedback */
        apply_H(H, psi, psi_tmp);      /* H psi */
        apply_H(H, psi_tmp, psi2);    /* H^2 psi */
        for(int i=0;i<H_DIM;i++){
            double complex term1 = - I * DT * psi_tmp[i];
            double complex term2 = - 0.5 * DT * DT * psi2[i];
            /* feedback G -> H: adiciona real bias proporcional a rho */
            double bias = GAMMA * rho[i % G_DIM];
            psi[i] = psi[i] + term1 + term2 + bias;
        }
        normalize_complex(psi, H_DIM);

        /* Medidas */
        double Hglob = shannon_entropy(rho, G_DIM);
        double Hpsi  = psi_entropy(psi);
        double Htotal = Hglob + LAMBDA_PSI * Hpsi;
        local_entropies(rho, Hloc);
        snr_per_partition(rho, snr);
        int spec_peak = dft_peak_index(rho);

        /* grava linha */
        fprintf(f,"%d,%.12f,%.12f,%.12f,%d", t, Hglob, Hpsi, Htotal, spec_peak);
        for(int k=0;k<PARTS;k++) fprintf(f,",%.12f", Hloc[k]);
        fprintf(f,"\n");

        /* buffer para atrator detection */
        Htotal_buffer[buf_idx % ATTR_WINDOW] = Htotal;
        buf_idx++;

        if(t % 30 == 0){
            printf("seed=%u step=%3d Hglob=%.3f Hpsi=%.3f Htotal=%.3f spec_peak=%d SNR0=%.2f\n",
                   seed, t, Hglob, Hpsi, Htotal, spec_peak, snr[0]);
        }
    }

    /* detectar atrator: variância de Htotal na janela final */
    int filled = (buf_idx < ATTR_WINDOW) ? buf_idx : ATTR_WINDOW;
    double mean=0.0, var=0.0;
    for(int i=0;i<filled;i++) mean += Htotal_buffer[i];
    mean /= (filled>0?filled:1);
    for(int i=0;i<filled;i++){ double d = Htotal_buffer[i]-mean; var += d*d; }
    var /= (filled>0?filled:1);
    printf("seed=%u finished. Htotal_mean_window=%.6f Htotal_var_window=%.6f\n", seed, mean, var);
    if(var < 1e-4) printf("=> attractor detected (low variance in final window)\n");
    else printf("=> no strong attractor detected (variance above threshold)\n");

    fclose(f);
    printf("Run complete. seed=%u out=%s\n", seed, outname);
    return 0;
}
