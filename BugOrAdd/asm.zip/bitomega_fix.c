#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#define Q 10
#define STEPS 2000

typedef struct {
    uint8_t q;
    int C;
    int H;
} State;

// passo com quantização
State step(State s, uint32_t input) {
    State out;

    float Cin = (input & 0xF) / 15.0f;
    float Hin = ((input >> 4) & 0xF) / 15.0f;

    float Cf = 0.75f * (s.C / 100.0f) + 0.25f * Cin;
    float Hf = 0.75f * (s.H / 100.0f) + 0.25f * Hin;

    out.C = (int)(Cf * 100);
    out.H = (int)(Hf * 100);

    uint32_t mix = (out.C ^ out.H ^ input);
    out.q = (s.q + mix) % Q;

    return out;
}

// agora comparação exata
int equal(State a, State b){
    return (a.q == b.q && a.C == b.C && a.H == b.H);
}

// Floyd agora funciona
int detect_cycle(State s0) {
    State tortoise = step(s0, 1);
    State hare = step(step(s0, 1), 2);

    for(int i=0;i<STEPS;i++){
        if(equal(tortoise, hare)){
            return 1;
        }
        tortoise = step(tortoise, i+3);
        hare = step(step(hare, i+4), i+5);
    }

    return 0;
}

int main() {
    printf("=== BITOMEGA DISCRETE ===\n");

    int attractors = 0;

    for(int q=0;q<Q;q++){
        for(int c=0;c<100;c+=10){
            for(int h=0;h<100;h+=10){

                State s = {q, c, h};

                if(detect_cycle(s)){
                    attractors++;
                }
            }
        }
    }

    printf("Atratores detectados: %d\n", attractors);

    return 0;
}
