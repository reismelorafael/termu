.global _start
.section .bss
.align 8
T:      .skip 262144*8
Flow:   .skip 262144*8
Residual:.skip 262144*1
Counters:.skip 64

.section .data
LUT_DECAY:
    .quad 0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7  // Preencher 65536 valores
LUT_FLOW:
    .quad 0x0,0x0,0x1,0x1,0x2,0x2,0x3,0x3

.section .text
_start:
    mov x0,0             // índice base
init_loop:
    ldr x1, =T
    str x0, [x1, x0, LSL #3]  // T[i] = i
    add x0, x0, #1
    cmp x0, #262144
    b.lt init_loop

    // Benchmark start
    mrs x2, CNTVCT_EL0

    // Fase decay+diffusion
    mov x3,0
decay_loop:
    ldr x4, =T
    ldr x5, [x4, x3, LSL #3]
    ldr x6, =LUT_DECAY
    ldr x7, [x6, x5, LSL #1]
    sub x5, x5, x7
    str x5, [x4, x3, LSL #3]
    add x3,x3,#1
    cmp x3,#262144
    b.lt decay_loop

    // Benchmark stop
    mrs x8, CNTVCT_EL0
    sub x9,x8,x2
    ldr x10, =Counters
    str x9,[x10]

hang:
    b hang
