#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdio.h>

// leitura de tempo (contador ARM64)
static inline uint64_t rdtsc() {
    uint64_t v;
    asm volatile("mrs %0, cntvct_el0" : "=r"(v));
    return v;
}

int main() {
    int fd = open("input.bin", O_RDONLY);
    if (fd < 0) return 1;

    struct stat st;
    if (fstat(fd, &st) < 0) return 1;

    size_t size = st.st_size;

    uint8_t *buf = mmap(0, size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (buf == (void*)-1) return 1;

    uint64_t crc = 0;
    uint64_t t0 = rdtsc();

    // ============================
    // LOOP ASM PURO ARM64
    // ============================
    asm volatile(
        "mov x0, %[buf]\n"
        "mov x1, %[size]\n"
        "mov x2, #0\n"

        "cmp x1, #64\n"
        "blt 2f\n"

        "1:\n"
        "ld1 {v0.16b, v1.16b, v2.16b, v3.16b}, [x0], #64\n"

        "umov x3, v0.d[0]\n"
        "crc32x w2, w2, x3\n"
        "umov x3, v0.d[1]\n"
        "crc32x w2, w2, x3\n"

        "umov x3, v1.d[0]\n"
        "crc32x w2, w2, x3\n"
        "umov x3, v1.d[1]\n"
        "crc32x w2, w2, x3\n"

        "umov x3, v2.d[0]\n"
        "crc32x w2, w2, x3\n"
        "umov x3, v2.d[1]\n"
        "crc32x w2, w2, x3\n"

        "umov x3, v3.d[0]\n"
        "crc32x w2, w2, x3\n"
        "umov x3, v3.d[1]\n"
        "crc32x w2, w2, x3\n"

        "subs x1, x1, #64\n"
        "bge 1b\n"

        "2:\n"
        "mov %[out], x2\n"

        : [out] "=r"(crc)
        : [buf] "r"(buf), [size] "r"(size)
        : "x0","x1","x2","x3","v0","v1","v2","v3","memory"
    );

    uint64_t t1 = rdtsc();

    char out[128];
    int len = 0;

    len += sprintf(out + len, "CRC=%llx\n", (unsigned long long)crc);
    len += sprintf(out + len, "CYCLES=%llu\n", (unsigned long long)(t1 - t0));

    write(1, out, len);

    return 0;
}
