.global _start

.section .bss
.align 4
torus:
.space 28     @ 7 * 4 bytes (7D)

.section .text

_start:

    @ =========================
    @ 🌱 SEED → REGISTRADORES
    @ =========================

    mov r0, #0x41        @ 'A'
    mov r1, #0x42        @ 'B'
    mov r2, #0x43
    mov r3, #0x44

    @ mistura simples (hash mínimo)
    eor r0, r0, r1
    add r2, r2, r0
    mul r3, r2, r1

    @ =========================
    @ 📦 INICIALIZA TORUS
    @ =========================

    ldr r4, =torus

    str r0, [r4, #0]
    str r1, [r4, #4]
    str r2, [r4, #8]
    str r3, [r4, #12]

    add r5, r0, r2
    add r6, r1, r3
    eor r7, r5, r6

    str r5, [r4, #16]
    str r6, [r4, #20]
    str r7, [r4, #24]

loop:

    @ =========================
    @ 🔄 PASSO DINÂMICO
    @ =========================

    ldr r0, [r4, #0]
    ldr r1, [r4, #4]
    ldr r2, [r4, #8]
    ldr r3, [r4, #12]
    ldr r5, [r4, #16]
    ldr r6, [r4, #20]
    ldr r7, [r4, #24]

    @ operação tipo toro (mod 2^32)
    add r0, r0, r1
    eor r1, r1, r2
    add r2, r2, r3
    eor r3, r3, r5
    add r5, r5, r6
    eor r6, r6, r7
    add r7, r7, r0

    @ escrita de volta
    str r0, [r4, #0]
    str r1, [r4, #4]
    str r2, [r4, #8]
    str r3, [r4, #12]
    str r5, [r4, #16]
    str r6, [r4, #20]
    str r7, [r4, #24]

    @ =========================
    @ 🔁 LOOP INFINITO
    @ =========================

    b loop
