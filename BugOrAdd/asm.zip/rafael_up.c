/* rafael_up.c
   Protótipo do Sistema Rafael com acoplamento H<->G e evolução de psi
   Compilar: clang rafael_up.c -O2 -lm -o rafael_up
   Rodar: ./rafael_up
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* Parâmetros operacionais */
#define H_DIM 16
#define G_DIM 64
#define PARTS 8
#define T_STEPS 200
#define ALPHA 0.25
#define NOISE_P 0.05
#define SEED 123456789
#define DT 0.05               /* passo temporal para evolução de psi */
#define COUPLING 0.12         /* força de acoplamento rho <- rho * (1 + COUPLING*influence) */
#define LAMBDA_PSI 0.8        /* peso da entropia de psi em H_total */

/* RNG xorshift32 */
static unsigned int rng_state = SEED;
unsigned int xorshift32() {
    unsigned int x = rng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_state = x;
    return x;
}
double rand01() { return (xorshift32() & 0xFFFFFF) / (double)0x1000000; }

/* utilitários */
void normalize(double *v, int n){
    double s=0.0;
    for(int i=0;i<n;i++) s += v[i]*v[i];
    if(s<=0) return;
    double norm = sqrt(s);
    for(int i=0;i<n;i++) v[i]/=norm;
}

/* construir H real simétrica */
void build_H(double H[H_DIM][H_DIM]) {
    for(int i=0;i<H_DIM;i++) for(int j=0;j<H_DIM;j++) H[i][j]=0.0;
    for(int i=0;i<H_DIM;i++){
        H[i][i] = 1.0 + 0.1 * (rand01()-0.5);
        if(i+1<H_DIM){
            double v = 0.2 * (rand01()-0.5);
            H[i][i+1] = v; H[i+1][i] = v;
        }
    }
    for(int k=0;k< H_DIM; k++){
        int i = xorshift32()%H_DIM;
        int j = xorshift32()%H_DIM;
        double v = 0.05*(rand01()-0.5);
        H[i][j]+=v; H[j][i]+=v;
    }
}

/* aplicar H (multiplicação) */
void apply_H(double H[H_DIM][H_DIM], double *in, double *out){
    for(int i=0;i<H_DIM;i++){
        double s=0.0;
        for(int j=0;j<H_DIM;j++) s += H[i][j]*in[j];
        out[i]=s;
    }
}

/* init estados */
void init_state(double *psiH, double *rhoG){
    for(int i=0;i<H_DIM;i++) psiH[i] = (rand01()-0.5);
    normalize(psiH,H_DIM);
    double sum=0.0;
    for(int i=0;i<G_DIM;i++){ rhoG[i] = 0.1 + 0.9*rand01(); sum += rhoG[i]; }
    for(int i=0;i<G_DIM;i++) rhoG[i] /= sum;
}

/* U_T: circular shift */
void apply_U_T(double *rho, double *out, int shift){
    for(int i=0;i<G_DIM;i++){
        int j = (i+shift) % G_DIM;
        out[j] = rho[i];
    }
}

/* D on G: reflection modular (involution) */
void apply_D_T(double *rho, double *out){
    for(int i=0;i<G_DIM;i++){
        int j = (G_DIM - i) % G_DIM;
        out[j] = rho[i];
    }
}

/* D on H: swap pairs (involution) */
void apply_D_H(double *psi, double *out){
    for(int i=0;i<H_DIM;i++) out[i]=0.0;
    for(int i=0;i<H_DIM;i+=2){
        if(i+1 < H_DIM){
            out[i]   = psi[i+1];
            out[i+1] = psi[i];
        } else out[i]=psi[i];
    }
}

/* correção C em G */
void apply_C_G(double *rho, double *rho_in, double *out){
    for(int i=0;i<G_DIM;i++) out[i] = (1.0-ALPHA)*rho[i] + ALPHA*rho_in[i];
}

/* ruído: mistura com uniforme */
void apply_noise(double *rho, double p){
    if(p<=0) return;
    double uniform = 1.0 / (double)G_DIM;
    for(int i=0;i<G_DIM;i++) rho[i] = (1.0-p)*rho[i] + p*uniform;
}

/* entropia Shannon */
double shannon_entropy(double *rho, int n){
    double H=0.0;
    for(int i=0;i<n;i++){
        double p = rho[i];
        if(p>0) H -= p * log(p);
    }
    return H;
}

/* entropia de psi via |psi|^2 */
double psi_entropy(double *psi){
    double p_sum=0.0;
    for(int i=0;i<H_DIM;i++) p_sum += psi[i]*psi[i];
    if(p_sum<=0) return 0.0;
    double H=0.0;
    for(int i=0;i<H_DIM;i++){
        double p = (psi[i]*psi[i]) / p_sum;
        if(p>0) H -= p * log(p);
    }
    return H;
}

/* entropias locais por partição */
void local_entropies(double *rho, double *Hloc){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double sum=0.0;
        for(int i=0;i<cell;i++) sum += rho[k*cell + i];
        if(sum<=0){ Hloc[k]=0.0; continue; }
        double H=0.0;
        for(int i=0;i<cell;i++){
            double p = rho[k*cell + i] / sum;
            if(p>0) H -= p * log(p);
        }
        Hloc[k] = H;
    }
}

/* SNR por partição */
void snr_per_partition(double *rho, double *snr){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double mean=0.0;
        for(int i=0;i<cell;i++) mean += rho[k*cell + i];
        mean /= cell;
        double var=0.0;
        for(int i=0;i<cell;i++){
            double d = rho[k*cell + i] - mean;
            var += d*d;
        }
        var /= cell;
        if(var<=1e-12) snr[k] = 1e6;
        else snr[k] = mean*mean / var;
    }
}

/* grava CSV */
void write_csv_timeseries(double *Hloc_ts, double *Hglob_ts, double *Hpsi_ts, double *Htotal_ts, int steps){
    FILE *f = fopen("rafael_timeseries_up.csv","w");
    if(!f) return;
    fprintf(f,"step,Hglob,Hpsi,Htotal");
    for(int k=0;k<PARTS;k++) fprintf(f,",Hloc_%d",k);
    fprintf(f,"\n");
    for(int t=0;t<steps;t++){
        fprintf(f,"%d,%.12f,%.12f,%.12f", t, Hglob_ts[t], Hpsi_ts[t], Htotal_ts[t]);
        for(int k=0;k<PARTS;k++) fprintf(f,",%.12f", Hloc_ts[t*PARTS + k]);
        fprintf(f,"\n");
    }
    fclose(f);
}

int main(){
    static double H[H_DIM][H_DIM];
    static double psi[H_DIM], psi_tmp[H_DIM];
    static double rho[G_DIM], rho_tmp[G_DIM], rho_in[G_DIM];
    static double Hloc[PARTS], snr[PARTS];
    double *Hloc_ts = (double*)malloc(sizeof(double)*T_STEPS*PARTS);
    double *Hglob_ts = (double*)malloc(sizeof(double)*T_STEPS);
    double *Hpsi_ts  = (double*)malloc(sizeof(double)*T_STEPS);
    double *Htotal_ts= (double*)malloc(sizeof(double)*T_STEPS);

    rng_state = SEED ^ (unsigned int)time(NULL);

    build_H(H);
    init_state(psi, rho);
    for(int i=0;i<G_DIM;i++) rho_in[i] = rho[i];
    normalize(psi,H_DIM);

    for(int t=0;t<T_STEPS;t++){
        /* 1) U_T */
        int shift = (t % (G_DIM/4)) + 1;
        apply_U_T(rho, rho_tmp, shift);

        /* 2) Dualidade combinada intermitente */
        if(t % 10 == 0){
            /* D on G then D on H */
            apply_D_T(rho_tmp, rho);
            apply_D_H(psi, psi_tmp);
            for(int i=0;i<H_DIM;i++) psi[i]=psi_tmp[i];
        } else {
            for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];
        }

        /* 3) Acoplamento H -> G: influencia de psi sobre rho */
        for(int i=0;i<G_DIM;i++){
            double influence = fabs(psi[i % H_DIM]); /* simples mapeamento */
            rho[i] *= (1.0 + COUPLING * influence);
        }
        /* renormaliza rho antes da correção */
        double sum=0.0;
        for(int i=0;i<G_DIM;i++) sum += rho[i];
        if(sum<=0) sum=1.0;
        for(int i=0;i<G_DIM;i++) rho[i] /= sum;

        /* 4) Correção C */
        apply_C_G(rho, rho_in, rho_tmp);

        /* 5) Ruído */
        apply_noise(rho_tmp, NOISE_P);

        /* 6) Renormaliza */
        sum=0.0;
        for(int i=0;i<G_DIM;i++) sum += rho_tmp[i];
        if(sum<=0) sum=1.0;
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i]/sum;

        /* 7) Evolução de psi com H (Euler explícito real) */
        apply_H(H, psi, psi_tmp);
        for(int i=0;i<H_DIM;i++){
            psi[i] = psi[i] - DT * psi_tmp[i]; /* simplificação: psi <- psi - dt * H psi */
        }
        normalize(psi,H_DIM);

        /* 8) medidas: entropias e SNR */
        double Hglob = shannon_entropy(rho, G_DIM);
        double Hpsi  = psi_entropy(psi);
        double Htotal = Hglob + LAMBDA_PSI * Hpsi;
        local_entropies(rho, Hloc);
        snr_per_partition(rho, snr);

        Hglob_ts[t] = Hglob;
        Hpsi_ts[t]  = Hpsi;
        Htotal_ts[t]= Htotal;
        for(int k=0;k<PARTS;k++) Hloc_ts[t*PARTS + k] = Hloc[k];

        if(t % 20 == 0){
            printf("step=%3d Hglob=%.6f Hpsi=%.6f Htotal=%.6f Hloc0=%.6f SNR0=%.3f\n",
                   t, Hglob, Hpsi, Htotal, Hloc[0], snr[0]);
        }
    }

    write_csv_timeseries(Hloc_ts, Hglob_ts, Hpsi_ts, Htotal_ts, T_STEPS);
    printf("Simulação completa. Arquivo gerado: rafael_timeseries_up.csv\n");
    printf("Parâmetros: H_DIM=%d G_DIM=%d PARTS=%d T_STEPS=%d ALPHA=%.2f NOISE_P=%.3f DT=%.3f COUPLING=%.3f LAMBDA_PSI=%.3f\n",
           H_DIM, G_DIM, PARTS, T_STEPS, ALPHA, NOISE_P, DT, COUPLING, LAMBDA_PSI);

    free(Hloc_ts); free(Hglob_ts); free(Hpsi_ts); free(Htotal_ts);
    return 0;
}
