import hashlib
import math
import time
import json
import os

# ================================
# 🌱 SEMENTE
# ================================
SEMENTE = "AΔBΩΔTTΦIIBΩΔΣΣRΩRΔΔBΦΦFΔTTRR"

# ================================
# 🔐 HASH REAL (SHA3-256)
# ================================
def gerar_hash(seed):
    return hashlib.sha3_256(seed.encode("utf-8")).hexdigest()

# ================================
# 💾 ESTADO
# ================================
def nome_arquivo(h):
    return f"estado_{h[:12]}.json"

def salvar_estado(h, estado):
    with open(nome_arquivo(h), "w") as f:
        json.dump(estado, f)

def carregar_estado(h):
    arq = nome_arquivo(h)
    if os.path.exists(arq):
        with open(arq, "r") as f:
            return json.load(f)
    return None

# ================================
# 🧬 DINÂMICA EXACORDEX (Q-LIKE)
# ================================
SQRT3_2 = math.sqrt(3) / 2
CONST = math.pi * math.sin(math.radians(279))

def passo(estado):
    novo = []
    for v in estado:
        x = (v * SQRT3_2 - CONST) % 1.0
        novo.append(x)
    return novo

# ================================
# 🧠 MÉTRICA (F_Love)
# ================================
def f_love(estado):
    m = sum(estado)/len(estado)
    var = sum((x-m)**2 for x in estado)/len(estado)
    return 1/(1+var)

# ================================
# ⚙️ INICIALIZAÇÃO
# ================================
hash_seed = gerar_hash(SEMENTE)
estado = carregar_estado(hash_seed)

if estado is None:
    print("🌱 Criando novo estado...")
    # gerar estado inicial a partir do hash
    estado = []
    for i in range(7):
        chunk = hash_seed[i*4:(i+1)*4]
        val = int(chunk, 16) / 65535
        estado.append(val)
else:
    print("🌳 Estado restaurado.")

# ================================
# 🔄 LOOP VIVO
# ================================
ciclo = 0

while True:
    estado = passo(estado)
    energia = f_love(estado)

    print(f"[{ciclo}] F_Love={energia:.6f}")

    salvar_estado(hash_seed, estado)

    ciclo += 1
    time.sleep(1)
