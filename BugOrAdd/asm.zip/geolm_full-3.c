/* ============================================================
   GEOLM_FULL.C — Consolidated Single-File Build
   Anterioridade / Context Header
   ============================================================
   HISTÓRICO DE ARQUITETURA:
     Java proof-of-concept → Rust rewrite → C/ASM (ARM32 Termux)
     Blocos B1..B5 consolidados + MÓDULO B6: coerência×contexto×prova

   AMBIENTE ALVO:
     Android 10, Termux, ARM32 (Cortex-A7), softfp ABI
     clang -O2 -mcpu=cortex-a7 -mfpu=neon-vfpv4 \
           -mfloat-abi=softfp -std=c11 geolm_full.c -lm -o geolm

   ARQUITETURA CROSS (32→64 bits):
     - Ponteiros: u32 (4B) em ARM32, u64 (8B) em AArch64/x86_64
     - FP: f32 (softfp) aqui; AArch64 usa FPU HW nativa
     - NEON ARM32: vld1q_f32 / vmlaq_f32 (128-bit SIMD)
     - NEON ARM64: mesma ISA + fma fused (mais eficiente)
     - x86_64: SSE/AVX equivalente; mesmo algoritmo, intrinsics diferentes
     - Macro ARCH_WORD abstrai tamanho de ponteiro para portabilidade

   RAF CYCLE (invariante do sistema):
     ψ(ler estado) → χ(retroalimentar) → ρ(expandir)
     → Δ(validar) → Σ(executar) → Ω(alinhar) → novo ψ

   MÓDULOS:
     B1: Arena (64MB estático), Vocab (hash aberto), Tokenizer
     B2: EmbedTable (pos_enc sinusoidal), MHA (4 cabeças, HEAD_DIM=16)
     B3: FFN (relu), TransformerLayer (2 camadas), CrossEntropy
     B4: TinyModel bigram + SGD + fetch HTTP (wget/curl) + JSON extract
     B5: CLI REPL, save/load binário (magic GLM1)
     B6: ContextBuffer, CoerenceScore (cosine), ProofLayer (CRC32+entropy)
            RAF ψχρΔΣΩ cycle, ToroidalState 7D, AttractorPool 42

   MATEMÁTICA NÚCLEO:
     s ∈ T^7 = (R/Z)^7         — espaço de estados toroidal
     C_{t+1} = (1-α)C_t + αC_in — EMA coerência (α=0.25)
     H_{t+1} = (1-α)H_t + αH_in — EMA entropia
     φ = (1-H)·C               — qualidade de estado
     Spiral(n) = (√3/2)^n      — sequência Rafaelia
     F_{n+1} = F_n·(√3/2) - π·sin(279°) — recorrência mod 42
     CRC32C poly=0x82F63B78    — integridade
     FNV-1a  mult=0x100000001B3 — hash rápido
     Cohesion = cos(θ(h_t, C_mean)) — prova de coerência

   HIERARQUIA DE MEMÓRIA ARM32:
     registradores (r0-r15, s0-s31) — 0 ciclos
     L1 D-cache 32KB 4-way — ~4 ciclos
     L2 unified 256KB-1MB  — ~12 ciclos
     RAM LPDDR3             — ~60 ciclos
     Storage (eMMC)         — ~50.000 ciclos
     Arena estática 64MB evita malloc/free e fragmentação.

   PARALELISMO (single-core Cortex-A7):
     NEON 128-bit: 4×f32 por instrução
     Pipeline duplo: 2 instruções/ciclo (Cortex-A7 in-order)
     Loop unroll ×4: amortiza branch overhead
     Prefetch: __builtin_prefetch para sequências longas

   PRIMOS / DIVISORES:
     Vocab hash: DJB2 (primo implícito via Horner)
     Arena align: pot-de-2 (mask trick, sem divisão)
     Toroidal stride: gcd(Δr,R)=1, gcd(Δc,C)=1 (Bezout)
     42 atratores: período da recorrência Fibonacci-Rafael

   CONVERGÊNCIA:
     Transformer (B3): loss converge via gradient descent estocástico
     TinyModel (B4): bigram converge em ~50 épocas, texto pequeno
     CoherenceProof (B6): φ→1 indica estado estável no toro
   ============================================================ */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

/* ============================================================
   TIPOS E MACROS GLOBAIS
   ============================================================ */
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;
typedef float    f32;

/* portabilidade 32→64: ARCH_WORD é o tipo nativo de ponteiro */
#if defined(__LP64__) || defined(_LP64)
typedef uint64_t uword;
#else
typedef uint32_t uword;
#endif

#define VOCAB_MAX       8192
#define TOKEN_LEN_MAX     32
#define EMBED_DIM         64
#define SEQ_LEN           64
#define HIDDEN_DIM       128
#define N_HEADS             4
#define HEAD_DIM           16
#define N_LAYERS            2
#define ARENA_MB           64
#define ARENA_BYTES        (ARENA_MB * 1024 * 1024)
#define TEXT_BUF_SIZE      (2 * 1024 * 1024)

/* B6 constants */
#define CTX_BUF_LEN        64    /* janela de contexto */
#define ATTRACTOR_N        42    /* atratores do sistema */
#define TORUS_DIM           7    /* dimensão do toro */
#define RAF_CYCLE_LEN       6    /* ψ χ ρ Δ Σ Ω */
#define CRC32C_POLY  0x82F63B78u
#define FNV_MULT     0x100000001B3ull
#define FNV_INIT     0xCBF29CE484222325ull
#define SPIRAL_F32   0.86602540378f   /* sqrt(3)/2 */
#define PHI_F32      1.61803398875f   /* golden ratio */
#define SIN279_PI_F32 (-0.06279052f)  /* π·sin(279°) */
#define ALPHA_EMA    0.25f

#define ALIGNED64  __attribute__((aligned(64)))
#define ALIGNED16  __attribute__((aligned(16)))
#define FORCE_INLINE __attribute__((always_inline)) static inline
#define NO_INLINE    __attribute__((noinline))

#define GLM_OK   0
#define GLM_ERR -1
#define GLM_OOM -2

/* ANSI cores */
#define CYN "\033[36m"
#define YEL "\033[33m"
#define GRN "\033[32m"
#define RED "\033[31m"
#define MAG "\033[35m"
#define RST "\033[0m"
#define BLD "\033[1m"

/* ============================================================
   B1 — ARENA ALLOCATOR
   64MB estático, bump pointer, alinhamento configurável
   Sem malloc/free — zero fragmentação
   ============================================================ */
static u8 ALIGNED64 g_arena_buf[ARENA_BYTES];

typedef struct {
    u8  *base;
    u32  cap;
    u32  bump;
    u32  n_alloc;
    u32  peak;
} Arena;

static Arena g_arena;

static void arena_init(Arena *a) {
    a->base    = g_arena_buf;
    a->cap     = ARENA_BYTES;
    a->bump    = 0;
    a->n_alloc = 0;
    a->peak    = 0;
    memset(g_arena_buf, 0, ARENA_BYTES);
}

FORCE_INLINE void *arena_alloc(Arena *a, u32 n, u32 align) {
    u32 mask  = align - 1u;
    u32 start = (a->bump + mask) & ~mask;
    u32 end   = start + n;
    if (end > a->cap) return NULL;
    a->bump    = end;
    a->n_alloc++;
    if (end > a->peak) a->peak = end;
    return a->base + start;
}

FORCE_INLINE u32  arena_save(const Arena *a)        { return a->bump; }
FORCE_INLINE void arena_restore(Arena *a, u32 mark) { a->bump = mark; }

static void arena_stats(const Arena *a) {
    printf("[arena] used=%uKB peak=%uKB cap=%uMB allocs=%u\n",
           a->bump/1024, a->peak/1024, a->cap/(1024*1024), a->n_alloc);
}

#define ALLOC(T,n)    ((T*)arena_alloc(&g_arena,(u32)(sizeof(T)*(n)),16u))
#define ALLOC64(T,n)  ((T*)arena_alloc(&g_arena,(u32)(sizeof(T)*(n)),64u))

/* ============================================================
   B1 — VOCAB (hash aberto, DJB2, linear probing)
   ============================================================ */
typedef struct {
    char str[TOKEN_LEN_MAX];
    u32  id;
    u32  freq;
    u8   used;
    u8   _pad[3];
} VocabEntry;

typedef struct {
    VocabEntry *entries;
    u32         size;
    u32         cap;
    u32 id_unk, id_bos, id_eos, id_pad;
} Vocab;

FORCE_INLINE u32 vocab_hash(const char *s, u32 cap) {
    u32 h = 5381u;
    while (*s) h = ((h << 5) + h) ^ (u8)*s++;
    return h % cap;
}

static i32 vocab_init(Vocab *v) {
    v->entries = ALLOC64(VocabEntry, VOCAB_MAX);
    if (!v->entries) return GLM_OOM;
    memset(v->entries, 0, sizeof(VocabEntry) * VOCAB_MAX);
    v->size = 0; v->cap = VOCAB_MAX;
    v->id_pad=0; v->id_unk=1; v->id_bos=2; v->id_eos=3;
    const char *sp[] = {"<pad>","<unk>","<bos>","<eos>",NULL};
    for (i32 i=0; sp[i]; i++) {
        u32 h = vocab_hash(sp[i], VOCAB_MAX);
        strncpy(v->entries[h].str, sp[i], TOKEN_LEN_MAX-1);
        v->entries[h].id   = (u32)i;
        v->entries[h].freq = 0;
        v->entries[h].used = 1;
        v->size++;
    }
    return GLM_OK;
}

static u32 vocab_insert(Vocab *v, const char *s) {
    if (v->size >= v->cap-1) return v->id_unk;
    u32 h = vocab_hash(s, v->cap);
    for (u32 p=0; p<v->cap; p++) {
        VocabEntry *e = &v->entries[h];
        if (!e->used) {
            strncpy(e->str, s, TOKEN_LEN_MAX-1);
            e->id=v->size++; e->freq=1; e->used=1;
            return e->id;
        }
        if (strncmp(e->str, s, TOKEN_LEN_MAX)==0) { e->freq++; return e->id; }
        h = (h+1) % v->cap;
    }
    return v->id_unk;
}

static u32 vocab_lookup(const Vocab *v, const char *s) {
    u32 h = vocab_hash(s, v->cap);
    for (u32 p=0; p<v->cap; p++) {
        const VocabEntry *e = &v->entries[h];
        if (!e->used) return v->id_unk;
        if (strncmp(e->str, s, TOKEN_LEN_MAX)==0) return e->id;
        h = (h+1) % v->cap;
    }
    return v->id_unk;
}

static const char *vocab_str(const Vocab *v, u32 id) {
    for (u32 i=0; i<v->cap; i++)
        if (v->entries[i].used && v->entries[i].id==id)
            return v->entries[i].str;
    return "<unk>";
}

/* ============================================================
   B1 — TOKENIZER (whitespace split + punct isolation)
   ============================================================ */
FORCE_INLINE u8 tok_norm(u8 c) {
    return (c>='A' && c<='Z') ? c+32u : c;
}
FORCE_INLINE i32 tok_sep(u8 c) {
    return c==' '||c=='\t'||c=='\n'||c=='\r';
}
FORCE_INLINE i32 tok_punct(u8 c) {
    return c=='.'||c==','||c==';'||c==':'||c=='!'||c=='?'||
           c=='"'||c=='\''||c=='('||c==')'||c=='-'||c=='/';
}

static u32 tokenize(Vocab *v, const char *text, u32 len,
                    u32 *ids, u32 max_ids) {
    char buf[TOKEN_LEN_MAX]; u32 bp=0, n=0;
#define EMIT() do { \
    if(bp>0&&n<max_ids){buf[bp]=0;ids[n++]=vocab_insert(v,buf);bp=0;} \
} while(0)
    for (u32 i=0; i<len && n<max_ids; i++) {
        u8 c = tok_norm((u8)text[i]);
        if (tok_sep(c))   { EMIT(); continue; }
        if (tok_punct(c)) {
            EMIT();
            if (n<max_ids) { buf[0]=(char)c; buf[1]=0; ids[n++]=vocab_insert(v,buf); }
            continue;
        }
        if (bp<TOKEN_LEN_MAX-1) buf[bp++]=(char)c;
        else { EMIT(); buf[bp++]=(char)c; }
    }
    EMIT();
#undef EMIT
    return n;
}

/* ============================================================
   B2 — MATH PRIMITIVES
   ============================================================ */
FORCE_INLINE f32 fast_expf(f32 x) {
    if (x>10.f) return 22026.f;
    if (x<-10.f) return 4.54e-5f;
    f32 x2=x*x, x3=x2*x, x4=x3*x;
    return 1.f+x+x2*.5f+x3*.16667f+x4*.04167f;
}

static void softmax_f32(f32 *v, u32 n) {
    f32 mx=v[0];
    for(u32 i=1;i<n;i++) if(v[i]>mx) mx=v[i];
    f32 s=0;
    for(u32 i=0;i<n;i++){v[i]=fast_expf(v[i]-mx);s+=v[i];}
    f32 inv=s>1e-9f?1.f/s:0;
    for(u32 i=0;i<n;i++) v[i]*=inv;
}

FORCE_INLINE f32 reluf(f32 x) { return x>0.f?x:0.f; }

FORCE_INLINE f32 dot_f32(const f32 *a, const f32 *b, u32 d) {
    f32 s0=0,s1=0,s2=0,s3=0; u32 i=0;
    for(;i+3<d;i+=4){s0+=a[i]*b[i];s1+=a[i+1]*b[i+1];
                      s2+=a[i+2]*b[i+2];s3+=a[i+3]*b[i+3];}
    for(;i<d;i++) s0+=a[i]*b[i];
    return s0+s1+s2+s3;
}

FORCE_INLINE void vec_zero(f32 *v, u32 d) { memset(v,0,d*sizeof(f32)); }
FORCE_INLINE void vec_copy(f32 *dst, const f32 *src, u32 d) {
    memcpy(dst,src,d*sizeof(f32));
}

FORCE_INLINE f32 vec_norm(const f32 *v, u32 d) {
    f32 s=0; for(u32 i=0;i<d;i++) s+=v[i]*v[i];
    return sqrtf(s+1e-9f);
}

/* cosine similarity */
FORCE_INLINE f32 cosine_sim(const f32 *a, const f32 *b, u32 d) {
    f32 ab=dot_f32(a,b,d);
    f32 na=vec_norm(a,d), nb=vec_norm(b,d);
    return (na>1e-9f && nb>1e-9f) ? ab/(na*nb) : 0.f;
}

static void layer_norm(f32 *o, const f32 *x,
                        const f32 *g, const f32 *b, u32 d) {
    f32 m=0,v=0;
    for(u32 i=0;i<d;i++) m+=x[i];
    m/=d;
    for(u32 i=0;i<d;i++){f32 diff=x[i]-m;v+=diff*diff;}
    v/=d; f32 is=1.f/sqrtf(v+1e-5f);
    for(u32 i=0;i<d;i++) o[i]=(x[i]-m)*is*g[i]+b[i];
}

static void matmul_seq(f32 *o, const f32 *in, const f32 *W,
                        u32 sl, u32 id, u32 od) {
    for(u32 s=0;s<sl;s++){
        const f32 *ri=in+s*id; f32 *ro=o+s*od;
        vec_zero(ro,od);
        for(u32 i=0;i<id;i++){
            const f32 *Wr=W+i*od; f32 xi=ri[i];
            u32 j=0;
            for(;j+3<od;j+=4){ro[j]+=xi*Wr[j];ro[j+1]+=xi*Wr[j+1];
                                ro[j+2]+=xi*Wr[j+2];ro[j+3]+=xi*Wr[j+3];}
            for(;j<od;j++) ro[j]+=xi*Wr[j];
        }
    }
}

/* ============================================================
   B2 — EMBEDDINGS + POSITIONAL ENCODING
   ============================================================ */
typedef struct {
    f32 ALIGNED64 weight[VOCAB_MAX][EMBED_DIM];
    f32 ALIGNED64 pos_enc[SEQ_LEN][EMBED_DIM];
    u32 vocab_size, dim;
} EmbedTable;

static void embed_init(EmbedTable *e, u32 vocab_size) {
    e->vocab_size=vocab_size; e->dim=EMBED_DIM;
    f32 scale=1.f/sqrtf((f32)EMBED_DIM);
    u32 rng=0x52414641u;
    for(u32 v=0;v<vocab_size;v++)
        for(u32 d=0;d<EMBED_DIM;d++){
            rng=rng*1664525u+1013904223u;
            e->weight[v][d]=((f32)(i32)rng)/2147483648.f*scale;
        }
    for(u32 p=0;p<SEQ_LEN;p++)
        for(u32 i=0;i<EMBED_DIM;i+=2){
            f32 freq=1.f/powf(10000.f,(f32)i/(f32)EMBED_DIM);
            e->pos_enc[p][i]=sinf((f32)p*freq);
            e->pos_enc[p][i+1]=cosf((f32)p*freq);
        }
}

static void embed_forward(const EmbedTable *e, const u32 *ids,
                           u32 seq_len, f32 *out) {
    for(u32 p=0;p<seq_len;p++){
        u32 tid=ids[p]; if(tid>=e->vocab_size) tid=1;
        f32 *row=out+p*EMBED_DIM;
        const f32 *emb=e->weight[tid];
        const f32 *pos=e->pos_enc[p];
        u32 d=0;
        for(;d+3<EMBED_DIM;d+=4){
            row[d]=emb[d]+pos[d]; row[d+1]=emb[d+1]+pos[d+1];
            row[d+2]=emb[d+2]+pos[d+2]; row[d+3]=emb[d+3]+pos[d+3];
        }
        for(;d<EMBED_DIM;d++) row[d]=emb[d]+pos[d];
    }
}

/* ============================================================
   B2 — MULTI-HEAD ATTENTION (4 heads, HEAD_DIM=16, causal mask)
   ============================================================ */
typedef struct {
    f32 ALIGNED64 Wq[N_HEADS][EMBED_DIM][HEAD_DIM];
    f32 ALIGNED64 Wk[N_HEADS][EMBED_DIM][HEAD_DIM];
    f32 ALIGNED64 Wv[N_HEADS][EMBED_DIM][HEAD_DIM];
    f32 ALIGNED64 Wo[EMBED_DIM][EMBED_DIM];
    f32 ALIGNED16 Q[N_HEADS][SEQ_LEN][HEAD_DIM];
    f32 ALIGNED16 K[N_HEADS][SEQ_LEN][HEAD_DIM];
    f32 ALIGNED16 V[N_HEADS][SEQ_LEN][HEAD_DIM];
    f32 ALIGNED16 scores[N_HEADS][SEQ_LEN][SEQ_LEN];
    f32 ALIGNED16 attn_out[SEQ_LEN][EMBED_DIM];
} MHALayer;

static void mha_init(MHALayer *m) {
    u32 rng=0x4D484100u;
    f32 sq=1.f/sqrtf((f32)EMBED_DIM);
    f32 so=1.f/sqrtf((f32)(N_HEADS*HEAD_DIM));
    for(u32 h=0;h<N_HEADS;h++)
        for(u32 i=0;i<EMBED_DIM;i++)
            for(u32 j=0;j<HEAD_DIM;j++){
                rng=rng*1664525u+1013904223u;
                m->Wq[h][i][j]=((f32)(i32)rng)/2147483648.f*sq;
                rng=rng*1664525u+1013904223u;
                m->Wk[h][i][j]=((f32)(i32)rng)/2147483648.f*sq;
                rng=rng*1664525u+1013904223u;
                m->Wv[h][i][j]=((f32)(i32)rng)/2147483648.f*sq;
            }
    for(u32 i=0;i<EMBED_DIM;i++)
        for(u32 j=0;j<EMBED_DIM;j++){
            rng=rng*1664525u+1013904223u;
            m->Wo[i][j]=((f32)(i32)rng)/2147483648.f*so;
        }
}

static void mha_forward(MHALayer *m, const f32 *x, f32 *out, u32 sl) {
    f32 scale=1.f/sqrtf((f32)HEAD_DIM);
    for(u32 h=0;h<N_HEADS;h++){
        matmul_seq(&m->Q[h][0][0],x,&m->Wq[h][0][0],sl,EMBED_DIM,HEAD_DIM);
        matmul_seq(&m->K[h][0][0],x,&m->Wk[h][0][0],sl,EMBED_DIM,HEAD_DIM);
        matmul_seq(&m->V[h][0][0],x,&m->Wv[h][0][0],sl,EMBED_DIM,HEAD_DIM);
        for(u32 i=0;i<sl;i++){
            for(u32 j=0;j<sl;j++)
                m->scores[h][i][j]=(j>i)?-1e9f:
                    dot_f32(m->Q[h][i],m->K[h][j],HEAD_DIM)*scale;
            softmax_f32(m->scores[h][i],sl);
        }
        for(u32 i=0;i<sl;i++){
            f32 *slot=&m->attn_out[i][h*HEAD_DIM];
            vec_zero(slot,HEAD_DIM);
            for(u32 j=0;j<sl;j++){
                f32 a=m->scores[h][i][j];
                const f32 *vj=m->V[h][j];
                u32 d=0;
                for(;d+3<HEAD_DIM;d+=4){slot[d]+=a*vj[d];slot[d+1]+=a*vj[d+1];
                                         slot[d+2]+=a*vj[d+2];slot[d+3]+=a*vj[d+3];}
                for(;d<HEAD_DIM;d++) slot[d]+=a*vj[d];
            }
        }
    }
    matmul_seq(out,&m->attn_out[0][0],&m->Wo[0][0],sl,EMBED_DIM,EMBED_DIM);
}

/* ============================================================
   B3 — FFN (EMBED→HIDDEN→EMBED, ReLU)
   ============================================================ */
typedef struct {
    f32 ALIGNED64 W1[EMBED_DIM][HIDDEN_DIM];
    f32 ALIGNED64 W2[HIDDEN_DIM][EMBED_DIM];
    f32 ALIGNED16 b1[HIDDEN_DIM];
    f32 ALIGNED16 b2[EMBED_DIM];
    f32 ALIGNED16 ln_g[EMBED_DIM];
    f32 ALIGNED16 ln_b[EMBED_DIM];
    f32 ALIGNED16 buf[SEQ_LEN][HIDDEN_DIM];
} FFNLayer;

static void ffn_init(FFNLayer *f) {
    u32 rng=0x46464E00u;
    f32 s1=1.f/sqrtf((f32)EMBED_DIM), s2=1.f/sqrtf((f32)HIDDEN_DIM);
    for(u32 i=0;i<EMBED_DIM;i++)
        for(u32 j=0;j<HIDDEN_DIM;j++){rng=rng*1664525u+1013904223u;
            f->W1[i][j]=((f32)(i32)rng)/2147483648.f*s1;}
    for(u32 i=0;i<HIDDEN_DIM;i++)
        for(u32 j=0;j<EMBED_DIM;j++){rng=rng*1664525u+1013904223u;
            f->W2[i][j]=((f32)(i32)rng)/2147483648.f*s2;}
    memset(f->b1,0,sizeof(f->b1)); memset(f->b2,0,sizeof(f->b2));
    for(u32 i=0;i<EMBED_DIM;i++){f->ln_g[i]=1.f;f->ln_b[i]=0.f;}
}

static void ffn_forward(FFNLayer *f, const f32 *x, f32 *out, u32 sl) {
    matmul_seq(&f->buf[0][0],x,&f->W1[0][0],sl,EMBED_DIM,HIDDEN_DIM);
    for(u32 s=0;s<sl;s++){
        f32 *row=f->buf[s];
        for(u32 j=0;j<HIDDEN_DIM;j++) row[j]=reluf(row[j]+f->b1[j]);
    }
    matmul_seq(out,&f->buf[0][0],&f->W2[0][0],sl,HIDDEN_DIM,EMBED_DIM);
    for(u32 s=0;s<sl;s++){
        f32 *row=out+s*EMBED_DIM;
        for(u32 j=0;j<EMBED_DIM;j++) row[j]+=f->b2[j];
    }
}

/* ============================================================
   B3 — TRANSFORMER LAYER (LN→MHA→residual→LN→FFN→residual)
   ============================================================ */
typedef struct {
    f32 ALIGNED64 Wq[EMBED_DIM][EMBED_DIM];
    f32 ALIGNED64 Wk[EMBED_DIM][EMBED_DIM];
    f32 ALIGNED64 Wv[EMBED_DIM][EMBED_DIM];
    f32 ALIGNED64 Wo[EMBED_DIM][EMBED_DIM];
    FFNLayer ffn;
    f32 ALIGNED16 ln1_g[EMBED_DIM], ln1_b[EMBED_DIM];
    f32 ALIGNED16 ln2_g[EMBED_DIM], ln2_b[EMBED_DIM];
    f32 ALIGNED16 lno[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 mha[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 ffno[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 Q[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 K[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 V[SEQ_LEN][EMBED_DIM];
    f32 ALIGNED16 sc[SEQ_LEN][SEQ_LEN];
} TLayer;

static void tlayer_init(TLayer *l) {
    u32 rng=0x544C0000u;
    f32 s=1.f/sqrtf((f32)EMBED_DIM);
    f32 *ws[]={&l->Wq[0][0],&l->Wk[0][0],&l->Wv[0][0],&l->Wo[0][0],NULL};
    for(u32 p=0;ws[p];p++){
        f32 *W=ws[p];
        for(u32 i=0;i<EMBED_DIM*EMBED_DIM;i++){
            rng=rng*1664525u+1013904223u;
            W[i]=((f32)(i32)rng)/2147483648.f*s;
        }
    }
    for(u32 i=0;i<EMBED_DIM;i++){
        l->ln1_g[i]=1.f;l->ln1_b[i]=0.f;
        l->ln2_g[i]=1.f;l->ln2_b[i]=0.f;
    }
    ffn_init(&l->ffn);
}

static void tlayer_forward(TLayer *l, const f32 *x, f32 *out, u32 sl) {
    f32 scale=1.f/sqrtf((f32)EMBED_DIM);
    for(u32 s=0;s<sl;s++)
        layer_norm(l->lno[s],x+s*EMBED_DIM,l->ln1_g,l->ln1_b,EMBED_DIM);
    matmul_seq(&l->Q[0][0],&l->lno[0][0],&l->Wq[0][0],sl,EMBED_DIM,EMBED_DIM);
    matmul_seq(&l->K[0][0],&l->lno[0][0],&l->Wk[0][0],sl,EMBED_DIM,EMBED_DIM);
    matmul_seq(&l->V[0][0],&l->lno[0][0],&l->Wv[0][0],sl,EMBED_DIM,EMBED_DIM);
    for(u32 i=0;i<sl;i++){
        for(u32 j=0;j<sl;j++)
            l->sc[i][j]=(j>i)?-1e9f:dot_f32(l->Q[i],l->K[j],EMBED_DIM)*scale;
        softmax_f32(l->sc[i],sl);
    }
    for(u32 i=0;i<sl;i++){
        f32 *ao=l->mha[i]; vec_zero(ao,EMBED_DIM);
        for(u32 j=0;j<sl;j++){
            f32 a=l->sc[i][j]; const f32 *vj=l->V[j];
            u32 d=0;
            for(;d+3<EMBED_DIM;d+=4){ao[d]+=a*vj[d];ao[d+1]+=a*vj[d+1];
                                       ao[d+2]+=a*vj[d+2];ao[d+3]+=a*vj[d+3];}
            for(;d<EMBED_DIM;d++) ao[d]+=a*vj[d];
        }
    }
    matmul_seq(&l->ffno[0][0],&l->mha[0][0],&l->Wo[0][0],sl,EMBED_DIM,EMBED_DIM);
    for(u32 s=0;s<sl;s++){
        f32 *r=l->ffno[s]; const f32 *xi=x+s*EMBED_DIM;
        for(u32 d=0;d<EMBED_DIM;d++) r[d]+=xi[d];
    }
    for(u32 s=0;s<sl;s++)
        layer_norm(l->lno[s],l->ffno[s],l->ln2_g,l->ln2_b,EMBED_DIM);
    ffn_forward(&l->ffn,&l->lno[0][0],&l->mha[0][0],sl);
    for(u32 s=0;s<sl;s++){
        f32 *r=out+s*EMBED_DIM;
        const f32 *a=l->ffno[s], *b=l->mha[s];
        for(u32 d=0;d<EMBED_DIM;d++) r[d]=a[d]+b[d];
    }
}

/* ============================================================
   B3 — LM HEAD + CROSS-ENTROPY
   ============================================================ */
typedef struct {
    f32 ALIGNED64 W[EMBED_DIM][VOCAB_MAX];
    f32 ALIGNED16 b[VOCAB_MAX];
    u32 vocab_size;
} LMHead;

static void lmhead_init(LMHead *h, u32 vsz) {
    h->vocab_size=vsz;
    u32 rng=0x484F4400u; f32 s=1.f/sqrtf((f32)EMBED_DIM);
    for(u32 i=0;i<EMBED_DIM;i++)
        for(u32 j=0;j<vsz;j++){rng=rng*1664525u+1013904223u;
            h->W[i][j]=((f32)(i32)rng)/2147483648.f*s;}
    memset(h->b,0,vsz*sizeof(f32));
}

static void lmhead_logits(const LMHead *h, const f32 *last, f32 *logits) {
    for(u32 j=0;j<h->vocab_size;j++){
        f32 s=h->b[j];
        for(u32 i=0;i<EMBED_DIM;i++) s+=last[i]*h->W[i][j];
        logits[j]=s;
    }
}

/* ============================================================
   B4/B5 — TINY MODEL (bigram, full backprop, train+generate)
   ============================================================ */
typedef struct {
    f32 ALIGNED64 embed[VOCAB_MAX][EMBED_DIM];
    f32 ALIGNED64 head_W[EMBED_DIM][VOCAB_MAX];
    f32 ALIGNED16 head_b[VOCAB_MAX];
    u32 vocab_size;
    u32 step;
    f32 best_loss;
    f32 last_loss;
} TinyModel;

static TinyModel *tiny_new(u32 vsz) {
    TinyModel *m=ALLOC64(TinyModel,1); if(!m) return NULL;
    m->vocab_size=vsz; m->step=0; m->best_loss=1e9f; m->last_loss=0.f;
    u32 rng=0x544D0000u; f32 s=1.f/sqrtf((f32)EMBED_DIM);
    for(u32 v=0;v<vsz;v++)
        for(u32 d=0;d<EMBED_DIM;d++){rng=rng*1664525u+1013904223u;
            m->embed[v][d]=((f32)(i32)rng)/2147483648.f*s;}
    for(u32 i=0;i<EMBED_DIM;i++)
        for(u32 j=0;j<vsz;j++){rng=rng*1664525u+1013904223u;
            m->head_W[i][j]=((f32)(i32)rng)/2147483648.f*s;}
    memset(m->head_b,0,vsz*sizeof(f32));
    return m;
}

/* forward + backward bigram step, retorna loss */
static f32 tiny_step(TinyModel *m, u32 ctx, u32 tgt,
                      f32 *logbuf, f32 lr) {
    if(ctx>=m->vocab_size||tgt>=m->vocab_size) return 0.f;
    f32 *emb=m->embed[ctx];
    /* forward */
    for(u32 j=0;j<m->vocab_size;j++){
        f32 s=m->head_b[j];
        for(u32 i=0;i<EMBED_DIM;i++) s+=m->head_W[i][j]*emb[i];
        logbuf[j]=s;
    }
    f32 mx=logbuf[0];
    for(u32 j=1;j<m->vocab_size;j++) if(logbuf[j]>mx) mx=logbuf[j];
    f32 sum=0;
    for(u32 j=0;j<m->vocab_size;j++){logbuf[j]=fast_expf(logbuf[j]-mx);sum+=logbuf[j];}
    f32 inv=sum>1e-9f?1.f/sum:0;
    for(u32 j=0;j<m->vocab_size;j++) logbuf[j]*=inv;
    f32 loss=-logf(logbuf[tgt]+1e-9f);
    /* backward */
    static f32 ALIGNED16 dL[VOCAB_MAX];
    for(u32 j=0;j<m->vocab_size;j++) dL[j]=logbuf[j]-(j==tgt?1.f:0.f);
    for(u32 i=0;i<EMBED_DIM;i++){
        f32 ei=emb[i];
        for(u32 j=0;j<m->vocab_size;j++) m->head_W[i][j]-=lr*dL[j]*ei;
    }
    for(u32 j=0;j<m->vocab_size;j++) m->head_b[j]-=lr*dL[j];
    for(u32 i=0;i<EMBED_DIM;i++){
        f32 g=0;
        for(u32 j=0;j<m->vocab_size;j++) g+=m->head_W[i][j]*dL[j];
        emb[i]-=lr*g;
    }
    m->step++;
    return loss;
}

static void tiny_train(TinyModel *m, const u32 *ids, u32 n,
                        u32 epochs, f32 lr) {
    static f32 ALIGNED16 logbuf[VOCAB_MAX];
    struct timespec t0,t1; clock_gettime(CLOCK_MONOTONIC,&t0);
    printf(BLD "[train] tokens=%u epochs=%u lr=%.5f vocab=%u\n" RST,
           n, epochs, lr, m->vocab_size);
    for(u32 ep=0;ep<epochs;ep++){
        f32 tot=0; u32 cnt=0;
        for(u32 i=0;i+1<n;i++){tot+=tiny_step(m,ids[i],ids[i+1],logbuf,lr);cnt++;}
        f32 loss=tot/(f32)(cnt?cnt:1);
        m->last_loss=loss;
        if(loss<m->best_loss) m->best_loss=loss;
        if(ep%10==0||ep==epochs-1){
            clock_gettime(CLOCK_MONOTONIC,&t1);
            f64 el=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)*1e-9;
            printf("  ep=%3u loss=" YEL "%.4f" RST " best=%.4f %.1fs\n",
                   ep,loss,m->best_loss,el);
        }
    }
}

static void tiny_generate(TinyModel *m, const Vocab *v,
                            u32 start, u32 ngen, f32 temp) {
    static f32 ALIGNED16 logbuf[VOCAB_MAX];
    u32 cur=start; u32 rng=(u32)time(NULL);
    printf(GRN "[gen] " RST);
    for(u32 i=0;i<ngen;i++){
        for(u32 j=0;j<m->vocab_size;j++){
            f32 s=m->head_b[j];
            for(u32 d=0;d<EMBED_DIM;d++) s+=m->head_W[d][j]*m->embed[cur][d];
            logbuf[j]=s/temp;
        }
        f32 mx=logbuf[0];
        for(u32 j=1;j<m->vocab_size;j++) if(logbuf[j]>mx) mx=logbuf[j];
        f32 sum=0;
        for(u32 j=0;j<m->vocab_size;j++){logbuf[j]=fast_expf(logbuf[j]-mx);sum+=logbuf[j];}
        rng=rng*1664525u+1013904223u;
        f32 r=((f32)(rng>>1))/2147483647.f*sum;
        u32 sam=0; f32 acc=0;
        for(u32 j=0;j<m->vocab_size;j++){acc+=logbuf[j];if(acc>=r){sam=j;break;}}
        printf("%s ",vocab_str(v,sam));
        cur=sam;
        if(cur==v->id_eos) break;
    }
    printf("\n");
}

/* ============================================================
   B5 — SAVE/LOAD (magic GLM1, binário portável)
   ============================================================ */
#define MODEL_MAGIC 0x474C4D31u

typedef struct {
    u32 magic, vocab_size, step, embed_dim;
    f32 best_loss;
    u32 _pad[3];
} ModelHeader;

static i32 model_save(const TinyModel *m, const Vocab *v,
                       const char *path) {
    FILE *fp=fopen(path,"wb"); if(!fp) return GLM_ERR;
    ModelHeader hdr={MODEL_MAGIC,m->vocab_size,m->step,EMBED_DIM,
                     m->best_loss,{0,0,0}};
    fwrite(&hdr,sizeof(hdr),1,fp);
    fwrite(m->embed,sizeof(f32),m->vocab_size*EMBED_DIM,fp);
    fwrite(m->head_W,sizeof(f32),EMBED_DIM*m->vocab_size,fp);
    fwrite(m->head_b,sizeof(f32),m->vocab_size,fp);
    if(v){fwrite(&v->size,sizeof(u32),1,fp);fwrite(v->entries,sizeof(VocabEntry),v->cap,fp);}
    fclose(fp);
    printf("[save] %s vocab=%u step=%u loss=%.4f\n",
           path,m->vocab_size,m->step,m->best_loss);
    return GLM_OK;
}

static i32 model_load(TinyModel *m, Vocab *v, const char *path) {
    FILE *fp=fopen(path,"rb"); if(!fp) return GLM_ERR;
    ModelHeader hdr; fread(&hdr,sizeof(hdr),1,fp);
    if(hdr.magic!=MODEL_MAGIC||hdr.embed_dim!=EMBED_DIM){fclose(fp);return GLM_ERR;}
    m->vocab_size=hdr.vocab_size; m->step=hdr.step; m->best_loss=hdr.best_loss;
    fread(m->embed,sizeof(f32),m->vocab_size*EMBED_DIM,fp);
    fread(m->head_W,sizeof(f32),EMBED_DIM*m->vocab_size,fp);
    fread(m->head_b,sizeof(f32),m->vocab_size,fp);
    if(v){fread(&v->size,sizeof(u32),1,fp);fread(v->entries,sizeof(VocabEntry),v->cap,fp);}
    fclose(fp);
    printf("[load] %s vocab=%u step=%u loss=%.4f\n",
           path,m->vocab_size,m->step,m->best_loss);
    return GLM_OK;
}

/* ============================================================
   B4 — FETCH HTTP (wget/curl via popen) + JSON extract
   ============================================================ */
static char g_textbuf[TEXT_BUF_SIZE];

static i32 fetch_url(const char *url, char *buf, u32 bsz, u32 *olen) {
    char cmd[512];
    snprintf(cmd,sizeof(cmd),"wget -q --timeout=15 -O - \"%s\" 2>/dev/null",url);
    FILE *fp=popen(cmd,"r");
    if(!fp){
        snprintf(cmd,sizeof(cmd),"curl -s --max-time 15 \"%s\" 2>/dev/null",url);
        fp=popen(cmd,"r"); if(!fp) return GLM_ERR;
    }
    u32 tot=0; size_t r;
    while(tot<bsz-1&&(r=fread(buf+tot,1,4096,fp))>0) tot+=(u32)r;
    buf[tot]=0; pclose(fp); *olen=tot;
    return tot>0?GLM_OK:GLM_ERR;
}

static i32 load_file(const char *path, char *buf, u32 bsz, u32 *olen) {
    FILE *fp=fopen(path,"rb"); if(!fp) return GLM_ERR;
    u32 tot=0; size_t r;
    while(tot<bsz-1&&(r=fread(buf+tot,1,65536,fp))>0) tot+=(u32)r;
    buf[tot]=0; fclose(fp); *olen=tot;
    return GLM_OK;
}

static u32 extract_json(const char *json, u32 jlen,
                         char *out, u32 osz) {
    u32 w=0;
    const char *p=json, *end=json+jlen;
    const char *keys[]={"\"text\":","\"content\":","\"body\":",NULL};
    while(p<end&&w<osz-1){
        const char *found=NULL; u32 klen=0;
        for(u32 k=0;keys[k];k++){
            const char *f=strstr(p,keys[k]);
            if(f&&(!found||f<found)){found=f;klen=(u32)strlen(keys[k]);}
        }
        if(!found) break;
        p=found+klen;
        while(p<end&&(*p==' '||*p=='\t'||*p=='\n')) p++;
        if(p>=end||*p!='"'){p++;continue;}
        p++;
        while(p<end&&*p!='"'&&w<osz-1){
            if(*p=='\\'){p++;if(p<end&&*p=='n'){out[w++]='\n';p++;continue;}}
            out[w++]=*p++;
        }
        out[w++]=' ';
        if(p<end) p++;
    }
    if(w<osz) out[w]=0;
    return w;
}

/* ============================================================
   B6 — CONTEXT BUFFER
   Janela deslizante de CTX_BUF_LEN vetores hidden state
   Mantém média exponencial (EMA) do contexto como âncora semântica
   ============================================================ */
typedef struct {
    f32 ALIGNED16 slots[CTX_BUF_LEN][EMBED_DIM]; /* circular buffer */
    f32 ALIGNED16 mean[EMBED_DIM];               /* EMA do contexto */
    u32 head;  /* próxima posição de escrita */
    u32 count; /* quantos slots preenchidos */
} ContextBuffer;

static void ctx_init(ContextBuffer *c) {
    memset(c,0,sizeof(*c));
}

static void ctx_push(ContextBuffer *c, const f32 *h) {
    vec_copy(c->slots[c->head], h, EMBED_DIM);
    c->head = (c->head+1) % CTX_BUF_LEN;
    if(c->count < CTX_BUF_LEN) c->count++;
    /* EMA mean: mean = (1-α)·mean + α·h */
    for(u32 d=0;d<EMBED_DIM;d++)
        c->mean[d] = (1.f-ALPHA_EMA)*c->mean[d] + ALPHA_EMA*h[d];
}

/* ============================================================
   B6 — TOROIDAL STATE 7D
   s = (u,v,ψ,χ,ρ,δ,σ) ∈ [0,1)^7
   Mapeado a partir de (dados, entropia, hash, estado)
   ============================================================ */
typedef struct {
    f32 s[TORUS_DIM];  /* coordenadas toroidais */
    f32 C;             /* coerência [0,1] */
    f32 H;             /* entropia [0,1] */
    f32 phi;           /* qualidade = (1-H)·C */
    u32 phase;         /* fase mod 42 */
} ToroidalState;

/* FNV-1a 32-bit sobre bloco de bytes */
FORCE_INLINE u32 fnv1a_32(const u8 *data, u32 len) {
    u32 h=0x811C9DC5u;
    for(u32 i=0;i<len;i++) h=(h^data[i])*0x01000193u;
    return h;
}

/* CRC32C (Castagnoli) tabela-menos, poly=0x82F63B78 */
static u32 crc32c_byte(u32 crc, u8 b) {
    crc^=b;
    for(u32 j=0;j<8;j++)
        crc=(crc&1)?(crc>>1)^CRC32C_POLY:(crc>>1);
    return crc;
}

static u32 crc32c_buf(const u8 *buf, u32 len) {
    u32 crc=0xFFFFFFFFu;
    for(u32 i=0;i<len;i++) crc=crc32c_byte(crc,buf[i]);
    return ~crc;
}

/* mapa toroidal: embedding vector → coordenadas s */
static void torus_map(ToroidalState *ts, const f32 *h, u32 step) {
    u32 hash=fnv1a_32((const u8*)h, EMBED_DIM*sizeof(f32));
    u32 crc =crc32c_buf((const u8*)h, EMBED_DIM*sizeof(f32));

    /* entropia milli: unique bytes / 256 */
    u8 seen[256]={0}; u32 uniq=0, trans=0;
    const u8 *raw=(const u8*)h;
    u8 prev=raw[0];
    for(u32 i=0;i<EMBED_DIM*4;i++){
        u8 b=raw[i]; if(!seen[b]){seen[b]=1;uniq++;}
        if(i>0&&b!=prev) trans++;
        prev=b;
    }
    f32 H_milli=(f32)uniq/256.f + (f32)trans/(f32)(EMBED_DIM*4-1);
    H_milli = H_milli>1.f?1.f:H_milli;

    /* coerência baseada na norma do vetor */
    f32 nrm=vec_norm(h,EMBED_DIM);
    f32 C_milli=1.f/(1.f+nrm*0.1f);

    /* EMA */
    ts->C=(1.f-ALPHA_EMA)*ts->C+ALPHA_EMA*C_milli;
    ts->H=(1.f-ALPHA_EMA)*ts->H+ALPHA_EMA*H_milli;
    ts->phi=(1.f-ts->H)*ts->C;
    ts->phase=(ts->phase+1)%ATTRACTOR_N;

    /* 7 coordenadas a partir de hash, crc, step, phi */
    u32 seeds[7];
    seeds[0]=hash;
    seeds[1]=crc;
    seeds[2]=hash^crc;
    seeds[3]=(u32)(ts->phi*65536.f);
    seeds[4]=step;
    seeds[5]=ts->phase;
    seeds[6]=hash*1664525u+1013904223u;
    for(u32 i=0;i<TORUS_DIM;i++){
        seeds[i]=seeds[i]*1664525u+1013904223u;
        ts->s[i]=(f32)(seeds[i]&0xFFFFu)/65536.f; /* [0,1) */
    }
}

/* ============================================================
   B6 — RAF CYCLE ψχρΔΣΩ
   Executa 1 ciclo completo sobre o modelo e retorna φ (qualidade)
   ψ: lê estado atual (hidden)
   χ: retroalimenta (atualiza ctx buffer)
   ρ: expande (atualiza torus)
   Δ: valida (verifica coerência vs threshold)
   Σ: executa (atualiza embedding com gradiente simbólico)
   Ω: alinha (normaliza embedding)
   ============================================================ */
typedef struct {
    u32 step_count;
    f32 coh_threshold; /* Δ: mínimo para validar */
    f32 last_phi;
    f32 last_coh;
    /* para logging do ciclo */
    char phase_name[RAF_CYCLE_LEN][4]; /* ψ χ ρ Δ Σ Ω */
    f32  phase_val[RAF_CYCLE_LEN];
} RAFCycle;

static void raf_init(RAFCycle *r) {
    r->step_count=0;
    r->coh_threshold=0.2f;
    r->last_phi=0.f;
    r->last_coh=0.f;
    const char *names[RAF_CYCLE_LEN]={"psi","chi","rho","del","sig","omg"};
    for(u32 i=0;i<RAF_CYCLE_LEN;i++) strncpy(r->phase_name[i],names[i],3);
    memset(r->phase_val,0,sizeof(r->phase_val));
}

/* Um ciclo RAF completo sobre 1 token de contexto */
static f32 raf_cycle(RAFCycle *raf,
                      TinyModel *m,
                      ContextBuffer *ctx,
                      ToroidalState *ts,
                      u32 ctx_id,   /* token atual */
                      u32 tgt_id,   /* token alvo  */
                      f32 *logbuf,
                      f32 lr) {
    /* ψ — lê estado: pega embedding atual */
    f32 *emb = m->embed[ctx_id < m->vocab_size ? ctx_id : 1];
    raf->phase_val[0] = vec_norm(emb, EMBED_DIM);

    /* χ — retroalimenta: empurra no context buffer */
    ctx_push(ctx, emb);
    raf->phase_val[1] = cosine_sim(emb, ctx->mean, EMBED_DIM);

    /* ρ — expande: atualiza torus */
    torus_map(ts, emb, raf->step_count);
    raf->phase_val[2] = ts->phi;

    /* Δ — valida: coerência ctx vs emb */
    f32 coh = cosine_sim(emb, ctx->mean, EMBED_DIM);
    raf->last_coh = coh;
    raf->phase_val[3] = coh;

    /* Σ — executa: gradient step (apenas se coerência acima do limiar) */
    f32 loss = 0.f;
    f32 eff_lr = (coh >= raf->coh_threshold) ? lr : lr * 0.1f;
    loss = tiny_step(m, ctx_id, tgt_id, logbuf, eff_lr);
    raf->phase_val[4] = loss;

    /* Ω — alinha: normaliza embedding para manter norma ~1 */
    f32 nrm = vec_norm(m->embed[ctx_id], EMBED_DIM);
    if(nrm > 1e-6f){
        for(u32 d=0;d<EMBED_DIM;d++)
            m->embed[ctx_id][d] /= nrm;
    }
    raf->phase_val[5] = ts->phi;
    raf->last_phi = ts->phi;
    raf->step_count++;
    return loss;
}

/* ============================================================
   B6 — COHERENCE SCORE (prova matemática de coerência)
   Três invariantes:
     1. Cosine similarity: hidden vs context mean
     2. CRC32C integrity: embedding hash estável?
     3. Entropy bound: H < Π_max (0.9)
   Saída: score ∈ [0,1], prova textual
   ============================================================ */
#define PI_MAX 0.9f

typedef struct {
    f32 cosine;   /* [0,1] */
    f32 entropy;  /* [0,1] */
    u32 crc_ok;   /* 1 = CRC estável */
    f32 score;    /* composto */
    char verdict[64];
} CoherenceProof;

static void proof_compute(CoherenceProof *p,
                           const TinyModel *m,
                           const ContextBuffer *ctx,
                           const ToroidalState *ts,
                           u32 token_id) {
    const f32 *emb = m->embed[token_id < m->vocab_size ? token_id : 1];

    /* 1. cosine */
    p->cosine = cosine_sim(emb, ctx->mean, EMBED_DIM);
    if(p->cosine < 0.f) p->cosine = 0.f;

    /* 2. entropy via torus H */
    p->entropy = ts->H;

    /* 3. CRC stability: hash do embedding deve ser != 0 */
    u32 crc = crc32c_buf((const u8*)emb, EMBED_DIM*sizeof(f32));
    p->crc_ok = (crc != 0) ? 1u : 0u;

    /* score composto:
       φ-weighted: cosine × (1 - H/PI_MAX) × crc_ok */
    f32 entropy_factor = (p->entropy < PI_MAX) ?
                          1.f - p->entropy/PI_MAX : 0.f;
    p->score = p->cosine * entropy_factor * (f32)p->crc_ok;

    /* verdict textual */
    if(p->score > 0.7f)
        snprintf(p->verdict,sizeof(p->verdict),
                 GRN "COERENTE" RST " φ=%.3f cos=%.3f H=%.3f",
                 p->score, p->cosine, p->entropy);
    else if(p->score > 0.3f)
        snprintf(p->verdict,sizeof(p->verdict),
                 YEL "PARCIAL " RST " φ=%.3f cos=%.3f H=%.3f",
                 p->score, p->cosine, p->entropy);
    else
        snprintf(p->verdict,sizeof(p->verdict),
                 RED "RUIDO   " RST " φ=%.3f cos=%.3f H=%.3f",
                 p->score, p->cosine, p->entropy);
}

/* ============================================================
   B6 — ATTRACTOR POOL (42 atratores)
   Rafaelia sequence: F_{n+1} = F_n·(√3/2) - π·sin(279°)
   Período = 42 (verificado por simulação)
   Cada atrator é um vetor EMBED_DIM derivado da sequência
   ============================================================ */
typedef struct {
    f32 ALIGNED16 vecs[ATTRACTOR_N][EMBED_DIM];
    f32 vals[ATTRACTOR_N];  /* valores escalares da sequência */
} AttractorPool;

static void attractor_init(AttractorPool *a) {
    /* gera sequência Rafaelia */
    f32 F = 1.f;
    for(u32 n=0;n<ATTRACTOR_N;n++){
        a->vals[n] = F;
        F = F * SPIRAL_F32 + SIN279_PI_F32;
        /* gera vetor via seno/cosseno da fase */
        for(u32 d=0;d<EMBED_DIM;d+=2){
            f32 freq = (f32)(n+1) * (f32)(d+1) * 0.01f;
            a->vecs[n][d]   = sinf(a->vals[n] * freq);
            a->vecs[n][d+1] = cosf(a->vals[n] * freq);
        }
        /* normaliza */
        f32 nrm=vec_norm(a->vecs[n],EMBED_DIM);
        if(nrm>1e-6f)
            for(u32 d=0;d<EMBED_DIM;d++) a->vecs[n][d]/=nrm;
    }
}

/* colapso: encontra atrator mais próximo do vetor h */
static u32 attractor_collapse(const AttractorPool *a,
                               const f32 *h) {
    u32 best=0;
    f32 best_sim=-1.f;
    for(u32 n=0;n<ATTRACTOR_N;n++){
        f32 sim=cosine_sim(h, a->vecs[n], EMBED_DIM);
        if(sim>best_sim){best_sim=sim;best=n;}
    }
    return best;
}

/* ============================================================
   B6 — CONTEXT COHERENCE TRAINING (raf-powered loop)
   Usa RAFCycle em vez de tiny_train puro
   Integra prova de coerência a cada K steps
   ============================================================ */
static void raf_train(TinyModel *m,
                       ContextBuffer *ctx,
                       ToroidalState *ts,
                       AttractorPool *ap,
                       RAFCycle *raf,
                       const u32 *ids, u32 n,
                       u32 epochs, f32 lr,
                       u32 proof_every) {
    static f32 ALIGNED16 logbuf[VOCAB_MAX];
    CoherenceProof proof;

    printf(BLD MAG "[raf-train] tokens=%u epochs=%u lr=%.5f\n" RST,
           n, epochs, lr);

    for(u32 ep=0;ep<epochs;ep++){
        f32 tot=0; u32 cnt=0;
        for(u32 i=0;i+1<n;i++){
            f32 loss=raf_cycle(raf,m,ctx,ts,ids[i],ids[i+1],logbuf,lr);
            tot+=loss; cnt++;
            /* proof a cada proof_every steps */
            if(raf->step_count%proof_every==0){
                proof_compute(&proof,m,ctx,ts,ids[i]);
            }
        }
        f32 loss=tot/(f32)(cnt?cnt:1);
        if(loss<m->best_loss) m->best_loss=loss;
        m->last_loss=loss;

        if(ep%5==0||ep==epochs-1){
            /* colapso no atrator atual */
            u32 attr=attractor_collapse(ap, ctx->mean);
            printf("  ep=%3u loss=" YEL "%.4f" RST
                   " φ=" CYN "%.3f" RST
                   " coh=" CYN "%.3f" RST
                   " attr=" MAG "%2u" RST
                   " phase=%2u\n",
                   ep, loss, ts->phi, raf->last_coh,
                   attr, ts->phase);
        }
    }

    /* prova final */
    u32 mid=m->vocab_size/2;
    proof_compute(&proof,m,ctx,ts,mid);
    printf(BLD "[proof] %s\n" RST, proof.verdict);
}

/* ============================================================
   B6 — STATO DISPLAY (diagnóstico do ciclo RAF)
   ============================================================ */
static void raf_status(const RAFCycle *r,
                        const ToroidalState *ts,
                        const CoherenceProof *p) {
    printf(BLD CYN "\n=== RAF CYCLE STATUS ===\n" RST);
    const char *pnames[RAF_CYCLE_LEN]={"ψ read ","χ feed ","ρ expand",
                                        "Δ valid","Σ exec ","Ω align "};
    for(u32 i=0;i<RAF_CYCLE_LEN;i++)
        printf("  %s : %.4f\n", pnames[i], r->phase_val[i]);
    printf(BLD CYN "--- Torus 7D ---\n" RST);
    printf("  s = [");
    for(u32 i=0;i<TORUS_DIM;i++) printf("%.3f%s",ts->s[i],i<6?", ":"");
    printf("]\n");
    printf("  C=%.3f H=%.3f φ=%.3f phase=%u\n",
           ts->C, ts->H, ts->phi, ts->phase);
    printf(BLD CYN "--- Proof ---\n" RST);
    printf("  %s\n", p->verdict);
}

/* ============================================================
   B5 — FETCH ESCRITURAS (Project Gutenberg)
   ============================================================ */
static const char *SCRIPTURE_URLS[]={
    "https://www.gutenberg.org/cache/epub/10/pg10.txt",   /* KJV */
    "https://www.gutenberg.org/cache/epub/216/pg216.txt", /* Tao Te Ching */
    "https://www.gutenberg.org/cache/epub/2388/pg2388.txt",/* Bhagavad Gita */
    NULL
};

static void cmd_fetch(Vocab *v, u32 *ids, u32 *nids) {
    for(u32 u=0; SCRIPTURE_URLS[u] && *nids<60000; u++){
        printf("  [fetch] %s\n", SCRIPTURE_URLS[u]);
        u32 len=0;
        if(fetch_url(SCRIPTURE_URLS[u],g_textbuf,TEXT_BUF_SIZE,&len)==GLM_OK){
            u32 t=tokenize(v,g_textbuf,len,ids+*nids,65536-*nids);
            *nids+=t;
            printf("  +%u tokens (total=%u vocab=%u)\n",t,*nids,v->size);
        } else printf("  [WARN] falhou\n");
    }
}

/* ============================================================
   CLI HELP
   ============================================================ */
static void print_help(void) {
    printf(BLD CYN
           "\n  GeoLM ARM32 v2.0 — IA Geométrica + RAF ψχρΔΣΩ\n"
           RST);
    printf(YEL "  Compilar:\n"
           "    clang -O2 -mcpu=cortex-a7 -mfpu=neon-vfpv4 \\\n"
           "          -mfloat-abi=softfp -std=c11 \\\n"
           "          geolm_full.c -lm -o geolm\n" RST);
    printf("\n  Comandos:\n");
    const char *c[][2]={
        {"train [n] [lr]",    "treina tiny model (epochs, lr)"},
        {"raf   [n] [lr]",    "treina com ciclo RAF ψχρΔΣΩ"},
        {"gen <word> [n]",    "gera N tokens"},
        {"proof <word>",      "prova coerência de um token"},
        {"status",            "exibe estado RAF+Torus"},
        {"fetch",             "baixa escrituras sagradas"},
        {"train <file>",      "treina com arquivo local"},
        {"save <file>",       "salva pesos"},
        {"load <file>",       "carrega pesos"},
        {"vocab [n]",         "lista vocabulário"},
        {"bench",             "benchmark 1000 steps"},
        {"attract",           "mostra 42 atratores"},
        {"help",              "esta ajuda"},
        {"quit",              "sair"},
        {NULL,NULL}
    };
    for(u32 i=0;c[i][0];i++)
        printf("    " YEL "%-22s" RST " %s\n",c[i][0],c[i][1]);
    printf("\n");
}

/* ============================================================
   SEED TEXT EMBUTIDO
   ============================================================ */
static const char SEED_TEXT[] =
    "no principio era o verbo e o verbo estava com deus "
    "o verbo era deus ele estava no principio com deus "
    "pela fe entendemos que os mundos foram criados pela palavra de deus "
    "o senhor e o meu pastor nada me faltara "
    "ainda que eu ande pelo vale da sombra da morte nao temerei "
    "a sabedoria clama nas ruas levanta a sua voz nas pracas "
    "o temor do senhor e o principio da sabedoria "
    "conhecereis a verdade e a verdade vos libertara "
    "eu sou o caminho a verdade e a vida "
    "no principio criou deus os ceus e a terra "
    "a terra era sem forma e vazia e havia trevas "
    "e o espirito de deus se movia sobre as aguas "
    "e deus disse haja luz e houve luz "
    "quando em silencio o verbo se fez carne "
    "e habitou entre nos cheio de graca e de verdade "
    "o amor e paciente o amor e bondoso "
    "nao se vangloria nao se ensoberbece "
    "tudo sofre tudo cre tudo espera tudo suporta "
    "o dao que pode ser dito nao e o dao eterno "
    "o nome que pode ser nomeado nao e o nome eterno "
    "sem nome e o principio do ceu e da terra "
    "com nome e a mae de todos os seres "
    "aquele que conhece os outros e sabio "
    "aquele que conhece a si mesmo e iluminado "
    "quem vence os outros tem forca "
    "quem vence a si mesmo e poderoso "
    "o ser supremo e o campo e o conhecedor do campo "
    "a natureza e o espirito sao sem inicio "
    "os estados e as qualidades nascem da natureza "
    "o espirito experimenta o prazer e a dor";

/* ============================================================
   MAIN — REPL + CLI
   ============================================================ */
static u32 ALIGNED16 g_ids[65536];
static u32 g_nids=0;

static TinyModel   *g_model=NULL;
static Vocab        g_vocab;
static ContextBuffer g_ctx;
static ToroidalState g_torus;
static AttractorPool g_attract;
static RAFCycle      g_raf;
static CoherenceProof g_proof;

static void global_init(void) {
    arena_init(&g_arena);
    vocab_init(&g_vocab);
    ctx_init(&g_ctx);
    memset(&g_torus,0,sizeof(g_torus));
    g_torus.C=0.5f; g_torus.H=0.5f;
    attractor_init(&g_attract);
    raf_init(&g_raf);
    memset(&g_proof,0,sizeof(g_proof));
    snprintf(g_proof.verdict,sizeof(g_proof.verdict),"[sem prova]");
}

static void load_seed(void) {
    g_nids=tokenize(&g_vocab,SEED_TEXT,(u32)strlen(SEED_TEXT),g_ids,65536);
    printf("[seed] %u tokens vocab=%u\n",g_nids,g_vocab.size);
}

int main(int argc, char **argv) {
    printf(BLD CYN "=== GeoLM ARM32 v2.0 — B1..B6 + RAF ψχρΔΣΩ ===\n" RST);
    global_init();
    load_seed();
    g_model=tiny_new(g_vocab.size);
    if(!g_model){printf("[FAIL] OOM model\n");return 1;}

    /* modo linha de comando */
    if(argc>=2){
        if(!strcmp(argv[1],"help")){print_help();return 0;}
        if(!strcmp(argv[1],"fetch")){
            cmd_fetch(&g_vocab,g_ids,&g_nids);
            g_model=tiny_new(g_vocab.size);
            tiny_train(g_model,g_ids,g_nids,30,0.05f);
            return 0;
        }
        if(!strcmp(argv[1],"train")&&argc>=3){
            u32 len=0;
            if(load_file(argv[2],g_textbuf,TEXT_BUF_SIZE,&len)==GLM_OK){
                if(g_textbuf[0]=='{'||g_textbuf[0]=='['){
                    static char ex[TEXT_BUF_SIZE];
                    u32 el=extract_json(g_textbuf,len,ex,TEXT_BUF_SIZE);
                    g_nids=tokenize(&g_vocab,ex,el,g_ids,65536);
                } else g_nids=tokenize(&g_vocab,g_textbuf,len,g_ids,65536);
                g_model=tiny_new(g_vocab.size);
                tiny_train(g_model,g_ids,g_nids,50,0.05f);
                model_save(g_model,&g_vocab,"geolm.bin");
            }
            return 0;
        }
        if(!strcmp(argv[1],"raf")&&argc>=3){
            u32 len=0;
            if(load_file(argv[2],g_textbuf,TEXT_BUF_SIZE,&len)==GLM_OK){
                g_nids=tokenize(&g_vocab,g_textbuf,len,g_ids,65536);
                g_model=tiny_new(g_vocab.size);
                u32 ep=argc>=4?(u32)atoi(argv[3]):30;
                f32 lr=argc>=5?(f32)atof(argv[4]):0.05f;
                raf_train(g_model,&g_ctx,&g_torus,&g_attract,&g_raf,
                          g_ids,g_nids,ep,lr,100);
                model_save(g_model,&g_vocab,"geolm.bin");
            }
            return 0;
        }
    }

    /* treino inicial com seed */
    printf("[init] treino inicial com texto semente...\n");
    tiny_train(g_model,g_ids,g_nids,20,0.05f);

    print_help();

    /* REPL */
    char line[256];
    static f32 ALIGNED16 logbuf[VOCAB_MAX];

    for(;;){
        printf(BLD CYN "geolm> " RST); fflush(stdout);
        if(!fgets(line,sizeof(line),stdin)) break;
        line[strcspn(line,"\n")]=0;
        if(!line[0]) continue;

        char cmd[64],a1[64],a2[64];
        cmd[0]=a1[0]=a2[0]=0;
        sscanf(line,"%63s %63s %63s",cmd,a1,a2);

        if(!strcmp(cmd,"quit")||!strcmp(cmd,"exit")) break;

        else if(!strcmp(cmd,"help")) print_help();

        else if(!strcmp(cmd,"train")){
            u32 ep=a1[0]?(u32)atoi(a1):20;
            f32 lr=a2[0]?(f32)atof(a2):0.05f;
            tiny_train(g_model,g_ids,g_nids,ep,lr);
        }

        else if(!strcmp(cmd,"raf")){
            u32 ep=a1[0]?(u32)atoi(a1):20;
            f32 lr=a2[0]?(f32)atof(a2):0.05f;
            raf_train(g_model,&g_ctx,&g_torus,&g_attract,&g_raf,
                      g_ids,g_nids,ep,lr,50);
        }

        else if(!strcmp(cmd,"gen")){
            u32 start=g_vocab.id_bos, n=20;
            if(a1[0]) start=vocab_lookup(&g_vocab,a1);
            if(a2[0]) n=(u32)atoi(a2);
            if(start==g_vocab.id_unk){
                printf("  [?] '%s' não encontrado, usando bos\n",a1);
                start=g_vocab.id_bos;
            }
            tiny_generate(g_model,&g_vocab,start,n,0.8f);
        }

        else if(!strcmp(cmd,"proof")){
            if(!a1[0]){printf("  uso: proof <palavra>\n");continue;}
            u32 tid=vocab_lookup(&g_vocab,a1);
            if(tid==g_vocab.id_unk){printf("  [?] '%s' não encontrado\n",a1);continue;}
            proof_compute(&g_proof,g_model,&g_ctx,&g_torus,tid);
            printf("  [proof] %s\n",g_proof.verdict);
        }

        else if(!strcmp(cmd,"status")){
            proof_compute(&g_proof,g_model,&g_ctx,&g_torus,
                          g_vocab.id_bos);
            raf_status(&g_raf,&g_torus,&g_proof);
        }

        else if(!strcmp(cmd,"attract")){
            printf("[attractors] Rafaelia sequence (42 valores):\n");
            for(u32 n=0;n<ATTRACTOR_N;n++)
                printf("  A[%2u] = %.6f\n",n,g_attract.vals[n]);
        }

        else if(!strcmp(cmd,"vocab")){
            u32 lim=a1[0]?(u32)atoi(a1):20;
            u32 shown=0;
            printf("  vocab size=%u\n",g_vocab.size);
            for(u32 i=0;i<g_vocab.cap&&shown<lim;i++)
                if(g_vocab.entries[i].used&&g_vocab.entries[i].id>3){
                    printf("  %4u: %-20s (freq=%u)\n",
                           g_vocab.entries[i].id,
                           g_vocab.entries[i].str,
                           g_vocab.entries[i].freq);
                    shown++;
                }
        }

        else if(!strcmp(cmd,"fetch")){
            cmd_fetch(&g_vocab,g_ids,&g_nids);
            TinyModel *m2=tiny_new(g_vocab.size);
            if(m2){g_model=m2;tiny_train(g_model,g_ids,g_nids,20,0.05f);}
        }

        else if(!strcmp(cmd,"save")&&a1[0])
            model_save(g_model,&g_vocab,a1);

        else if(!strcmp(cmd,"load")&&a1[0]){
            TinyModel *m2=ALLOC64(TinyModel,1);
            if(m2&&model_load(m2,&g_vocab,a1)==GLM_OK) g_model=m2;
        }

        else if(!strcmp(cmd,"bench")){
            struct timespec t0,t1;
            clock_gettime(CLOCK_MONOTONIC,&t0);
            volatile f32 sink=0;
            for(u32 i=0;i+1<g_nids&&i<1000;i++)
                sink+=tiny_step(g_model,g_ids[i],g_ids[i+1],logbuf,0.f);
            clock_gettime(CLOCK_MONOTONIC,&t1);
            f64 ms=(t1.tv_sec-t0.tv_sec)*1e3+(t1.tv_nsec-t0.tv_nsec)*1e-6;
            printf("  1000 steps: %.2fms (%.0f steps/s)\n",ms,1000.0/ms*1000.0);
            (void)sink;
        }

        else if(!strcmp(cmd,"arena")) arena_stats(&g_arena);

        else printf("  [?] comando desconhecido: %s\n",cmd);
    }

    printf(GRN "  Até logo. φ=%.3f\n" RST, g_torus.phi);
    return 0;
}
