/* rafael_up_v2.c
   Sistema Rafael v2 — C puro, Termux ARM32
   - Evolução semi-unitária de ψ (Taylor ordem 2)
   - Feedback bidirecional (H <-> G)
   - Dualidade probabilística
   Uso: ./rafael_up_v2 [seed] [out_csv]
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define H_DIM 16
#define G_DIM 64
#define PARTS 8
#define T_STEPS 200
#define ALPHA 0.25
#define NOISE_P 0.05
#define DT 0.05
#define COUPLING 0.12
#define GAMMA 0.05
#define LAMBDA_PSI 0.8
#define P_DUAL 0.15

static unsigned int rng_state = 123456789u;
unsigned int xorshift32(){ unsigned int x=rng_state; x^=x<<13; x^=x>>17; x^=x<<5; rng_state=x; return x; }
double rand01(){ return (xorshift32() & 0xFFFFFF) / (double)0x1000000; }

void normalize(double *v,int n){
    double s=0.0; for(int i=0;i<n;i++) s += v[i]*v[i];
    if(s<=0) return;
    double norm = sqrt(s);
    for(int i=0;i<n;i++) v[i] /= norm;
}

void build_H(double H[H_DIM][H_DIM]){
    for(int i=0;i<H_DIM;i++) for(int j=0;j<H_DIM;j++) H[i][j]=0.0;
    for(int i=0;i<H_DIM;i++){
        H[i][i] = 1.0 + 0.1*(rand01()-0.5);
        if(i+1 < H_DIM){
            double v = 0.2*(rand01()-0.5);
            H[i][i+1] = v; H[i+1][i] = v;
        }
    }
}

void apply_H(double H[H_DIM][H_DIM], double *in, double *out){
    for(int i=0;i<H_DIM;i++){
        double s=0.0;
        for(int j=0;j<H_DIM;j++) s += H[i][j]*in[j];
        out[i] = s;
    }
}

void init_state(double *psi, double *rho){
    for(int i=0;i<H_DIM;i++) psi[i] = (rand01()-0.5);
    normalize(psi,H_DIM);
    double sum=0.0;
    for(int i=0;i<G_DIM;i++){ rho[i] = rand01(); sum += rho[i]; }
    for(int i=0;i<G_DIM;i++) rho[i] /= sum;
}

void apply_U_T(double *rho, double *out, int shift){
    for(int i=0;i<G_DIM;i++){ int j=(i+shift)%G_DIM; out[j]=rho[i]; }
}

void apply_D_T(double *rho, double *out){
    for(int i=0;i<G_DIM;i++){ int j=(G_DIM - i) % G_DIM; out[j] = rho[i]; }
}

void apply_D_H(double *psi, double *out){
    for(int i=0;i<H_DIM;i++) out[i]=0.0;
    for(int i=0;i<H_DIM;i+=2){
        if(i+1 < H_DIM){ out[i] = psi[i+1]; out[i+1] = psi[i]; }
        else out[i] = psi[i];
    }
}

void apply_C_G(double *rho, double *rho_in, double *out){
    for(int i=0;i<G_DIM;i++) out[i] = (1.0-ALPHA)*rho[i] + ALPHA*rho_in[i];
}

void apply_noise(double *rho, double p){
    if(p <= 0.0) return;
    double u = 1.0 / (double)G_DIM;
    for(int i=0;i<G_DIM;i++) rho[i] = (1.0-p)*rho[i] + p*u;
}

double shannon_entropy(double *rho, int n){
    double H=0.0;
    for(int i=0;i<n;i++){
        double p = rho[i];
        if(p>0) H -= p * log(p);
    }
    return H;
}

double psi_entropy(double *psi){
    double sum=0.0;
    for(int i=0;i<H_DIM;i++) sum += psi[i]*psi[i];
    if(sum<=0) return 0.0;
    double H=0.0;
    for(int i=0;i<H_DIM;i++){
        double p = (psi[i]*psi[i]) / sum;
        if(p>0) H -= p * log(p);
    }
    return H;
}

void local_entropies(double *rho, double *Hloc){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double sum=0.0;
        for(int i=0;i<cell;i++) sum += rho[k*cell + i];
        if(sum <= 0.0){ Hloc[k] = 0.0; continue; }
        double H=0.0;
        for(int i=0;i<cell;i++){
            double p = rho[k*cell + i] / sum;
            if(p>0) H -= p * log(p);
        }
        Hloc[k] = H;
    }
}

void snr_per_partition(double *rho, double *snr){
    int cell = G_DIM / PARTS;
    for(int k=0;k<PARTS;k++){
        double mean=0.0;
        for(int i=0;i<cell;i++) mean += rho[k*cell + i];
        mean /= cell;
        double var=0.0;
        for(int i=0;i<cell;i++){ double d = rho[k*cell + i] - mean; var += d*d; }
        var /= cell;
        snr[k] = (var <= 1e-12) ? 1e6 : (mean*mean / var);
    }
}

int main(int argc, char **argv){
    unsigned int seed = (unsigned int)time(NULL) ^ 0xA5A5A5A5u;
    const char *outname = "rafael_timeseries.csv";
    if(argc >= 2) seed = (unsigned int)atoi(argv[1]);
    if(argc >= 3) outname = argv[2];

    rng_state = seed;

    static double H[H_DIM][H_DIM];
    static double psi[H_DIM], psi_tmp[H_DIM], psi2[H_DIM];
    static double rho[G_DIM], rho_tmp[G_DIM], rho_in[G_DIM];
    static double Hloc[PARTS], snr[PARTS];

    build_H(H);
    init_state(psi, rho);
    for(int i=0;i<G_DIM;i++) rho_in[i] = rho[i];

    FILE *f = fopen(outname, "w");
    if(!f){ perror("fopen"); return 1; }
    /* header */
    fprintf(f,"step,Hglob,Hpsi,Htotal");
    for(int k=0;k<PARTS;k++) fprintf(f,",Hloc_%d",k);
    fprintf(f,"\n");

    for(int t=0;t<T_STEPS;t++){
        /* U_T */
        int shift = (t % (G_DIM/4)) + 1;
        apply_U_T(rho, rho_tmp, shift);
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];

        /* Dualidade probabilística */
        if(rand01() < P_DUAL){
            apply_D_T(rho, rho_tmp);
            for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i];
            apply_D_H(psi, psi_tmp);
            for(int i=0;i<H_DIM;i++) psi[i] = psi_tmp[i];
        }

        /* Acoplamento H -> G */
        for(int i=0;i<G_DIM;i++){
            double influence = fabs(psi[i % H_DIM]);
            rho[i] *= (1.0 + COUPLING * influence);
        }
        /* renormaliza */
        double sum = 0.0;
        for(int i=0;i<G_DIM;i++) sum += rho[i];
        if(sum <= 0.0) sum = 1.0;
        for(int i=0;i<G_DIM;i++) rho[i] /= sum;

        /* Correção e ruído */
        apply_C_G(rho, rho_in, rho_tmp);
        apply_noise(rho_tmp, NOISE_P);
        sum = 0.0;
        for(int i=0;i<G_DIM;i++) sum += rho_tmp[i];
        if(sum <= 0.0) sum = 1.0;
        for(int i=0;i<G_DIM;i++) rho[i] = rho_tmp[i] / sum;

        /* Evolução semi-unitária de psi (Taylor 2) + feedback G -> H */
        apply_H(H, psi, psi_tmp);        /* H psi */
        apply_H(H, psi_tmp, psi2);      /* H^2 psi */
        for(int i=0;i<H_DIM;i++){
            psi[i] = psi[i] - DT * psi_tmp[i] + 0.5 * DT * DT * psi2[i] + GAMMA * rho[i % G_DIM];
        }
        normalize(psi, H_DIM);

        /* Medidas */
        double Hglob = shannon_entropy(rho, G_DIM);
        double Hpsi  = psi_entropy(psi);
        double Htotal = Hglob + LAMBDA_PSI * Hpsi;
        local_entropies(rho, Hloc);
        snr_per_partition(rho, snr);

        /* grava linha */
        fprintf(f,"%d,%.12f,%.12f,%.12f", t, Hglob, Hpsi, Htotal);
        for(int k=0;k<PARTS;k++) fprintf(f,",%.12f", Hloc[k]);
        fprintf(f,"\n");

        if(t % 20 == 0){
            printf("seed=%u step=%3d Hglob=%.3f Hpsi=%.3f Htotal=%.3f Hloc0=%.3f SNR0=%.2f\n",
                   seed, t, Hglob, Hpsi, Htotal, Hloc[0], snr[0]);
        }
    }

    fclose(f);
    printf("Run complete. seed=%u out=%s\n", seed, outname);
    return 0;
}
