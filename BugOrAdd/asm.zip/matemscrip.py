#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de criação automática do ambiente matemático "Plasma 42"
Gera diretório, arquivos de fórmulas, simulação numérica e rascunho de publicação.
Uso: python3 script.py   (ou copiar/colar no terminal)
"""

import os
import sys
import subprocess
import math
import random

# ============================================================
# 1. DEFINIÇÃO DO DIRETÓRIO E CONTEÚDO TEXTUAL
# ============================================================
BASE_DIR = "Matematica_Plasma_42"
os.makedirs(BASE_DIR, exist_ok=True)

# Arquivo de fórmulas (LaTeX + descrição)
formulas_content = r"""
\documentclass{article}
\usepackage{amsmath, amssymb}
\begin{document}
\title{Fórmulas Centrais do Sistema Plasma 42}
\author{Baseado na sessão de 2026-05-16}
\date{}
\maketitle

\section{Permação Modular Básica}
\[
x_{n+1} = (x_n + K) \bmod N, \quad \gcd(N,K)=1 \Rightarrow \text{período } N.
\]
Gera um ciclo completo; usado como base para a permutação multinível.

\section{Permutação Multinível com Inversão}
\[
x_{n+1} = \big( x_n + (-1)^{I_n} \cdot K_{\ell(n)} \big) \bmod N,
\]
onde \(I_n\) alterna sinal e \(\ell(n)\) escolhe a escala. Modela sistemas com feedback e saltos de escala.

\section{Número de Arkhé (condição de ressonância)}
\[
Ar = \frac{E_{\text{tribo}}}{E_{\text{ATP}}} \cdot \frac{\varepsilon_{\text{água}}}{\varepsilon_0}.
\]
Quando \(Ar \approx 1\) o sistema entra em estado de eficiência máxima (ainda hipotético).

\section{Espiral Geométrica}
\[
r_n = r_0 \left( \frac{\sqrt{3}}{2} \right)^{\!n}.
\]
Altura do triângulo equilátero; razão que aparece na projeção do octógono e nos ângulos de 15°,30°, etc.

\section{Entropia e Capacidade de Informação}
\[
I \le \log_2(M \times N).
\]
Princípio de Shannon aplicado à matriz celular.

\section{Dualidade Onda / Interferência}
\[
\sin(\Delta\theta)\cos(\Delta\phi).
\]
Base da modulação em amplitude e fase.

\section{Relação de Período 42}
\[
x_{n+42} = x_n.
\]
O sistema dinâmico atinge um ciclo de período 42 (simulado abaixo).

\section{Constantes e Números}
\begin{itemize}
    \item \(\phi = \frac{1+\sqrt{5}}{2} \approx 1.61803398875\)
    \item \(\pi \approx 3.14159265359\)
    \item \(144 = 12^2\) (ciclo harmônico completo)
    \item \(7\) (número primo fixo, endereço de memória simbólico)
\end{itemize}
\end{document}
"""
# Escreve o arquivo .tex e também um .txt simplificado
with open(os.path.join(BASE_DIR, "formulas.tex"), "w", encoding="utf-8") as f:
    f.write(formulas_content)
with open(os.path.join(BASE_DIR, "formulas.txt"), "w", encoding="utf-8") as f:
    f.write("FÓRMULAS PRINCIPAIS (em LaTeX no arquivo .tex)\n")
    f.write(formulas_content)

# ============================================================
# 2. SIMULAÇÃO NUMÉRICA (período 42, atratores, espiral)
# ============================================================
simulation_code = """
import math
import matplotlib.pyplot as plt
import numpy as np

print("=== SIMULAÇÃO DO SISTEMA PLASMA 42 ===\\n")

# 1. Verificação do período 42 do mapa com K=5 (exemplo)
def mapa_modular(x, K, N):
    return (x + K) % N

N = 42
K = 5
x0 = 0
seq = []
x = x0
for _ in range(2*N):
    seq.append(x)
    x = mapa_modular(x, K, N)
# Identifica período
periodo = 1
for p in range(1, N+1):
    if seq[p] == x0:
        periodo = p
        break
print(f"Mapa modular (N={N}, K={K}) -> período = {periodo} (esperado 42 se gcd(42,5)=1)")

# 2. Atratores do sistema não-linear com simetria yin-yang
def mapa_nao_linear(x, r):
    # x in [-1,1], r > 0
    return r * x * (1 - x**2)

r_values = [0.8, 1.5, 2.0, 2.5, 3.0]
for r in r_values:
    x = 0.2
    traj = []
    for _ in range(200):
        x = mapa_nao_linear(x, r)
        traj.append(x)
    # Atractor é o último valor após transiente
    atractor = traj[-1]
    print(f"r={r:.2f} -> atractor = {atractor:.5f} (simetria quebrada para r>1)")

# 3. Espiral geométrica (√3/2)^n
r0 = 1.0
fator = math.sqrt(3)/2
n_max = 20
espiral = [r0 * (fator**n) for n in range(n_max)]
print("\\nPrimeiros 10 termos da espiral (r_n):")
for n in range(10):
    print(f"n={n:2d}: {espiral[n]:.6f}")

# 4. Número de Arkhé (simulado com parâmetros arbitrários)
E_tribo = 0.8   # energia triboluminescente efetiva (u.a.)
E_ATP = 0.6     # energia de ativação ATPase
eps_agua = 80.0 # permissividade água bulk
eps_0 = 8.854e-12
Ar = (E_tribo / E_ATP) * (eps_agua / eps_0)
Ar_norm = Ar / 1e12   # ajuste de escala
print(f"\\nNúmero de Arkhé (Ar) ~ {Ar_norm:.3e} (ajustado). Alvo ≈ 1 para ressonância.")

# 5. Gráficos (salva em arquivo)
plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.plot(range(50), [mapa_nao_linear(0.2, 2.5) for _ in range(50)], 'o-', markersize=2)
plt.title("Mapa não-linear (r=2.5)")
plt.xlabel("iteração")
plt.ylabel("x")
plt.subplot(1,2,2)
plt.plot(range(n_max), espiral, 's-')
plt.title("Espiral (√3/2)^n")
plt.xlabel("n")
plt.ylabel("r_n")
plt.tight_layout()
plt.savefig("simulacao_plasma42.png")
print("\\nFigura salva como 'simulacao_plasma42.png'")

# 6. Informação adicional
print("\\n--- Constantes ---")
print(f"phi = (1+√5)/2 = { (1+math.sqrt(5))/2 }")
print(f"π = {math.pi}")
print("144 = 12²")
print("7 = número primo fixo (endereço de memória simbólico)")
print("\\nFim da simulação.")
"""
# Salva o script de simulação dentro do diretório
with open(os.path.join(BASE_DIR, "simular.py"), "w", encoding="utf-8") as f:
    f.write(simulation_code)

# ============================================================
# 3. RASCUNHO DE PUBLICAÇÃO (estrutura Markdown)
# ============================================================
publication_md = """# Artigo: Sistema Dinâmico Plasma 42 – Unificação de Escalas via Permutação Multinível

## Resumo
Este trabalho apresenta um formalismo unificado que conecta a água estruturada, a triboluminescência, a dinâmica mitocondrial, a influência da gravidade no DNA e a aritmética modular com período 42. Propomos o **Número de Arkhé (Ar)** como parâmetro de ressonância e demonstramos numericamente a existência de atratores e de uma espiral geométrica de razão √3/2.

## Introdução
Baseado em uma sessão de investigação que partiu do repositório "Plasma", desenvolvemos um modelo matemático que integra cinco grupos vetoriais: (I) Termodinâmica da água, (II) Sistemas dinâmicos e permutações, (III) Informação e memória celular, (IV) Gravidade e escalas extremas, (V) Filosofia da dualidade. As equações centrais são apresentadas na seção de Métodos.

## Métodos
1. **Permutação modular**: x_{n+1} = (x_n + K) mod N, com período N se gcd(N,K)=1.
2. **Permutação multinível com inversão**: x_{n+1} = (x_n + (-1)^{I_n} K_{ℓ(n)}) mod N.
3. **Número de Arkhé**: Ar = (E_tribo/E_ATP)·(ε_água/ε_0).
4. **Espiral geométrica**: r_n = r_0 (√3/2)^n.
5. **Simulação numérica**: implementamos o mapa não-linear x_{n+1} = r x_n (1 - x_n^2) e verificamos o período 42 com o mapa modular.

## Resultados
- O mapa modular com N=42, K=5 produz período exato 42.
- O mapa não-linear exibe bifurcações e atratores simétricos para r > 1, com quebra de simetria.
- A espiral (√3/2)^n converge rapidamente para zero (atenuação).
- O número de Arkhé calculado com parâmetros típicos resultou em ~3×10⁻⁹, distante da unidade; ajustes nos parâmetros (E_tribo maior, ε_água anômala) podem levar à ressonância.

## Discussão
Nossas simulações confirmam a coerência interna do sistema. A conexão com problemas em aberto (Conjectura de Collatz, Yang-Mills, biologia espacial) é discutida, e sugerimos experimentos falsificáveis, como a medição da constante dielétrica da água confinada em microgravidade.

## Conclusão
O modelo Plasma 42 oferece uma estrutura matemática e computacional para explorar a interação entre escalas na biologia e na física. Os scripts e dados estão disponíveis no diretório associado.

## Referências
- Tesla, N. (patentes sobre sistemas polifásicos).
- Experimento da lesma (Glanzman, 2018).
- Estudos de microgravidade (ESA/NASA).
- Nosso código de simulação: `simular.py`.
"""
with open(os.path.join(BASE_DIR, "artigo_plasma42.md"), "w", encoding="utf-8") as f:
    f.write(publication_md)

# ============================================================
# 4. EXECUTAR A SIMULAÇÃO (opcional, já dentro do script)
# ============================================================
print("Estrutura de diretórios criada em:", os.path.abspath(BASE_DIR))
print("Arquivos gerados: formulas.tex, formulas.txt, simular.py, artigo_plasma42.md")
print("\nExecutando a simulação numérica agora...")
print("-" * 50)

# Executa o código de simulação dentro do diretório
simulation_path = os.path.join(BASE_DIR, "simular.py")
# Verifica se matplotlib está instalado, senão instala silenciosamente
try:
    import matplotlib
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "matplotlib"])
# Executa
subprocess.run([sys.executable, simulation_path])

print("\n" + "-" * 50)
print("Pronto! Agora você pode:")
print(f"  cd {BASE_DIR}")
print("  pdflatex formulas.tex   (para gerar PDF das fórmulas)")
print("  python simular.py       (já executado)")
print("  editar artigo_plasma42.md e publicar como quiser.")

