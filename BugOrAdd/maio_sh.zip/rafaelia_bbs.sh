#!/data/data/com.termux/files/usr/bin/bash

# Função 1: Login
f_login() {
    clear
    echo "=== AUTENTICAR NO GITHUB ==="
    gh auth login -p https -w
    read -p "Pressione ENTER para voltar..."
}

# Função 2: Listar, Escolher Diretório e Baixar
f_clone() {
    clear
    if ! gh auth status >/dev/null 2>&1; then
        echo "ERRO: Faça o Login (Opção 1) primeiro!"
        read -p "Pressione ENTER para voltar..."
        return
    fi
    
    # 1. Escolhe o repositório na lista
    SELECAO=$(gh repo list --limit 100 | fzf --prompt="🔍 Selecione: " --header="Use as setas para escolher e ENTER")
    
    if [ -n "$SELECAO" ]; then
        REPO_COMPLETO=$(echo "$SELECAO" | awk '{print $1}')
        # Pega só a última parte do nome (ex: dono/projeto vira só "projeto")
        NOME_PROJETO=$(basename "$REPO_COMPLETO")
        
        # 2. Caixa azul perguntando o diretório de destino (Padrão: ~/projetos/nome_do_repo)
        DIRETORIO_PADRAO="$HOME/projetos/$NOME_PROJETO"
        
        DESTINO=$(dialog --title " DIRETÓRIO DE DOWNLOAD " \
            --inputbox "Onde deseja salvar o repositório $NOME_PROJETO?\n(Pode apagar e digitar outro caminho se quiser)" \
            10 60 "$DIRETORIO_PADRAO" \
            3>&1 1>&2 2>&3)
        
        # Se você apertar "Cancelar", ele cancela o download
        if [ $? -ne 0 ]; then return; fi
        
        clear
        echo "Baixando $REPO_COMPLETO para a pasta: $DESTINO"
        echo "Aguarde..."
        
        # Faz o download exatamente para a pasta que você escolheu
        gh repo clone "$REPO_COMPLETO" "$DESTINO"
        
        echo ""
        echo "✅ Download concluído com sucesso em: $DESTINO"
        read -p "Pressione ENTER para voltar ao menu..."
    fi
}

# Função 3: Sincronizar
f_sync() {
    clear
    PASTA=$(dialog --title " SINCRONIZAR " --inputbox "Digite o caminho da pasta do repositório para sincronizar:" 10 60 "$HOME/projetos/" 3>&1 1>&2 2>&3)
    if [ $? -ne 0 ]; then return; fi
    
    cd "$PASTA" 2>/dev/null
    if [ $? -eq 0 ] && [ -d ".git" ]; then
        echo "Sincronizando $PASTA ..."
        git pull
    else
        echo "ERRO: Caminho inválido ou não é um repositório Git."
    fi
    read -p "Pressione ENTER para voltar..."
}

# LOOP DO MENU
while true; do
    OPCAO=$(dialog --clear --title " RAFAELIA BBS - GESTOR DE MATRIZ " \
        --backtitle "Usuário: rafaelmeloreisnovo@gmail.com" \
        --cancel-label "Sair" \
        --menu "Escolha a operação desejada:" 15 55 4 \
        "1" "Logar na Conta" \
        "2" "Listar, Escolher Diretório e Baixar" \
        "3" "Sincronizar uma pasta" \
        2>&1 >/dev/tty)

    if [ $? -ne 0 ]; then clear; exit 0; fi

    case $OPCAO in
        1) f_login ;;
        2) f_clone ;;
        3) f_sync ;;
    esac
done
