#!/data/data/com.termux/files/usr/bin/bash

set -e

# =========================
# core.s (ASM ARMv7 + NEON)
# =========================
cat << 'ASM' > core.s
.global core_run

.type core_run, %function

@ r0 = x ptr
@ r1 = y ptr
@ r2 = dens ptr
@ r3 = N
@ r4 = K

core_run:

    push {r4-r7, lr}

    mov r5, #0

loop_main:

    add r6, r5, r4
    cmp r6, r3
    subge r6, r6, r3

    @ load xi yi
    vldr s0, [r0, r5, lsl #2]
    vldr s1, [r1, r5, lsl #2]

    @ load xj yj
    vldr s2, [r0, r6, lsl #2]
    vldr s3, [r1, r6, lsl #2]

    @ dx dy
    vsub.f32 s4, s2, s0
    vsub.f32 s5, s3, s1

    @ len = sqrt(dx^2 + dy^2)
    vmul.f32 s6, s4, s4
    vmla.f32 s6, s5, s5
    vsqrt.f32 s6, s6

    @ fast inverse (1/len)
    vrecpe.f32 s7, s6
    vrecps.f32 s8, s6, s7
    vmul.f32 s7, s7, s8

    @ normalize
    vmul.f32 s4, s4, s7
    vmul.f32 s5, s5, s7

    @ accumulate
    vldr s9, [r2, r5, lsl #2]
    vadd.f32 s9, s9, s6
    vstr s9, [r2, r5, lsl #2]

    add r5, r5, #1
    cmp r5, r3
    blt loop_main

    pop {r4-r7, pc}
ASM

# =========================
# main.c (CLI + PNG + SVG)
# =========================
cat << 'C' > main.c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

extern void core_run(float*, float*, float*, int, int);

#define N 42
#define SIZE 512

float x[N], y[N], d[N];

void gen_circle() {
    for(int i=0;i<N;i++){
        float t = 2.0f * M_PI * i / N;
        x[i] = cosf(t);
        y[i] = sinf(t);
        d[i] = 0.0f;
    }
}

void save_svg() {
    FILE *f = fopen("out.svg","w");
    fprintf(f,"<svg width='512' height='512' xmlns='http://www.w3.org/2000/svg'>\n");
    for(int i=0;i<N;i++){
        int px = 256 + x[i]*200;
        int py = 256 + y[i]*200;
        fprintf(f,"<circle cx='%d' cy='%d' r='3' fill='red'/>\n",px,py);
    }
    fprintf(f,"</svg>");
    fclose(f);
}

void save_ppm() {
    FILE *f = fopen("out.ppm","w");
    fprintf(f,"P3\n%d %d\n255\n", SIZE, SIZE);

    for(int y=0;y<SIZE;y++){
        for(int x=0;x<SIZE;x++){
            int c = (x^y)&255;
            fprintf(f,"%d %d %d ",c,c,c);
        }
        fprintf(f,"\n");
    }
    fclose(f);
}

int main(int argc, char** argv) {

    int K = 5;
    if(argc > 1) K = atoi(argv[1]);

    gen_circle();

    clock_t t0 = clock();

    for(int i=0;i<100000;i++)
        core_run(x,y,d,N,K);

    clock_t t1 = clock();

    double dt = (double)(t1-t0)/CLOCKS_PER_SEC;

    printf("Time: %.6f s\n", dt);
    printf("Ops/sec: %.2f M\n", (100000.0*N)/dt/1e6);

    save_svg();
    save_ppm();

    return 0;
}
C

# =========================
# COMPILAR
# =========================
clang -O3 -mfpu=neon -mfloat-abi=softfp main.c core.s -o run

# =========================
# EXECUTAR
# =========================
echo ">>> RUN"
./run 5

