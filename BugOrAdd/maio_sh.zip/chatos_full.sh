#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "[ChatOS] building FULL MONOLITH ARMv7..."

cat << 'C' > main.c
#include <stdio.h>
#include <time.h>

static inline double now(){
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

/* =========================
   SCALAR CORE
========================= */
__attribute__((naked))
void core_scalar(int n){
    __asm__ volatile(
        "push {r4-r7, lr}\n"
        "mov r4, r0\n"
        "mov r5, #1\n"
        "mov r6, #3\n"
        "1:\n"
        "add r5, r5, r6\n"
        "eor r5, r5, r4\n"
        "mul r5, r5, r6\n"
        "subs r4, r4, #1\n"
        "bne 1b\n"
        "pop {r4-r7, pc}\n"
    );
}

/* =========================
   ILP CORE
========================= */
__attribute__((naked))
void core_ilp(int n){
    __asm__ volatile(
        "push {r4-r7, lr}\n"
        "mov r4, r0\n"
        "1:\n"
        "add r5, r5, r6\n"
        "add r7, r7, r8\n"
        "add r9, r9, r10\n"
        "add r11, r11, r12\n"
        "subs r4, r4, #1\n"
        "bne 1b\n"
        "pop {r4-r7, pc}\n"
    );
}

/* =========================
   MEMORY STRIDE (CACHE PROBE)
========================= */
volatile int buffer[4096];

void core_memory(int n){
    volatile int x = 0;

    for(int i=0;i<n;i++){
        x += buffer[(i * 16) & 4095];
        x += buffer[(i * 128) & 4095];
        x += buffer[(i * 512) & 4095];
        x += buffer[(i * 1024) & 4095];
    }
}

/* =========================
   BRANCH STRESS
========================= */
int core_branch(int n){
    int x = 0;

    for(int i=0;i<n;i++){
        if((i ^ x) & 1)
            x += i;
        else
            x -= i;
    }

    return x;
}

/* =========================
   BENCH UTILS
========================= */
double run(void (*f)(int), int n){
    double t0 = now();
    f(n);
    double t1 = now();
    return t1 - t0;
}

/* overload workaround */
double run_mem(void (*f)(int), int n){
    double t0 = now();
    f(n);
    double t1 = now();
    return t1 - t0;
}

int main(){

    int iters = 20000000;
    double t[5];

    /* warmup */
    for(int i=0;i<3;i++){
        core_scalar(1000000);
        core_ilp(1000000);
        core_memory(100000);
        core_branch(1000000);
    }

    t[0] = run(core_scalar, iters);
    t[1] = run(core_ilp, iters);
    t[2] = run_mem(core_memory, 200000);
    t[3] = run_mem((void(*)(int))core_branch, 20000000);

    /* median simple (fixed small set) */
    for(int i=0;i<4;i++){
        for(int j=i+1;j<4;j++){
            if(t[i] > t[j]){
                double tmp=t[i];
                t[i]=t[j];
                t[j]=tmp;
            }
        }
    }

    double median = t[2];

    printf("{\n");
    printf("  \"scalar\": %.6f,\n", t[0]);
    printf("  \"ilp\": %.6f,\n", t[1]);
    printf("  \"memory\": %.6f,\n", t[2]);
    printf("  \"branch\": %.6f,\n", t[3]);
    printf("  \"median_latency\": %.6f\n", median);
    printf("}\n");

    return 0;
}
C

echo "[ChatOS] compiling..."

clang -O3 \
-mcpu=cortex-a7 \
-fPIE -pie \
-fno-stack-protector \
main.c -o chato

echo "[ChatOS] running..."
./chato

