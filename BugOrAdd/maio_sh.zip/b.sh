#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# VOYNICH PIPELINE COMPLETO — ARM64 Moto E7 Power
# Mapeia 209 JPGs + dados EVA + toro + famílias + relatório
# Cole tudo de uma vez no Termux
# ============================================================
set -e

ROOT="$HOME/exacordex/voynich"
DATA="$HOME/voynich_data"
IMGS="$DATA/images"
EVA="$DATA/voynich_raw.txt"
OUT="$ROOT/processed"
DONE="$ROOT/done"
REPORT="$ROOT/RELATORIO_FINAL.txt"

mkdir -p "$OUT" "$DONE" "$ROOT/data"

echo "╔══════════════════════════════════════════════╗"
echo "║  VOYNICH PIPELINE | ARM64 | PERIOD=42       ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── FASE 1: INVENTÁRIO DAS 209 IMAGENS ──────────────────────
echo "=== FASE 1: INVENTÁRIO DAS IMAGENS ===" | tee "$REPORT"
echo "" >> "$REPORT"

total_imgs=$(ls "$IMGS"/voynich_*.jpg 2>/dev/null | wc -l)
total_size=$(du -sh "$IMGS"/voynich_*.jpg 2>/dev/null | tail -1 | cut -f1 || echo "?")

echo "Total de imagens: $total_imgs" | tee -a "$REPORT"
echo "Diretório: $IMGS" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

# Classifica por tamanho de arquivo (proxy para densidade de conteúdo)
echo "--- Top 10 maiores (mais densa) ---" | tee -a "$REPORT"
ls -lS "$IMGS"/voynich_*.jpg 2>/dev/null | head -10 | \
    awk '{printf "  %s  %s KB\n", $NF, int($5/1024)}' | \
    sed "s|$IMGS/||" | tee -a "$REPORT"

echo "" | tee -a "$REPORT"
echo "--- Top 10 menores (possivelmente páginas simples) ---" | tee -a "$REPORT"
ls -lS "$IMGS"/voynich_*.jpg 2>/dev/null | tail -10 | \
    awk '{printf "  %s  %s KB\n", $NF, int($5/1024)}' | \
    sed "s|$IMGS/||" | tee -a "$REPORT"

# Copia todas para processed com status
echo "" | tee -a "$REPORT"
echo "--- Movendo para workflow ---" | tee -a "$REPORT"
for img in "$IMGS"/voynich_*.jpg; do
    base=$(basename "$img")
    num=$(echo "$base" | grep -o '[0-9]*' | head -1)
    # Classifica: 001-060=herbal, 061-100=astro, 101-116=cosmo,
    #             117-146=pharma, 147-209=recipe+text
    n=$((10#$num))
    if   [ $n -le 60  ]; then section="herbal"
    elif [ $n -le 100 ]; then section="astro"
    elif [ $n -le 116 ]; then section="cosmo"
    elif [ $n -le 146 ]; then section="pharma"
    else                       section="recipe"
    fi
    mkdir -p "$OUT/$section"
    ln -sf "$img" "$OUT/$section/$base" 2>/dev/null || true
done

echo "Seções criadas:" | tee -a "$REPORT"
for sec in herbal astro cosmo pharma recipe; do
    cnt=$(ls "$OUT/$sec"/*.jpg 2>/dev/null | wc -l)
    echo "  $sec: $cnt imagens" | tee -a "$REPORT"
done

# ── FASE 2: ANÁLISE EVA COM FAMÍLIAS POR SEÇÃO ──────────────
echo "" | tee -a "$REPORT"
echo "=== FASE 2: FAMÍLIAS EVA POR SEÇÃO ===" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

python3 << 'PYEOF' | tee -a "$REPORT"
import re, collections, math, os

EVA = os.path.expanduser("~/voynich_data/voynich_raw.txt")

# Seções por número de fólio
def section_of(folio):
    m = re.search(r'f(\d+)', folio)
    if not m: return "unknown"
    n = int(m.group(1))
    if n <= 60:  return "herbal"
    if n <= 100: return "astro"
    if n <= 116: return "cosmo"
    if n <= 146: return "pharma"
    return "recipe"

folio_words = {}
current = None
try:
    with open(EVA, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            fm = re.match(r'<(f\d+[rv]\d*)>', line)
            if fm: current = fm.group(1)
            if not current or line.startswith('#'): continue
            text = re.sub(r'<[^>]+>', '', line)
            words = re.findall(r'[a-z]{2,}', text)
            if words:
                folio_words.setdefault(current, []).extend(words)
except FileNotFoundError:
    print("  [EVA não encontrado — usando dados simulados]")
    folio_words = {}

if not folio_words:
    print("  Arquivo EVA ausente. Execute: cp ~/voynich_data/voynich_raw.txt ~/exacordex/voynich/data/")
else:
    # Agrupa por seção
    sections = collections.defaultdict(list)
    for folio, words in folio_words.items():
        sec = section_of(folio)
        sections[sec].extend(words)

    families_ranked = ["ch","qo","sh","ok","ot","da","ol","ai","yk","op"]

    for sec in ["herbal","astro","cosmo","pharma","recipe"]:
        words = sections[sec]
        if not words:
            continue
        total = len(words)
        fam_cnt = collections.Counter()
        for w in words:
            if len(w) >= 2:
                fam_cnt[w[:2]] += 1
        print(f"\n  [{sec.upper()}] {total} tokens | top famílias:")
        for fam, cnt in fam_cnt.most_common(5):
            pct = 100*cnt/total
            bar = '█' * int(pct/2)
            print(f"    {fam}: {cnt:5d} ({pct:5.1f}%) {bar}")

    # Dominância por seção (qual família é mais forte em cada)
    print("\n  --- FAMÍLIA DOMINANTE POR SEÇÃO ---")
    for sec in ["herbal","astro","cosmo","pharma","recipe"]:
        words = sections[sec]
        if not words: continue
        fam_cnt = collections.Counter(w[:2] for w in words if len(w)>=2)
        dom_fam, dom_cnt = fam_cnt.most_common(1)[0]
        pct = 100*dom_cnt/len(words)
        print(f"    {sec:8s}: {dom_fam} ({pct:.1f}%)")
PYEOF

# ── FASE 3: MAPEAMENTO TORO DAS 209 PÁGINAS ─────────────────
echo "" | tee -a "$REPORT"
echo "=== FASE 3: POSIÇÕES TOROIDAIS (209 páginas) ===" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

python3 << 'PYEOF' | tee -a "$REPORT"
import math

TORUS = 10
PERIOD = 42
SPIRAL = math.sqrt(3)/2
PAGES = 209

print("  Mapeamento: página -> (x,y) no toro T^2")
print("  Stride por sequência 0001123 (menor distância total)\n")

strides = [0,0,0,1,1,2,3]
slen = 7

sections = {
    "herbal":  (1,  60),
    "astro":   (61, 100),
    "cosmo":   (101,116),
    "pharma":  (117,146),
    "recipe":  (147,209),
}

for sec, (start, end) in sections.items():
    pos_x = int((start/PAGES) * (TORUS-1))
    pos_y = int(math.fmod((start/PAGES) * PERIOD, TORUS))
    end_x = int((end/PAGES) * (TORUS-1))
    end_y = int(math.fmod((end/PAGES) * PERIOD, TORUS))
    count = end - start + 1
    # Distância toroidal média da seção
    norm = (start + end) / 2 / PAGES
    inv_contrib = norm * (SPIRAL ** ((start % PERIOD)))
    print(f"  {sec:8s}: páginas {start:3d}-{end:3d} ({count:3d} pgs)")
    print(f"           toro_start=({pos_x},{pos_y}) toro_end=({end_x},{end_y})")
    print(f"           contrib_invariante = {inv_contrib:.6f}")
    print()

# Invariante global das 209 páginas
inv_total = sum(
    (i/PAGES) * (SPIRAL ** (i % PERIOD))
    for i in range(1, PAGES+1)
)
print(f"  INVARIANTE TOTAL I(209) = {inv_total:.6f}")
print(f"  I/pi = {inv_total/math.pi:.6f}  (referência: I_familias = 3.114806)")
PYEOF

# ── FASE 4: PIPELINE IMAGEM -> TODO/PROCESSED/DONE ──────────
echo "" | tee -a "$REPORT"
echo "=== FASE 4: WORKFLOW STATUS ===" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

# Cria script de processamento individual
cat > "$ROOT/process_page.sh" << 'SH'
#!/data/data/com.termux/files/usr/bin/bash
# Uso: bash process_page.sh voynich_013.jpg
PAGE="${1:-voynich_013.jpg}"
ROOT="$HOME/exacordex/voynich"
IMGS="$HOME/voynich_data/images"

num=$(echo "$PAGE" | grep -o '[0-9]*' | head -1)
n=$((10#$num))
if   [ $n -le 60  ]; then sec="herbal"
elif [ $n -le 100 ]; then sec="astro"
elif [ $n -le 116 ]; then sec="cosmo"
elif [ $n -le 146 ]; then sec="pharma"
else                       sec="recipe"
fi

echo "Página: $PAGE | Seção: $sec | Número: $n"
echo "Posição toro: x=$((n % 10)) y=$((n % 42 % 10))"
echo "Fase phi: $((n % 42))"

# Verifica existência
if [ -f "$IMGS/$PAGE" ]; then
    size=$(ls -lh "$IMGS/$PAGE" | awk '{print $5}')
    echo "Arquivo: OK ($size)"
    # Marca como processed
    cp "$IMGS/$PAGE" "$ROOT/processed/$PAGE"
    echo "→ processed/$PAGE"
else
    echo "Arquivo: NÃO ENCONTRADO em $IMGS"
fi
SH
chmod +x "$ROOT/process_page.sh"

# Status atual
echo "  Script de processamento: $ROOT/process_page.sh" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"
for sec in herbal astro cosmo pharma recipe; do
    cnt=$(ls "$OUT/$sec"/*.jpg 2>/dev/null | wc -l)
    echo "  $sec/: $cnt imagens prontas" | tee -a "$REPORT"
done

# ── FASE 5: SCRIPT DE PROCESSAMENTO EM LOTE ─────────────────
cat > "$ROOT/batch_process.sh" << 'SH'
#!/data/data/com.termux/files/usr/bin/bash
# Processa todas as imagens em lote com análise por seção
ROOT="$HOME/exacordex/voynich"
IMGS="$HOME/voynich_data/images"
DONE="$ROOT/done"
mkdir -p "$DONE"

total=0; ok=0; missing=0
for img in "$IMGS"/voynich_*.jpg; do
    [ -f "$img" ] || { ((missing++)); continue; }
    base=$(basename "$img")
    num=$(echo "$base" | grep -o '[0-9]*' | head -1)
    n=$((10#$num))
    if   [ $n -le 60  ]; then sec="herbal"
    elif [ $n -le 100 ]; then sec="astro"
    elif [ $n -le 116 ]; then sec="cosmo"
    elif [ $n -le 146 ]; then sec="pharma"
    else                       sec="recipe"
    fi
    phi=$((n % 42))
    toro_x=$((n % 10))
    toro_y=$((phi % 10))
    echo "$base|$sec|phi=$phi|toro=($toro_x,$toro_y)|$(ls -lh $img | awk '{print $5}')" \
        >> "$ROOT/done/index.csv"
    ((ok++))
    ((total++))
done

echo "Processadas: $ok / $total"
echo "Ausentes: $missing"
echo "Índice: $ROOT/done/index.csv"
SH
chmod +x "$ROOT/batch_process.sh"

# ── RESUMO FINAL ─────────────────────────────────────────────
echo "" | tee -a "$REPORT"
echo "=== RESUMO FINAL ===" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"
echo "  Imagens mapeadas: $total_imgs / 209" | tee -a "$REPORT"
echo "  Relatório:  $REPORT" | tee -a "$REPORT"
echo "  Index batch: $ROOT/done/index.csv (rodar batch_process.sh)" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"
echo "  PRÓXIMOS COMANDOS:" | tee -a "$REPORT"
echo "    bash ~/exacordex/voynich/batch_process.sh" | tee -a "$REPORT"
echo "    bash ~/exacordex/voynich/process_page.sh voynich_013.jpg" | tee -a "$REPORT"
echo "" | tee -a "$REPORT"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  PIPELINE CONCLUÍDO                          ║"
echo "║  Relatório salvo em:                         ║"
echo "║  ~/exacordex/voynich/RELATORIO_FINAL.txt     ║"
echo "╚══════════════════════════════════════════════╝"


#Cole tudo isso de uma vez. Depois:

# Processar página específica (a 013 que está na imagem)
bash ~/exacordex/voynich/process_page.sh voynich_013.jpg

# Processar todas as 209 em lote e gerar index.csv
bash ~/exacordex/voynich/batch_process.sh

# Ver o índice gerado
head -20 ~/exacordex/voynich/done/index.csv


#O que o pipeline entrega: cada imagem classificada em seção `herbal/astro/cosmo/pharma/recipe`, com posição toroidal `(x,y)`, fase `phi mod 42`, tamanho do arquivo, e o índice CSV completo das 209 páginas. O relatório final fica em `RELATORIO_FINAL.txt` com análise das famílias EVA por seção cruzada com o mapeamento toroidal.
