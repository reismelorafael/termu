#!/data/data/com.termux/files/usr/bin/bash
set -u

CC=${CC:-clang}
FLAGS="-O3 -march=armv7-a -mfpu=neon -mfloat-abi=softfp"

echo "=== RAFAELIA ARM32 REAL BUILD ==="

echo
echo "[1] Corrigindo imediatos simbólicos simples..."
for f in rafaelia_b3.S rafaelia_bench.S rafaelia_final.S rafaelia_core_armv7_bench.S; do
  [ -f "$f" ] || continue
  cp "$f" "$f.bak"
  sed -i \
    -e 's/mov r1, #msg_/ldr r1, =msg_/g' \
    -e 's/mov r2, #msg_/ldr r2, =msg_/g' \
    -e 's/and r2, r2, #0xFFFF/uxth r2, r2/g' \
    "$f"
done

echo
echo "[2] Compilando arquivos com _start usando -nostdlib..."
for f in rafaelia_core_armv7.S rafaelia_final.S; do
  [ -f "$f" ] || continue
  out="${f%.S}"
  echo "[START] $f -> $out"
  $CC $FLAGS -nostdlib -Wl,-e,_start "$f" -o "$out" \
    && chmod +x "$out" \
    && echo "OK: $out" \
    || echo "FALHOU: $f"
done

echo
echo "[3] Compilando ASM ARM32 sem ARM64..."
for f in rafaelia_b3.S rafaelia_bench.S rafaelia_core_armv7_bench.S; do
  [ -f "$f" ] || continue

  if grep -q 'udiv' "$f"; then
    echo "PULADO por usar udiv ARM opcional: $f"
    continue
  fi

  out="${f%.S}"
  echo "[ASM32] $f -> $out"
  $CC $FLAGS "$f" -o "$out" \
    && chmod +x "$out" \
    && echo "OK: $out" \
    || echo "FALHOU: $f"
done

echo
echo "[4] Ignorados: são ARM64/AArch64, não ARM32:"
echo "rafaelia_math_bench.S"
echo "rafaelia_core_v8.S"

echo
echo "=== BINÁRIOS GERADOS ==="
ls -lh rafaelia_b3 rafaelia_bench rafaelia_final rafaelia_core_armv7 rafaelia_core_armv7_bench 2>/dev/null || true
