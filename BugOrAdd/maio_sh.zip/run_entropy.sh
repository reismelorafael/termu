#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
IFS=$'\n\t'

# RAFAELIA_ENTROPY_CORE Orchestrator
# Profiles: generic, professional, environment
# Usage: ./run_entropy.sh [--profile=generic|professional|environment] [--iters=N] [--out=run_entropy] [--no-run]

PROFILE="professional"
ITERS=30000000
OUT_BIN="run_entropy"
NO_RUN=0
VERBOSE=1

log() { printf '%s\n' "$*"; }
err() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# parse args
for arg in "$@"; do
  case $arg in
    --profile=*) PROFILE="${arg#*=}"; shift ;;
    --iters=*) ITERS="${arg#*=}"; shift ;;
    --out=*) OUT_BIN="${arg#*=}"; shift ;;
    --no-run) NO_RUN=1; shift ;;
    --quiet) VERBOSE=0; shift ;;
    --help|-h) printf "Usage: %s [--profile=generic|professional|environment] [--iters=N] [--out=NAME] [--no-run]\n" "$0"; exit 0 ;;
    *) err "Unknown argument: $arg" ;;
  esac
done

[ $VERBOSE -eq 1 ] && log "=== RAFAELIA_ENTROPY_CORE ==="
[ $VERBOSE -eq 1 ] && log "Profile: $PROFILE  ITERS: $ITERS  OUT: $OUT_BIN"

# environment checks
command -v gcc >/dev/null 2>&1 || GCC_AVAILABLE=0 && true
command -v gcc >/dev/null 2>&1 && GCC_AVAILABLE=1
command -v as >/dev/null 2>&1 || AS_AVAILABLE=0 && true
command -v as >/dev/null 2>&1 && AS_AVAILABLE=1

if [ $GCC_AVAILABLE -eq 0 ] && [ $AS_AVAILABLE -eq 0 ]; then
  err "Neither gcc nor as found. Install a toolchain (pkg install clang binutils or apt)."
fi

# detect CPU features (Termux / Linux)
CPU_MODEL="unknown"
CPU_FLAGS=""
if [ -r /proc/cpuinfo ]; then
  CPU_MODEL=$(awk -F: '/model name|Processor|Hardware/ {print $2; exit}' /proc/cpuinfo | sed 's/^[ \t]*//;s/[ \t]*$//' || true)
  CPU_FLAGS=$(tr '\n' ' ' < /proc/cpuinfo | tr '[:upper:]' '[:lower:]' | sed -n 's/.*features[[:space:]]*:[[:space:]]*//p' || true)
fi

[ $VERBOSE -eq 1 ] && log "Detected CPU: ${CPU_MODEL:-unknown}"
[ $VERBOSE -eq 1 ] && log "CPU flags snippet: ${CPU_FLAGS:0:120}"

# choose flags by profile and detection
CFLAGS_COMMON="-O3 -fomit-frame-pointer -fno-math-errno -fno-trapping-math -Wall -Wextra -Wno-unused-parameter"
ASFLAGS=""
LDFLAGS="-lm -lrt"

case "$PROFILE" in
  generic)
    CFLAGS="$CFLAGS_COMMON -march=armv7-a -marm"
    ASFLAGS=""
    ;;
  professional)
    # aggressive but reasonable for many ARMv7 devices
    CFLAGS="$CFLAGS_COMMON -march=armv7-a -mfpu=neon -mfloat-abi=softfp -mcpu=cortex-a7 -funroll-loops -falign-functions=16 -fno-exceptions"
    ASFLAGS=""
    ;;
  environment)
    # adapt to detected features
    if echo "$CPU_FLAGS" | grep -q "neon"; then
      CFLAGS="$CFLAGS_COMMON -march=armv7-a -mfpu=neon -mfloat-abi=softfp -mcpu=cortex-a7 -funroll-loops"
    else
      CFLAGS="$CFLAGS_COMMON -march=armv7-a -marm -mcpu=cortex-a8"
    fi
    ASFLAGS=""
    ;;
  *)
    err "Unknown profile: $PROFILE"
    ;;
esac

[ $VERBOSE -eq 1 ] && log "CFLAGS: $CFLAGS"

# create assembly and C sources (robusto, idempotente)
cat > core.s <<'ASM'
.global core_run
.type core_run, %function

@ r0 = iterations
core_run:
    push {r4-r11, lr}

    mov r4, r0

    @ seeds
    mov r5, #0x12345678
    mov r6, #0x87654321
    mov r7, #0xF00DBEEF
    mov r8, #0x0BADCAFE
    mov r9, #0xCAFEBABE
    mov r10,#0xDEADBEEF
    mov r11,#0x13579BDF
    mov r12,#0x2468ACE0

loop_label:
    eor r5, r5, r5, lsl #13
    eor r5, r5, r5, lsr #17
    eor r5, r5, r5, lsl #5

    eor r6, r6, r6, lsl #11
    eor r6, r6, r6, lsr #19
    eor r6, r6, r6, lsl #3

    add r7, r7, r5
    eor r7, r7, r6
    mul r7, r7, r11

    add r8, r8, r6
    eor r8, r8, r5
    mul r8, r8, r12

    eor r9, r9, r7
    add r9, r9, r8
    mul r9, r9, r5

    eor r10, r10, r8
    add r10, r10, r7
    mul r10, r10, r6

    eor r11, r11, r9
    add r11, r11, r10

    eor r12, r12, r10
    add r12, r12, r9

    subs r4, r4, #1
    bgt loop_label

    pop {r4-r11, pc}
ASM

cat > main.c <<'C'
#include <stdio.h>
#include <time.h>

extern void core_run(int);

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(void) {
    int iters = ITERS_PLACEHOLDER;
    double warm[3];

    for (int i = 0; i < 3; i++) {
        double t0 = now();
        core_run(2000000);
        double t1 = now();
        warm[i] = t1 - t0;
    }

    double t0 = now();
    core_run(iters);
    double t1 = now();

    double dt = t1 - t0;
    double ops = (double)iters * 30.0;
    double ops_sec = ops / dt;

    double cpu_ghz = 1.5;
    double cycles = dt * cpu_ghz * 1e9;
    double cycles_per_iter = cycles / iters;

    printf("\n=== RESULTADOS ===\n");
    printf("Tempo total: %.6f s\n", dt);
    printf("Instrucoes estimadas: %.2f M\n", ops / 1e6);
    printf("Instrucoes/s: %.2f M\n", ops_sec / 1e6);
    printf("Ciclos/iteracao: %.2f\n", cycles_per_iter);
    printf("Warmup: %.4f / %.4f / %.4f s\n", warm[0], warm[1], warm[2]);

    return 0;
}
C

# inject iterations value safely
sed -i "s/ITERS_PLACEHOLDER/${ITERS}/g" main.c

# compile function
compile_with_gcc() {
  log "Compiling with gcc..."
  gcc -O3 $CFLAGS -fomit-frame-pointer -fno-exceptions -fno-math-errno \
      main.c core.s -o "$OUT_BIN" $LDFLAGS 2> compile_gcc.log
}

compile_with_as_ld() {
  log "Compiling with as + ld..."
  as -o core.o core.s 2> compile_as.log
  gcc -O3 $CFLAGS -c main.c -o main.o 2> compile_gcc_main.log
  ld -o "$OUT_BIN" core.o main.o -lc -lm -lrt 2> compile_ld.log || true
}

# try compilation strategies
COMPILED=0
if [ $GCC_AVAILABLE -eq 1 ]; then
  if compile_with_gcc; then
    COMPILED=1
  else
    log "gcc compile failed, see compile_gcc.log"
  fi
fi

if [ $COMPILED -eq 0 ] && [ $AS_AVAILABLE -eq 1 ]; then
  if compile_with_as_ld; then
    COMPILED=1
  else
    log "as/ld compile failed, check compile_as.log and compile_ld.log"
  fi
fi

if [ $COMPILED -eq 0 ]; then
  err "Compilation failed with all strategies."
fi

# make executable
chmod +x "$OUT_BIN"

# run if requested
if [ $NO_RUN -eq 0 ]; then
  log "Running $OUT_BIN ..."
  ./"$OUT_BIN"
else
  log "Build complete. Skipping run due to --no-run."
fi

log "Done."
