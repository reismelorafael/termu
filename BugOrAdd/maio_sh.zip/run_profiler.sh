#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=== CPU MICROARCH PROFILER ==="

# =========================
# 1. SCALAR LATENCY CORE
# =========================
cat << 'ASM' > core_scalar.s
.global core_scalar
.type core_scalar, %function

core_scalar:
    push {r4-r7, lr}

    mov r4, r0

loop:
    add r5, r5, r6   @ dependency chain
    add r5, r5, r6
    add r5, r5, r6

    subs r4, r4, #1
    bne loop

    pop {r4-r7, pc}
ASM

# =========================
# 2. ILP CORE (parallel)
# =========================
cat << 'ASM' > core_ilp.s
.global core_ilp
.type core_ilp, %function

core_ilp:
    push {r4-r7, lr}

    mov r4, r0

loop:
    add r5, r5, r6
    add r7, r7, r8
    add r9, r9, r10
    add r11, r11, r12

    subs r4, r4, #1
    bne loop

    pop {r4-r7, pc}
ASM

# =========================
# 3. NEON CORE (128-bit)
# =========================
cat << 'ASM' > core_neon.s
.global core_neon
.type core_neon, %function

core_neon:
    push {r4-r7, lr}

    mov r4, r0

loop:
    vadd.i32 q0, q0, q1
    vadd.i32 q2, q2, q3
    veor q4, q4, q5

    subs r4, r4, #1
    bne loop

    pop {r4-r7, pc}
ASM

# =========================
# 4. ENTROPY BIT-SLICE CORE
# =========================
cat << 'ASM' > core_entropy.s
.global core_entropy
.type core_entropy, %function

core_entropy:
    push {r4-r12, lr}

    mov r4, r0

    mov r5, #0x12345678
    mov r6, #0x87654321
    mov r7, #0xF00DBEEF
    mov r8, #0x0BADCAFE

loop:
    eor r5, r5, r5, lsl #13
    eor r5, r5, r5, lsr #17
    eor r5, r5, r5, lsl #5

    eor r6, r6, r6, lsl #11
    eor r6, r6, r6, lsr #19

    add r7, r7, r5
    eor r7, r7, r6

    add r8, r8, r7
    eor r8, r8, r5

    subs r4, r4, #1
    bne loop

    pop {r4-r12, pc}
ASM

# =========================
# MAIN PROFILER
# =========================
cat << 'C' > main.c
#include <stdio.h>
#include <time.h>
#include <math.h>

extern void core_scalar(int);
extern void core_ilp(int);
extern void core_neon(int);
extern void core_entropy(int);

static double now(){
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

/* =========================
   ENTROPIA SHANNON
========================= */
double entropy(unsigned int *data, int n){
    int c[256] = {0};

    for(int i=0;i<n;i++)
        c[data[i] & 0xFF]++;

    double H = 0.0;
    for(int i=0;i<256;i++){
        if(c[i]){
            double p = (double)c[i]/n;
            H -= p * log2(p);
        }
    }
    return H;
}

/* =========================
   PREVISIBILIDADE
========================= */
double predictability(unsigned int *data, int n){
    int same = 0;
    for(int i=1;i<n;i++)
        if(data[i] == data[i-1]) same++;

    return 1.0 - (double)same/n;
}

/* =========================
   BENCH CORE
========================= */
double bench(void (*f)(int), int iters){
    double t0 = now();
    f(iters);
    double t1 = now();
    return t1 - t0;
}

int main(){

    int iters = 200000000;

    printf("=== PROFILER START ===\n");

    double t_scalar = bench(core_scalar, iters);
    double t_ilp    = bench(core_ilp, iters);
    double t_neon   = bench(core_neon, iters);
    double t_ent    = bench(core_entropy, iters);

    double freq = 1.8e9;

    printf("\n--- SCALAR ---\n");
    printf("Time: %.6f s\n", t_scalar);
    printf("IPC approx: %.2f\n", iters / (t_scalar * freq));

    printf("\n--- ILP ---\n");
    printf("Time: %.6f s\n", t_ilp);
    printf("IPC approx: %.2f\n", iters / (t_ilp * freq));

    printf("\n--- NEON ---\n");
    printf("Time: %.6f s\n", t_neon);
    printf("SIMD gain approx: %.2fx\n", t_scalar / t_neon);

    printf("\n--- ENTROPY ---\n");
    printf("Time: %.6f s\n", t_ent);

    printf("\n=== SUMMARY ===\n");
    printf("Pipeline saturation index (PSI): %.3f\n",
        (t_scalar / t_ilp + t_scalar / t_neon) / 2.0);

    printf("NOTE: PSI > 1.5 = good ILP utilization\n");

    return 0;
}
C

# =========================
# BUILD
# =========================
clang -O3 \
-mcpu=cortex-a7 \
-mfpu=neon \
-mfloat-abi=softfp \
-fomit-frame-pointer \
main.c core_scalar.s core_ilp.s core_neon.s core_entropy.s -o run

echo ">>> RUN"
./run

