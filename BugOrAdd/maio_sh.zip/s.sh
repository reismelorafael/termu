#!/bin/bash
# =============================================================================
# EXACORDEX – COMPILAÇÃO E TESTE COMPLETO (ARM64 + NEON + CRC32)
# =============================================================================
set -e

cat > exacordex.S << 'EOF'
// ============================================================================
// EXACORDEX / VECTRA – BANCO CENTRAL DE PALAVRAS (VERSÃO INTEGRADA)
// ============================================================================
// Inclui: injeção (com/sem micro-entropia), reconstrução, busca por ressonância,
//         fusão harmônica, k‑vizinhos (top 4), pré‑filtro e síntese de áudio
// ============================================================================

.section .rodata
.align 4
PHI_Q16:        .word 0x0001999A
INV_PHI_Q16:    .word 0x00009E37
SPIRAL_K:       .word 0x0000DDB3
CRC_SEED:       .word 0xFFFFFFFF

// Máscaras fractais (32 máscaras de 16 bytes – exemplo com 4)
.align 4
fractal_masks:
    .byte 0x12,0x34,0x56,0x78,0x9A,0xBC,0xDE,0xF0,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88
    .byte 0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,0x01,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99
    .byte 0x34,0x56,0x78,0x9A,0xBC,0xDE,0xF0,0x12,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xAA
    .byte 0x45,0x67,0x89,0xAB,0xCD,0xEF,0x01,0x23,0x44,0x55,0x66,0x77,0x88,0x99,0xAA,0xBB
    // Preencher até 32 em uma implementação real

.section .bss
.align 16
torus_base:     .space 4194304 * 16   // 64 MB

.section .text
.global exacordex_inject_massive
.global vectra_entropy_inject
.global exacordex_reconstruct_phase
.global exacordex_search_nearest
.global vectra_resonance_search
.global exacordex_fuse
.global exacordex_search_k_nearest
.global torus_speak
.global emit_cell_generic

// ============================================================================
// MACRO VÓRTEX FRACTAL
// ============================================================================
.macro FRACTAL_VORTEX v_reg, v_tmp
    mul     \v_reg\().16b, \v_reg\().16b, v30.16b
    rev64   \v_tmp\().16b, \v_reg\().16b
    eor     \v_reg\().16b, \v_reg\().16b, \v_tmp\().16b
    ext     \v_reg\().16b, \v_reg\().16b, \v_reg\().16b, #8
.endm

// ============================================================================
// 1. INJEÇÃO GEOMÉTRICA (VERSÃO MASSIVA)
// ============================================================================
exacordex_inject_massive:
    stp     x29, x30, [sp, #-64]!
    mov     x29, sp
    adrp    x8, PHI_Q16
    ldr     w9, [x8, :lo12:PHI_Q16]
    dup     v30.4s, w9
    adrp    x10, torus_base
    add     x10, x10, :lo12:torus_base
    mov     w11, w2
.process_block:
    cmp     x1, #64
    b.lt    .process_tail
    ld1     {v0.16b, v1.16b, v2.16b, v3.16b}, [x0], #64
    FRACTAL_VORTEX v0, v4
    FRACTAL_VORTEX v1, v5
    FRACTAL_VORTEX v2, v6
    FRACTAL_VORTEX v3, v7
    umov    x12, v0.d[0]; crc32cx w11, w11, x12
    umov    x12, v1.d[1]; crc32cx w11, w11, x12
    umov    x12, v2.d[0]; crc32cx w11, w11, x12
    umov    x12, v3.d[1]; crc32cx w11, w11, x12
    and     w13, w11, #0x3FFFFF
    lsl     x14, x13, #4
    str     q0, [x10, x14]
    sub     x1, x1, #64
    b       .process_block
.process_tail:
    cbz     x1, .done
    ldrb    w12, [x0], #1
    crc32cb w11, w11, w12
    sub     x1, x1, #1
    b       .process_tail
.done:
    mov     w0, w11
    ldp     x29, x30, [sp], #64
    ret

// ============================================================================
// 2. INJEÇÃO COM MICRO-ENTROPIA (DIFERENCIA ENTONAÇÃO)
// ============================================================================
vectra_entropy_inject:
    stp     x29, x30, [sp, #-64]!
    mov     x29, sp
    stp     d8, d9, [sp, #16]
    mrs     x3, cntvct_el0
    and     x4, x3, #0x1F
    adrp    x5, fractal_masks
    add     x5, x5, :lo12:fractal_masks
    ldr     q0, [x5, x4, lsl #4]
    mov     w6, #0xFFFFFFFF
    adrp    x7, torus_base
    add     x7, x7, :lo12:torus_base
    mov     x8, x0
    mov     x9, x1
.loop_simd:
    cmp     x9, #16
    b.lt    .rem
    ld1     {v1.16b}, [x8], #16
    eor     v1.16b, v1.16b, v0.16b
    umov    x10, v1.d[0]; crc32cx w6, w6, x10
    umov    x10, v1.d[1]; crc32cx w6, w6, x10
    sub     x9, x9, #16
    b       .loop_simd
.rem:
    cbz     x9, .collapse
    ldrb    w10, [x8], #1
    eor     w10, w10, w4
    crc32cb w6, w6, w10
    sub     x9, x9, #1
    b       .rem
.collapse:
    and     w6, w6, #0x3FFFFF
    lsl     x11, x6, #4
    str     q1, [x7, x11]
    mov     x0, x6
    ldp     d8, d9, [sp, #16]
    ldp     x29, x30, [sp], #64
    ret

// ============================================================================
// 3. RECONSTRUÇÃO DA FASE (ANTIDERIVADA)
// ============================================================================
exacordex_reconstruct_phase:
    adrp    x2, torus_base
    add     x2, x2, :lo12:torus_base
    and     w0, w0, #0x3FFFFF
    lsl     x3, x0, #4
    ldr     q0, [x2, x3]
    rev64   v1.16b, v0.16b
    eor     v0.16b, v0.16b, v1.16b
    str     q0, [x1]
    ret

// ============================================================================
// 4. BUSCA POR RESSONÂNCIA – VIZINHO MAIS PRÓXIMO (COM PRÉ‑FILTRO)
// ============================================================================
exacordex_search_nearest:
    stp     d8, d9, [sp, #-64]!
    stp     d10, d11, [sp, #16]
    stp     d12, d13, [sp, #32]
    stp     d14, d15, [sp, #48]
    ld1     {v0.16b}, [x0]
    mov     w2, #0x7FFFFFFF
    mov     w3, #0
    adrp    x4, torus_base
    add     x4, x4, :lo12:torus_base
    // PRÉ‑FILTRO: usa 8 bits do primeiro byte do vetor para saltar blocos
    ldrb    w12, [x0]               // byte 0 do vetor consulta
    and     w12, w12, #0xFF
    lsl     x12, x12, #12           // bloco de 4KB
    add     x5, x4, x12
    mov     w6, w12, lsr #4         // índice inicial correspondente
    mov     w7, #4194304
    sub     w7, w7, w6
1:
    cmp     w6, w7
    b.ge    4f
    ld1     {v1.16b, v2.16b, v3.16b, v4.16b}, [x5], #64
    // Cálculo das distâncias (SAD) para 4 slots
    uabd    v5.16b, v1.16b, v0.16b
    umull   v6.8h, v5.8b, v5.8b
    umull2  v7.8h, v5.16b, v5.16b
    add     v6.8h, v6.8h, v7.8h
    uaddlv  s8, v6.8h
    fmov    w8, s8
    // (repetir para v2, v3, v4 – código abreviado, mesmo padrão)
    // Atualização do melhor (apenas slot0 mostrado; expandir na prática)
    cmp     w8, w2
    b.ge    2f
    mov     w2, w8
    mov     w3, w6
2:
    add     w6, w6, #4
    b       1b
4:
    str     w3, [x1]
    fmov    s0, w2
    ldp     d14, d15, [sp, #48]
    ldp     d12, d13, [sp, #32]
    ldp     d10, d11, [sp, #16]
    ldp     d8, d9, [sp], #64
    ret

// ============================================================================
// 5. BUSCA K‑VIZINHOS (TOP 4 – SIMPLIFICADO)
// ============================================================================
exacordex_search_k_nearest:
    // Preserva registradores e vetor consulta (mesmo prólogo)
    // Mantém array de 4 distâncias e 4 índices
    // (implementação reduzida por brevidade – apenas esboço)
    ret

// ============================================================================
// 6. FUSÃO HARMÔNICA (MÉDIA VETORIAL + ROTAÇÃO)
// ============================================================================
exacordex_fuse:
    adrp    x3, torus_base
    add     x3, x3, :lo12:torus_base
    lsl     x4, x0, #4
    ldr     q0, [x3, x4]
    lsl     x5, x1, #4
    ldr     q1, [x3, x5]
    uaddl   v2.8h, v0.8b, v1.8b
    uaddl2  v3.8h, v0.16b, v1.16b
    shrn    v0.8b, v2.8h, #1
    shrn2   v0.16b, v3.8h, #1
    ext     v0.16b, v0.16b, v0.16b, #3
    lsl     x6, x2, #4
    str     q0, [x3, x6]
    ret

// ============================================================================
// 7. SÍNTESE DE ÁUDIO (VETOR COMO FORMA DE ONDA)
// ============================================================================
emit_cell_generic:
    adrp    x20, torus_base
    add     x20, x20, :lo12:torus_base
    lsl     x7, x0, #4
    ldr     q0, [x20, x7]
    // Para demonstração: imprime as primeiras 16 amostras (em vez de tocar áudio)
    mov     x1, #16
    adr     x2, msg_audio
    bl      printf
    ret

.section .rodata
msg_audio: .asciz "Sintetizando áudio a partir do vetor (primeiros 16 bytes): %016llx\n"

// ============================================================================
// FUNÇÃO AUXILIAR PARA TESTE (expor torus_base)
// ============================================================================
.global get_torus_base
get_torus_base:
    adrp    x0, torus_base
    add     x0, x0, :lo12:torus_base
    ret

EOF

# -----------------------------------------------------------------------------
# PROGRAMA DE TESTE EM C
# -----------------------------------------------------------------------------
cat > test_exacordex.c << 'EOF'
#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declarações das funções assembly
extern uint32_t exacordex_inject_massive(const void *word, size_t len, uint32_t seed);
extern void exacordex_reconstruct_phase(uint32_t index, void *dest);
extern void exacordex_fuse(uint32_t idx_a, uint32_t idx_b, uint32_t idx_dest);
extern uint32_t exacordex_search_nearest(const void *query, uint32_t *best_index);
extern void* get_torus_base(void);

// Função auxiliar para imprimir vetor de 16 bytes
void print_vector(const char *label, const uint8_t *vec) {
    printf("%s: ", label);
    for (int i = 0; i < 16; i++) printf("%02x ", vec[i]);
    printf("\n");
}

int main() {
    printf("=== EXACORDEX – TESTE INTEGRADO ===\n\n");

    // 1. Injetar duas palavras
    const char *word1 = "amor";
    const char *word2 = "amor";  // mesma palavra, mas será injetada em momentos diferentes
    uint32_t idx1 = exacordex_inject_massive(word1, strlen(word1), 0x12345678);
    uint32_t idx2 = exacordex_inject_massive(word2, strlen(word2), 0x87654321);
    printf("Injeção 1 (\"%s\") -> índice 0x%06X\n", word1, idx1);
    printf("Injeção 2 (\"%s\") -> índice 0x%06X\n", word2, idx2);

    // 2. Reconstruir a partir do índice
    uint8_t reconstructed[16] = {0};
    exacordex_reconstruct_phase(idx1, reconstructed);
    print_vector("Reconstruído (índice 0)", reconstructed);

    // 3. Busca por ressonância (vizinho mais próximo)
    uint32_t best_idx;
    uint32_t dist = exacordex_search_nearest(reconstructed, &best_idx);
    printf("Busca: vetor reconstruído -> melhor índice 0x%06X (distância %u)\n", best_idx, dist);

    // 4. Fusão harmônica entre os dois índices (se diferentes)
    if (idx1 != idx2) {
        uint32_t idx_fused = 0x3FFFFF; // um slot livre (último, por exemplo)
        exacordex_fuse(idx1, idx2, idx_fused);
        uint8_t fused_vec[16];
        exacordex_reconstruct_phase(idx_fused, fused_vec);
        print_vector("Fusão de amor + amor (com jitter)", fused_vec);
    } else {
        printf("Os índices são iguais (micro‑entropia não ativada).\n");
    }

    // 5. Mostrar endereço base do Toro (apenas curiosidade)
    void *base = get_torus_base();
    printf("Toro 7D base: %p (tamanho 64 MB)\n", base);

    printf("\nTeste concluído.\n");
    return 0;
}
EOF

# -----------------------------------------------------------------------------
# COMPILAÇÃO
# -----------------------------------------------------------------------------
echo "Compilando o código assembly e o programa de teste..."
gcc -O2 -Wall -g -o exacordex_test exacordex.S test_exacordex.c -lm

# -----------------------------------------------------------------------------
# EXECUÇÃO
# -----------------------------------------------------------------------------
echo "Executando o teste..."
./exacordex_test

# Limpeza opcional (descomente se quiser remover os arquivos após execução)
# rm -f exacordex.S test_exacordex.c exacordex_test
