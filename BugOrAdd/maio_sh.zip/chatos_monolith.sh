#!/data/data/com.termux/files/usr/bin/bash

set -e

echo "[ChatOS] generating monolith source..."

cat << 'ASM' > core.s
.global mk_scalar

mk_scalar:
    push {r4-r7, lr}
    mov r4, r0

loop:
    add r5, r5, #1
    eor r5, r5, r4
    mul r5, r5, r4
    subs r4, r4, #1
    bgt loop

    pop {r4-r7, pc}
ASM

cat << 'C' > bench.c
#include <stdio.h>
#include <time.h>

extern void mk_scalar(int);

double now(){
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(){
    double t0 = now();
    mk_scalar(20000000);
    double t1 = now();

    printf("{\"latency\": %.6f}\n", t1 - t0);
    return 0;
}
C

echo "[ChatOS] compiling..."

clang -O3 \
-mcpu=cortex-a7 \
-mfpu=neon \
-mfloat-abi=softfp \
-fno-pie -fno-pic \
bench.c core.s \
-o chato

echo "[ChatOS] running..."

./chato

