#!/bin/bash
# short.sh - Kernel Fotônico em Rust: dos pontos verbais até o Ω
# Sustentado pela base: Fibonacci truncada, Baguá, Estados Discretos.

PROJETO="omega_kernel"
echo ">> Criando projeto Rust: $PROJETO"
cargo new $PROJETO --bin --quiet
cd $PROJETO

# Cargo.toml mínimo
cat > Cargo.toml <<EOF
[package]
name = "omega_kernel"
version = "0.10.0"
edition = "2021"
EOF

# src/main.rs com a base completa
cat > src/main.rs <<'RUST'
use std::env;
use std::f64::consts::PI;

// ═══════════════════════════════════════════════
// BASE IMUTÁVEL DO KERNEL (aquilo que se sustenta)
// ═══════════════════════════════════════════════

const PHI: f64 = 1.618033988749895;
const TRUNC_FIB: [u32; 5] = [0, 0, 1, 2, 3]; // Fibonacci com atraso de fase
const FREQ_LONGA: f64 = 0.01;  // 0,01 Hz (heurística longa)
const FREQ_RAPIDA: f64 = 0.1;  // 0,1 Hz (recursiva rápida)

// 10 estados discretos do Kernel
#[derive(Clone, PartialEq, Debug)]
enum Estado {
    Repouso0,         // 0 - silêncio pré-ativo
    Repouso1,         // 1 - silêncio confirmatório
    Emissao,          // 2 - Γ (nasce)
    Esticamento,      // 3 - Redshift
    Encolhimento,     // 4 - Blueshift
    Colisao,          // 5 - σ (ponto crítico de segurança)
    Absorcao,         // 6 - α (morre/absorvido)
    ConversaoQuimica, // 7 - ativação de ativo μ_i
    SaltoBiologico,   // 8 - Ψ_bio (homeostase)
    RetornoAureo,     // 9 - Ω (fechamento)
}

// 8 portões do Baguá com operadores laterais
#[derive(Clone)]
enum Bagua {
    Qian, // ☰ Céu - derivada direta
    Kun,  // ☷ Terra - antiderivada
    Kan,  // ☵ Água - recursiva indireta
    Li,   // ☲ Fogo - inversa reversa
    Zhen, // ☳ Trovão - heurística de salto
    Xun,  // ☴ Vento - logarítmica
    Gen,  // ☶ Montanha - relativa reversa
    Dui,  // ☱ Lago - analítica indireta
}

impl Bagua {
    fn aplicar(&self, x: f64, dt: f64) -> f64 {
        match self {
            Bagua::Qian => x + dt,                      // derivada direta
            Bagua::Kun  => x * (1.0 + dt),              // antiderivada simples
            Bagua::Kan  => x * (1.0 + (dt * 0.5).sin()),// recursiva indireta
            Bagua::Li   => -x / (1.0 + dt.abs()),       // inversa reversa
            Bagua::Zhen => x + (x * dt).sqrt().copysign(x), // heurística de salto
            Bagua::Xun  => x * (1.0 + (x.abs()+1.0).ln() * dt * 0.1), // logarítmica
            Bagua::Gen  => x * (1.0 + (x.abs()/(x.abs()+PHI)) * dt), // relativa reversa
            Bagua::Dui  => x * (1.0 + (x*dt).tanh()),   // analítica indireta
        }
    }
}

// Estrutura do Fóton
#[derive(Clone)]
struct Foton {
    id: u64,
    energia: f64,          // frequência da luz
    estado: Estado,
    caminho: Vec<String>,  // log verbal da jornada
    portao_atual: Option<Bagua>,
    fase_temporal: f64,    // oscilador 0,01/0,1 Hz
}

impl Foton {
    fn novo(id: u64, energia: f64) -> Self {
        Foton {
            id,
            energia,
            estado: Estado::Repouso0,
            caminho: vec![format!("Fóton {} nasce com energia {:.3}", id, energia)],
            portao_atual: None,
            fase_temporal: 0.0,
        }
    }

    // Teste de ressonância áurea (base PHI)
    fn colisao_ressonante(&self) -> bool {
        let fib_index = (self.energia.abs() as u32) % 5;
        let fib_val = TRUNC_FIB[fib_index as usize] as f64;
        (self.energia / (fib_val + 1.0)).fract() < 1.0/PHI
    }
}

// ═══════════════════════════════════════════════
// MOTOR PRINCIPAL: processa um fóton até o Ω
// ═══════════════════════════════════════════════
fn processar_foton(mut f: Foton) {
    let dt: f64 = 0.1; // passo de simulação (0.1s)
    let max_passos = 50;

    for _ in 0..max_passos {
        match f.estado {
            Estado::Repouso0 => {
                f.caminho.push("Repouso0 (silêncio inicial)".into());
                f.estado = Estado::Repouso1;
            }
            Estado::Repouso1 => {
                f.caminho.push("Repouso1 (confirma silêncio)".into());
                f.estado = Estado::Emissao;
                f.fase_temporal = 0.0;
            }
            Estado::Emissao => {
                f.caminho.push("Emissão (Γ): fóton entra no Kernel".into());
                f.estado = Estado::Esticamento;
            }
            Estado::Esticamento => {
                // Efeito Doppler: redução de frequência (redshift)
                f.energia *= 1.0 - FREQ_RAPIDA * dt;
                f.caminho.push(format!("Esticamento: energia → {:.3}", f.energia));
                f.estado = Estado::Encolhimento;
            }
            Estado::Encolhimento => {
                // Blueshift: aumento de frequência
                f.energia *= 1.0 + FREQ_RAPIDA * dt;
                f.caminho.push(format!("Encolhimento: energia → {:.3}", f.energia));
                f.estado = Estado::Colisao;
            }
            Estado::Colisao => {
                f.caminho.push("Colisão (σ): TESTE DE SEGURANÇA...".into());
                if f.colisao_ressonante() {
                    f.caminho.push("   ✓ Ressonância Áurea — fóton APROVADO".into());
                    f.estado = Estado::Absorcao;
                } else {
                    f.caminho.push("   ✗ Fora de ressonância — DESCARTADO (purga)".into());
                    // Fim do fóton sem atingir Ω
                    imprimir_trajeto(&f, false);
                    return;
                }
            }
            Estado::Absorcao => {
                f.caminho.push("Absorção (α): energia transferida".into());
                f.estado = Estado::ConversaoQuimica;
            }
            Estado::ConversaoQuimica => {
                // Ativação de ativo μ_i (simulação com portão do Baguá)
                let escolha_portao = (f.energia as u32 % 8) as usize;
                let portoes = [
                    Bagua::Qian, Bagua::Kun, Bagua::Kan, Bagua::Li,
                    Bagua::Zhen, Bagua::Xun, Bagua::Gen, Bagua::Dui
                ];
                let portao = portoes[escolha_portao].clone();
                f.caminho.push(format!("Química (μ): ativando portão Baguá {:?}", escolha_portao));
                f.energia = portao.aplicar(f.energia, dt);
                f.portao_atual = Some(portao);
                f.estado = Estado::SaltoBiologico;
            }
            Estado::SaltoBiologico => {
                f.caminho.push(format!("Salto Biológico (Ψ_bio): homeostase, E={:.3}", f.energia));
                f.estado = Estado::RetornoAureo;
            }
            Estado::RetornoAureo => {
                f.caminho.push("Ω RETORNO ÁUREO ATINGIDO".into());
                f.caminho.push(format!("Energia final: {:.3} | Phi = {:.3}", f.energia, PHI));
                imprimir_trajeto(&f, true);
                return;
            }
        }
        f.fase_temporal += dt;
    }
    f.caminho.push("ERRO: não convergiu para Ω dentro do limite de passos".into());
    imprimir_trajeto(&f, false);
}

fn imprimir_trajeto(f: &Foton, sucesso: bool) {
    let status = if sucesso { "✅ SUCESSO" } else { "❌ FALHA" };
    println!("\n=== Jornada do Fóton {} {} ===", f.id, status);
    for passo in &f.caminho {
        println!("  {}", passo);
    }
    println!("==========================================\n");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() > 1 {
        // Modo verbal: cada argumento é um fóton com energia fornecida
        for (i, arg) in args[1..].iter().enumerate() {
            if let Ok(energia) = arg.parse::<f64>() {
                let foton = Foton::novo(i as u64, energia);
                println!("> Processando fóton {} com energia {}...", i, energia);
                processar_foton(foton);
            } else {
                eprintln!("Argumento inválido (não numérico): {}", arg);
            }
        }
    } else {
        // Modo default: demonstração com 3 fótons de diferentes pontos
        println!("Ω Kernel Fotônico Ω");
        println!("Rodando com exemplos da base...\n");
        let exemplos = vec![1.5, 2.0, 3.0, 0.618, 7.2];
        for (i, e) in exemplos.iter().enumerate() {
            let foton = Foton::novo(i as u64, *e);
            processar_foton(foton);
        }
    }
}
RUST

echo ">> Compilando e executando o Kernel..."
cargo run -- 1.5 2.0 0.618 3.0
