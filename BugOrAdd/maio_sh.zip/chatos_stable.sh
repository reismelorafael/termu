#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "[ChatOS] stable profiler ARMv7 starting..."

cat << 'C' > main.c
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define N 9

static inline double now(){
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

/* =========================
   SCALAR CORE (CPU ALU)
========================= */
int core_scalar(int n){
    volatile int x = 1, y = 3;

    for(int i=0;i<n;i++){
        x += y;
        x ^= (i * 31);
        y += x;
    }

    return x;
}

/* =========================
   ILP CORE (dependency-free ops)
========================= */
int core_ilp(int n){
    volatile int a=1,b=2,c=3,d=4;

    for(int i=0;i<n;i++){
        a += i;
        b += i;
        c += i;
        d += i;
    }

    return a+b+c+d;
}

/* =========================
   MEMORY STRIDE CORE (cache inference)
========================= */
#define SIZE 4096
volatile int buffer[SIZE];

int core_memory(int n){
    volatile int x = 0;

    for(int i=0;i<n;i++){
        x += buffer[(i * 1) & (SIZE-1)];
        x += buffer[(i * 16) & (SIZE-1)];
        x += buffer[(i * 128) & (SIZE-1)];
        x += buffer[(i * 512) & (SIZE-1)];
    }

    return x;
}

/* =========================
   BRANCH CORE (predictor stress)
========================= */
int core_branch(int n){
    volatile int x = 0;

    for(int i=0;i<n;i++){
        if((i & 1) == (x & 1))
            x += i;
        else
            x -= i;
    }

    return x;
}

/* =========================
   BENCH UTILS
========================= */
double run_int(int (*f)(int), int n){
    double t0 = now();
    f(n);
    double t1 = now();
    return t1 - t0;
}

/* =========================
   SIMPLE MEDIAN (4 samples)
========================= */
void sort(double *a){
    for(int i=0;i<4;i++){
        for(int j=i+1;j<4;j++){
            if(a[i] > a[j]){
                double t=a[i];
                a[i]=a[j];
                a[j]=t;
            }
        }
    }
}

double median(double *a){
    sort(a);
    return a[2];
}

int main(){

    int iters = 20000000;
    double t[4];

    /* warmup (important for cache stability) */
    for(int i=0;i<3;i++){
        core_scalar(1000000);
        core_ilp(1000000);
        core_memory(100000);
        core_branch(1000000);
    }

    t[0] = run_int(core_scalar, iters);
    t[1] = run_int(core_ilp, iters);
    t[2] = run_int(core_memory, 200000);
    t[3] = run_int(core_branch, iters);

    double med = median(t);

    printf("{\n");
    printf("  \"scalar\": %.6f,\n", t[0]);
    printf("  \"ilp\": %.6f,\n", t[1]);
    printf("  \"memory\": %.6f,\n", t[2]);
    printf("  \"branch\": %.6f,\n", t[3]);
    printf("  \"median_latency\": %.6f,\n", med);
    printf("  \"note\": \"inference model ARMv7 userland, not hardware counters\"\n");
    printf("}\n");

    return 0;
}
C

echo "[ChatOS] compiling stable build..."

clang -O3 \
-mcpu=cortex-a7 \
-fPIE -pie \
-fno-stack-protector \
main.c -o chato

echo "[ChatOS] running..."
./chato
