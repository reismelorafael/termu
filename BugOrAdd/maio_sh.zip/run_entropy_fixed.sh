#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=== RAFAELIA_ENTROPY_CORE (FIXED) ==="

# ==========================================
# 1. Assembly ARM32 corrigido (literal pool)
# ==========================================
cat << 'ASM' > core.s
.global core_run
.type core_run, %function

core_run:
    push {r4-r11, lr}

    mov r4, r0

    @ carregar constantes via literal pool (funciona sempre)
    ldr r5, =0x12345678
    ldr r6, =0x87654321
    ldr r7, =0xF00DBEEF
    ldr r8, =0x0BADCAFE
    ldr r9, =0xCAFEBABE
    ldr r10,=0xDEADBEEF
    ldr r11,=0x13579BDF
    ldr r12,=0x2468ACE0

loop:
    eor r5, r5, r5, lsl #13
    eor r5, r5, r5, lsr #17
    eor r5, r5, r5, lsl #5

    eor r6, r6, r6, lsl #11
    eor r6, r6, r6, lsr #19
    eor r6, r6, r6, lsl #3

    add r7, r7, r5
    eor r7, r7, r6
    mul r7, r7, r11

    add r8, r8, r6
    eor r8, r8, r5
    mul r8, r8, r12

    eor r9, r9, r7
    add r9, r9, r8
    mul r9, r9, r5

    eor r10, r10, r8
    add r10, r10, r7
    mul r10, r10, r6

    eor r11, r11, r9
    add r11, r11, r10

    eor r12, r12, r10
    add r12, r12, r9

    subs r4, r4, #1
    bgt loop

    pop {r4-r11, pc}
ASM

# ==========================================
# 2. Código C (medidas)
# ==========================================
cat << 'C' > main.c
#include <stdio.h>
#include <time.h>

extern void core_run(int);

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(void) {
    int iters = 10000000;  // 10M (rápido)
    double warm[3];

    for (int i = 0; i < 3; i++) {
        double t0 = now();
        core_run(2000000);
        double t1 = now();
        warm[i] = t1 - t0;
    }

    double t0 = now();
    core_run(iters);
    double t1 = now();

    double dt = t1 - t0;
    double ops = (double)iters * 30.0;   // instruções por iteração (aprox)
    double ops_sec = ops / dt;

    printf("\n=== RESULTADOS ===\n");
    printf("Tempo total: %.6f s\n", dt);
    printf("Instruções/s: %.2f M\n", ops_sec / 1e6);
    printf("Warmup: %.4f / %.4f / %.4f s\n", warm[0], warm[1], warm[2]);

    return 0;
}
C

# ==========================================
# 3. Compilação (compatível com Termux)
# ==========================================
echo "Compilando com gcc..."
gcc -O3 -march=armv7-a -o run_entropy main.c core.s -lm 2>/dev/null || \
gcc -O3 -o run_entropy main.c core.s -lm

if [ ! -f run_entropy ]; then
    echo "ERRO: falha na compilação."
    exit 1
fi

# ==========================================
# 4. Execução
# ==========================================
echo "Executando..."
./run_entropy

echo "Pronto."
