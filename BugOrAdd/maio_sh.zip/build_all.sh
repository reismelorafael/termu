#!/bin/sh
set -e
cd ~/_p/Gomp
make clean && make full && make test
