#!/data/data/com.termux/files/usr/bin/bash
set -e

mkdir -p raf && cd raf

# ===== tipos =====
cat > t.h << 'C'
typedef unsigned int u32;
typedef unsigned long long u64;
typedef int s32;
C

# ===== syscall + tempo =====
cat > sys.h << 'C'
#include "t.h"

static inline s32 sc3(s32 n, s32 a, s32 b, s32 c) {
    register s32 r0 asm("r0")=a;
    register s32 r1 asm("r1")=b;
    register s32 r2 asm("r2")=c;
    register s32 r7 asm("r7")=n;
    asm volatile("svc #0":"+r"(r0):"r"(r1),"r"(r2),"r"(r7));
    return r0;
}

static inline void puts(const char *s){
    u32 n=0; while(s[n])n++;
    sc3(4,1,(s32)s,n);
}

typedef struct { s64 sec,nsec; } TS;

static inline u64 now(){
    TS t;
    sc3(263,1,(s32)&t,0);
    return (u64)t.sec*1000000000ULL+t.nsec;
}
C

# ===== CRC32C =====
cat > crc.h << 'C'
#include "t.h"
static inline u32 crc(u32 c,u8 b){
    c^=b;
    for(int i=0;i<8;i++)
        c=(c>>1)^(0x82F63B78U&-(c&1));
    return c;
}
static u32 crc_buf(u8 *p,u32 n){
    u32 c=~0;
    for(u32 i=0;i<n;i++) c=crc(c,p[i]);
    return ~c;
}
C

# ===== FSM =====
cat > fsm.h << 'C'
#include "t.h"
typedef struct { u32 s; s32 l; } FSM;

static void step(FSM *f,u32 i){
    f->s=(f->s+i)&9;
    f->l+=((i*13)&255);
}
C

# ===== entry =====
cat > start.S << 'ASM'
.text
.global _start
_start:
    bl main
    mov r7,#1
    mov r0,#0
    svc #0
ASM

# ===== main =====
cat > main.c << 'C'
#include "sys.h"
#include "crc.h"
#include "fsm.h"

static unsigned char buf[4096];

static void putu(u64 v){
    char b[32]; int i=31; b[i]=0;
    if(!v){b[--i]='0';}
    while(v){b[--i]='0'+v%10; v/=10;}
    puts(b+i);
}

int main(){

    for(int i=0;i<4096;i++) buf[i]=i^0x5A;

    puts("RAFAELIA BENCH ARM32\n");

    /* CRC bench */
    u64 t0=now();
    u32 r=0;
    for(int i=0;i<200;i++) r=crc_buf(buf,4096);
    u64 t1=now();

    puts("CRC ns: ");
    putu(t1-t0);
    puts("\n");

    /* FSM bench */
    FSM f={0,0};
    t0=now();
    for(int i=0;i<500000;i++) step(&f,i);
    t1=now();

    puts("FSM ns: ");
    putu(t1-t0);
    puts("\n");

    puts("OK ΣΩΔΦ\n");
    return 0;
}
C

echo "[*] build"
gcc -O2 -nostdlib -ffreestanding \
    -march=armv7-a -mfpu=neon \
    start.S main.c -o bench

echo "[*] run"
./bench
