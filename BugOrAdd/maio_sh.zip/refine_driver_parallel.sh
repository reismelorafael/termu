#!/bin/sh
# refine_driver_parallel.sh
# Usage: ./refine_driver_parallel.sh [results_dir] [max_jobs]
# Example: ./refine_driver_parallel.sh dual_results 4

RESULTS_DIR=${1:-dual_results}
MAX_JOBS=${2:-4}
AGG_CSV="${RESULTS_DIR}/aggregate_by_cell.csv"
PLAN_CSV="${RESULTS_DIR}/refinement_plan.csv"
RUNS_CSV="${RESULTS_DIR}/refinement_runs.csv"
REF_DIR="${RESULTS_DIR}/refined_results"
BIN="./rafael_dual_loop"
POST_AGG="./post_aggregate"

# Refinement policy (tunable)
T_ZERO=0.02        # |mean lambda1| < T_ZERO -> critical
T_STD=0.02         # std > T_STD -> critical
MIN_SEEDS=16       # seeds to run in refinement
REF_TLEAP_MULT=2   # multiply T_LEAP by this factor in refinement
REF_EPS="1e-8"     # eps for refinement runs
REF_M=16           # m (number of tangent vectors) for refinement
SAVE_RDIAG=1       # save rdiag in refinement runs
ADAPT_FLAG=0       # if 1 schedule adapt runs too (paired)

# Execution flags
GENERATE_ONLY=0    # if 1 -> only generate plan, do not execute runs
VERBOSE=1

mkdir -p "$REF_DIR"

# Ensure aggregate exists (run post_aggregate if needed)
if [ ! -f "$AGG_CSV" ]; then
  echo "aggregate_by_cell.csv not found in ${RESULTS_DIR}. Running post_aggregate..."
  if [ -x "$POST_AGG" ]; then
    "$POST_AGG" "$RESULTS_DIR"
  else
    echo "post_aggregate binary not found or not executable. Attempting to compile if source exists..."
    if [ -f post_aggregate.c ]; then
      clang post_aggregate.c -O2 -lm -std=c99 -o post_aggregate
      echo "Compiled post_aggregate."
      ./post_aggregate "$RESULTS_DIR"
    else
      echo "post_aggregate.c not found. Please provide post_aggregate binary or source."
      exit 1
    fi
  fi
fi

# Build refinement plan: robust CSV parsing, clamp c/g >= 0
echo "c,g,n,lambda1_mean,lambda1_std,lambda1_ci95,reason" > "$PLAN_CSV"
tail -n +2 "$AGG_CSV" | while IFS=',' read -r c g n mean std ci95 rest; do
  # trim whitespace
  c=$(printf "%s" "$c" | tr -d '[:space:]')
  g=$(printf "%s" "$g" | tr -d '[:space:]')
  mean=$(printf "%s" "$mean" | tr -d '[:space:]')
  std=$(printf "%s" "$std" | tr -d '[:space:]')
  ci95=$(printf "%s" "$ci95" | tr -d '[:space:]')
  reason=""
  is_near_zero=$(awk -v v="$mean" -v tz="$T_ZERO" 'BEGIN{ if(v > -tz && v < tz) print 1; else print 0 }')
  is_high_std=$(awk -v s="$std" -v ts="$T_STD" 'BEGIN{ if(s > ts) print 1; else print 0 }')
  if [ "$is_near_zero" -eq 1 ]; then reason="${reason}near_zero;"; fi
  if [ "$is_high_std" -eq 1 ]; then reason="${reason}high_std;"; fi
  if [ -n "$reason" ]; then
    echo "${c},${g},${n},${mean},${std},${ci95},${reason}" >> "$PLAN_CSV"
  fi
done

if [ "$(wc -l < "$PLAN_CSV")" -le 1 ]; then
  echo "No critical cells detected by criteria (T_ZERO=${T_ZERO}, T_STD=${T_STD})."
  echo "Plan file: $PLAN_CSV"
  exit 0
fi

echo "Critical cells written to $PLAN_CSV"
[ "$VERBOSE" -eq 1 ] && sed -n '1,200p' "$PLAN_CSV"

# Create refinement runs list (clamped, 3x3 local grid)
echo "out_prefix,c,g,seed,eps,TLEAP,m,save_rdiag,adapt_flag" > "$RUNS_CSV"

# infer coarse T_LEAP from any meta file; fallback 800
COARSE_TLEAP=800
meta_sample=$(ls "${RESULTS_DIR}"/*_meta.txt 2>/dev/null | head -n1 || true)
if [ -n "$meta_sample" ]; then
  tval=$(grep -Eo 'T_LEAP=[0-9]+' "$meta_sample" | head -n1 | sed 's/T_LEAP=//')
  if [ -n "$tval" ]; then COARSE_TLEAP=$tval; fi
fi
REF_TLEAP=$(( COARSE_TLEAP * REF_TLEAP_MULT ))

# seeds for refinement
SEED_BASE=900
SEEDS=""
i=0
while [ $i -lt $MIN_SEEDS ]; do
  SEEDS="$SEEDS $((SEED_BASE + i))"
  i=$((i+1))
done

# Expand plan into runs (clamp c2,g2 >= 0)
tail -n +2 "$PLAN_CSV" | while IFS=',' read -r c g n mean std ci95 reason; do
  # ensure numeric format
  c0=$(awk -v x="$c" 'BEGIN{printf "%.6f", x+0}')
  g0=$(awk -v x="$g" 'BEGIN{printf "%.6f", x+0}')
  for dc in -0.02 0 0.02; do
    for dg in -0.01 0 0.01; do
      c2=$(awk -v x="$c0" -v d="$dc" 'BEGIN{v=x+d; if(v<0) v=0; printf "%.6f", v}')
      g2=$(awk -v x="$g0" -v d="$dg" 'BEGIN{v=x+d; if(v<0) v=0; printf "%.6f", v}')
      for s in $SEEDS; do
        prefix="${REF_DIR}/ref_c${c2}_g${g2}_s${s}"
        echo "${prefix},${c2},${g2},${s},${REF_EPS},${REF_TLEAP},${REF_M},${SAVE_RDIAG},0" >> "$RUNS_CSV"
        if [ "$ADAPT_FLAG" -eq 1 ]; then
          echo "${prefix}_adapt,${c2},${g2},${s},${REF_EPS},${REF_TLEAP},${REF_M},${SAVE_RDIAG},1" >> "$RUNS_CSV"
        fi
      done
    done
  done
done

echo "Refinement run list created: $RUNS_CSV"
[ "$VERBOSE" -eq 1 ] && echo "Total runs:" $(($(wc -l < "$RUNS_CSV") - 1))

if [ "$GENERATE_ONLY" -eq 1 ]; then
  echo "GENERATE_ONLY=1 -> not executing runs. Exiting."
  exit 0
fi

# Execute runs in parallel using xargs -P (portable)
# Prepare a small runner script to be invoked by xargs
RUNNER="${RESULTS_DIR}/.refine_runner.sh"
cat > "$RUNNER" <<'RUN'
#!/bin/sh
IFS=',' read -r out_prefix c g seed eps tleap m save_rdiag adapt_flag <<'EOF'
$1
EOF
# call engine
./rafael_dual_loop "$seed" "$out_prefix" "$c" "$g" "$eps" "$tleap" "$m" "$save_rdiag" "$adapt_flag"
RUN
chmod +x "$RUNNER"

# Use tail to skip header, then feed each CSV line to xargs which calls the runner
tail -n +2 "$RUNS_CSV" | \
  sed 's/\\/\\\\/g; s/"/\\"/g' | \
  xargs -I{} -n1 -P"$MAX_JOBS" sh -c "$RUNNER \"{}\"" 

echo "Refinement execution complete. Refined results in $REF_DIR"
echo "Aggregate refined results with:"
echo "  ./post_aggregate ${REF_DIR}"
