#!/bin/sh
set -e
# Compila
clang rafael_up_v2.c -O2 -lm -o rafael_up_v2
clang rafael_stats.c -O2 -lm -o rafael_stats

# Seeds para rodar (ajuste conforme necessário)
SEEDS="1001 2002 3003 4004 5005 6006 7007 8008"

OUTFILES=""
for s in $SEEDS; do
  out="rafael_timeseries_${s}.csv"
  echo "Running seed $s -> $out"
  ./rafael_up_v2 $s $out
  OUTFILES="$OUTFILES $out"
done

echo "All runs complete. Aggregating..."
./rafael_stats $OUTFILES
echo "Done. CSV files:"
ls -1 rafael_timeseries_*.csv || true
