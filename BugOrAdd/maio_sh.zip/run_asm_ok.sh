#!/data/data/com.termux/files/usr/bin/bash
for x in ./rafaelia_core_armv7 ./rafaelia_final ./rafaelia_b3 ./rafaelia_bench ./rafaelia_core_armv7_bench; do
  [ -x "$x" ] && echo "=== RUN $x ===" && "$x"
done
