#!/data/data/com.termux/files/usr/bin/bash
# ============================================================================
# VECTRA PULSE – Runtime Otimizado para Android ARM64
# Este script:
#   - Ajusta parâmetros do kernel (se root disponível) para desempenho máximo
#   - Compila o núcleo Vectra Pulse (assembly + C)
#   - Executa o binário em loop, exibindo coerência, entropia, estado e fase
#   - Mostra métricas de CPU e memória em tempo real
# ============================================================================

set -e  # Sai ao primeiro erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          VECTRA PULSE – RUNTIME OTIMIZADO                 ║${NC}"
echo -e "${CYAN}║          Android ARM64 | Termux                           ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ----------------------------------------------------------------------------
# 1. Verificar ambiente Termux
# ----------------------------------------------------------------------------
if [ -z "$PREFIX" ] || [ ! -d "/data/data/com.termux" ]; then
    echo -e "${RED}❌ Este script deve ser executado no Termux.${NC}"
    exit 1
fi

# ----------------------------------------------------------------------------
# 2. Verificar e instalar dependências
# ----------------------------------------------------------------------------
echo -e "${YELLOW}📦 Instalando dependências...${NC}"
pkg update -y
pkg install -y cmake ninja build-essential git wget unzip ndk-multilib termux-api procps bc

# ----------------------------------------------------------------------------
# 3. Verificar root e aplicar otimizações de kernel (se possível)
# ----------------------------------------------------------------------------
HAS_ROOT=0
if command -v su &> /dev/null && su -c "echo test" 2>/dev/null; then
    HAS_ROOT=1
    echo -e "${GREEN}✓ Root detectado. Aplicando otimizações de kernel...${NC}"
    
    # Ajusta governador de CPU para performance (se disponível)
    su -c "echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" 2>/dev/null && \
        echo -e "  → Governador CPU: performance" || echo -e "  ${YELLOW}⚠ Governador não alterado${NC}"
    
    # Desativa hotplug para manter todos os núcleos ativos
    for core in /sys/devices/system/cpu/cpu*/online; do
        su -c "echo 1 > $core" 2>/dev/null
    done
    
    # Ajusta escalonador de E/S para noop (menos overhead)
    if [ -e /sys/block/mmcblk0/queue/scheduler ]; then
        su -c "echo noop > /sys/block/mmcblk0/queue/scheduler" 2>/dev/null
        echo -e "  → Escalonador I/O: noop"
    fi
    
    # Aumenta limites de memória compartilhada
    su -c "sysctl -w kernel.shmmax=268435456" 2>/dev/null
    su -c "sysctl -w kernel.shmall=65536" 2>/dev/null
    
    # Prioridade de processos em tempo real
    su -c "echo -n 95 > /proc/sys/kernel/sched_rt_runtime_us" 2>/dev/null
    
    echo -e "${GREEN}✓ Otimizações aplicadas.${NC}"
else
    echo -e "${YELLOW}⚠ Root não disponível. Pulando otimizações de kernel.${NC}"
fi

# ----------------------------------------------------------------------------
# 4. Preparar diretório de trabalho
# ----------------------------------------------------------------------------
WORK_DIR="$HOME/vectra_runtime"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# ----------------------------------------------------------------------------
# 5. Criar arquivos fonte (assembly + C)
# ----------------------------------------------------------------------------
echo -e "${YELLOW}📝 Criando código-fonte...${NC}"

# Arquivo assembly (vectra_pulse.S)
cat > vectra_pulse.S << 'EOF'
    .section .text
    .global vectra_pulse_init
    .global vectra_pulse_step
    .global vectra_pulse_collapse
    .global vectra_pulse_get_state
    .global vectra_pulse_get_coherence
    .global vectra_pulse_get_entropy
    .global vectra_pulse_get_phase

    .equ    PERIOD, 42

    .section .bss
    .align 4
torus_cells:
    .space 1024 * 32
state_current:
    .space 4
coherence:
    .space 4
entropy:
    .space 4
phase:
    .space 4

    .text
vectra_pulse_init:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp
    mov     w1, #0x8000
    adr     x2, coherence
    str     w1, [x2]
    str     w1, [x2, #4]
    str     wzr, [x2, #8]
    str     wzr, [x2, #12]
    mov     w3, #0
    adr     x4, torus_cells
1:
    cmp     w3, #1024
    b.ge    2f
    eor     w5, w3, w0
    mul     w5, w5, #0x9E3779B9
    str     w5, [x4], #4
    str     w5, [x4], #4
    str     w5, [x4], #4
    str     w5, [x4], #4
    str     w5, [x4], #4
    str     w5, [x4], #4
    str     w5, [x4], #4
    add     w3, w3, #1
    b       1b
2:
    ldp     x29, x30, [sp], #16
    ret

vectra_pulse_step:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp
    adr     x0, coherence
    ldr     w1, [x0]
    ldr     w2, [x0, #4]
    ldr     w3, [x0, #8]
    mov     w4, #0x2000
    mov     w5, #0x1000
    mov     w6, #0xC000
    mul     w7, w1, w6
    lsr     w7, w7, #16
    mul     w8, w4, w3
    lsr     w8, w8, #16
    add     w1, w7, w8
    mul     w7, w2, w6
    lsr     w7, w7, #16
    mul     w8, w5, w3
    lsr     w8, w8, #16
    add     w2, w7, w8
    str     w1, [x0]
    str     w2, [x0, #4]
    cmp     w1, w2
    csel    w3, #2, #1, gt
    str     w3, [x0, #8]
    ldr     w4, [x0, #12]
    add     w4, w4, #1
    mov     w5, #PERIOD
    udiv    w6, w4, w5
    msub    w4, w6, w5, w4
    str     w4, [x0, #12]
    ldp     x29, x30, [sp], #16
    ret

vectra_pulse_collapse:
    // Simplificado: apenas retorna
    ret

vectra_pulse_get_state:
    adr     x0, state_current
    ldr     w0, [x0]
    ret

vectra_pulse_get_coherence:
    adr     x0, coherence
    ldr     w0, [x0]
    ret

vectra_pulse_get_entropy:
    adr     x0, entropy
    ldr     w0, [x0]
    ret

vectra_pulse_get_phase:
    adr     x0, phase
    ldr     w0, [x0]
    ret
EOF

# Arquivo main.c
cat > main.c << 'EOF'
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <time.h>

extern void vectra_pulse_init(uint64_t seed);
extern void vectra_pulse_step(void);
extern void vectra_pulse_collapse(void);
extern uint32_t vectra_pulse_get_state(void);
extern uint32_t vectra_pulse_get_coherence(void);
extern uint32_t vectra_pulse_get_entropy(void);
extern uint32_t vectra_pulse_get_phase(void);

const char* state_to_string(uint32_t s) {
    switch(s) {
        case 0: return "EDGE";
        case 1: return "FLOW";
        case 2: return "LOCK";
        case 3: return "META";
        default: return "UNKNOWN";
    }
}

float q16_to_float(uint32_t q) {
    return (float)q / 65536.0f;
}

int main() {
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║           VECTRA PULSE – EM EXECUÇÃO                      ║\n");
    printf("║           Coerência Dinâmica | Fase Viva                  ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    printf("\n");

    vectra_pulse_init(42);
    printf("✓ Inicializado com seed 42\n\n");

    int step = 0;
    while (1) {
        vectra_pulse_step();
        vectra_pulse_collapse();

        uint32_t state = vectra_pulse_get_state();
        uint32_t coherence = vectra_pulse_get_coherence();
        uint32_t entropy = vectra_pulse_get_entropy();
        uint32_t phase = vectra_pulse_get_phase();

        printf("\033[2J\033[H"); // limpa tela
        printf("╔══════════════════════════════════════════════════════════════════════╗\n");
        printf("║                         VECTRA PULSE RUNTIME                         ║\n");
        printf("╠══════════════════════════════════════════════════════════════════════╣\n");
        printf("║  Passo: %-3d    |    Fase: %-3d    |    Estado: %-10s      ║\n", step, phase, state_to_string(state));
        printf("╠──────────────────────────────────────────────────────────────────────╣\n");
        printf("║  Coerência: %-10.5f   |   Entropia: %-10.5f            ║\n",
               q16_to_float(coherence), q16_to_float(entropy));
        printf("╠──────────────────────────────────────────────────────────────────────╣\n");
        printf("║  Tensão Δ = |C - H| = %-10.5f                                   ║\n",
               q16_to_float(coherence > entropy ? coherence - entropy : entropy - coherence));
        printf("╚══════════════════════════════════════════════════════════════════════╝\n");
        printf("\n");
        printf("  ⚡ Δ > LIMIAR? ");
        if (coherence > entropy + 0x4000) {
            printf("SIM → COLAPSO EMERGENTE!\n");
        } else if (entropy > coherence + 0x4000) {
            printf("SIM → TENSÃO CRÍTICA!\n");
        } else {
            printf("NÃO → COERÊNCIA MANTIDA.\n");
        }
        printf("\n");
        printf("  Pressione Ctrl+C para sair.\n");
        printf("\n");

        // Mostra uso de CPU (top -n 1 | grep "CPU")
        printf("  🖥️  CPU: ");
        if (command -v top >/dev/null) {
            top -bn1 | grep "CPU" | head -1 | awk '{print $2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$10}'
        } else {
            echo "N/A";
        }

        step++;
        sleep(1);
    }

    return 0;
}
EOF

# Atualizar CMakeLists.txt para compilar assembly + C
cat > CMakeLists.txt << 'EOF'
cmake_minimum_required(VERSION 3.10)
project(vectra_pulse LANGUAGES C ASM)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)

add_executable(vectra_pulse vectra_pulse.S main.c)

target_compile_options(vectra_pulse PRIVATE -O2 -g)
target_link_options(vectra_pulse PRIVATE -static)
set_target_properties(vectra_pulse PROPERTIES LINKER_LANGUAGE C)
EOF

echo -e "${GREEN}✅ Arquivos fonte criados.${NC}"

# ----------------------------------------------------------------------------
# 6. Compilar com NDK
# ----------------------------------------------------------------------------
echo -e "${YELLOW}🔨 Compilando para Android ARM64...${NC}"

NDK_PATH="$PREFIX/lib/android-ndk"
if [ ! -d "$NDK_PATH" ]; then
    echo -e "${RED}❌ NDK não encontrado. Tentando baixar...${NC}"
    NDK_URL="https://dl.google.com/android/repository/android-ndk-r27c-linux.zip"
    cd "$PREFIX/tmp"
    wget -q --show-progress "$NDK_URL" -O ndk.zip
    unzip -q ndk.zip
    mv android-ndk-r27c "$NDK_PATH"
    rm ndk.zip
    echo -e "${GREEN}✓ NDK instalado.${NC}"
fi

TOOLCHAIN="$NDK_PATH/build/cmake/android.toolchain.cmake"
if [ ! -f "$TOOLCHAIN" ]; then
    echo -e "${RED}❌ Toolchain do NDK não encontrada. Abortando.${NC}"
    exit 1
fi

BUILD_DIR="$WORK_DIR/build"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

ABI="arm64-v8a"
API_LEVEL="21"

cmake -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN" \
      -DANDROID_ABI="$ABI" \
      -DANDROID_PLATFORM="android-$API_LEVEL" \
      -DCMAKE_BUILD_TYPE=Release \
      -G Ninja \
      ..

ninja

EXECUTABLE=$(find "$BUILD_DIR" -type f -name "vectra_pulse" -executable | head -n1)
if [ -z "$EXECUTABLE" ]; then
    echo -e "${RED}❌ Falha na compilação. Verifique os logs.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Compilação concluída. Executável: $EXECUTABLE${NC}"

# ----------------------------------------------------------------------------
# 7. Executar com visualização em tempo real
# ----------------------------------------------------------------------------
echo -e "${BLUE}🚀 Iniciando runtime...${NC}"
echo -e "${YELLOW}Para sair, pressione Ctrl+C${NC}"
echo ""

# Executa diretamente
"$EXECUTABLE"
