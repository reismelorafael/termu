#!/bin/bash

set -e

DIR="raf_build"
mkdir -p $DIR
cd $DIR

echo "[RAFAELIA] criando estrutura..."

cat > detect_arch.h << 'EOC'
#pragma once

#if defined(__aarch64__)
    #define RAF_ARM64 1
#elif defined(__arm__)
    #define RAF_ARM32 1
#else
    #error "Arquitetura não suportada"
#endif

EOC

cat > raf_entry.c << 'EOC'
#include <stdint.h>
#include "detect_arch.h"

// forward
void raf_bench_main(void);

#if RAF_ARM64
__attribute__((naked))
void _start(void){
    __asm__ volatile(
        "mov x29, #0\n"
        "mov x30, #0\n"
        "and sp, sp, #-16\n"
        "bl raf_bench_main\n"
        "mov x8, #93\n"
        "mov x0, #0\n"
        "svc #0\n"
    );
}
#endif

#if RAF_ARM32
__attribute__((naked))
void _start(void){
    __asm__ volatile(
        "mov r11, #0\n"
        "mov lr, #0\n"
        "bl raf_bench_main\n"
        "mov r7, #1\n"
        "mov r0, #0\n"
        "svc #0\n"
    );
}
#endif

EOC

cat > raf_core.c << 'EOC'
#include <stdint.h>
#include "detect_arch.h"

// ===============================
// HOT PATH CONFIG
// ===============================

static uint64_t g_state = 0xDEADBEEFCAFEBABEULL;

// ===============================
// CRITICAL HOT LOOP (CLEAN)
// ===============================

static inline uint64_t mix(uint64_t x){
    x ^= x >> 33;
    x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33;
    x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33;
    return x;
}

// ===============================
// ARCH-SPECIFIC TIMER
// ===============================

#if RAF_ARM64

static inline uint64_t now_cycles(){
    uint64_t v;
    __asm__ volatile("mrs %0, cntvct_el0" : "=r"(v));
    return v;
}

#elif RAF_ARM32

static inline uint64_t now_cycles(){
    uint32_t v;
    __asm__ volatile("mrc p15, 0, %0, c9, c13, 0" : "=r"(v));
    return (uint64_t)v;
}

#endif

// ===============================
// HOT ASM CRITICAL SECTION
// ===============================

#if RAF_ARM64

static inline uint64_t hot_step(uint64_t x){
    uint64_t out;
    __asm__ volatile(
        "eor x0, %1, %1, lsr #33\n"
        "mov x1, #0xff51afd7ed558ccd\n"
        "mul x0, x0, x1\n"
        "eor x0, x0, x0, lsr #33\n"
        "mov %0, x0\n"
        : "=r"(out)
        : "r"(x)
        : "x0","x1"
    );
    return out;
}

#elif RAF_ARM32

static inline uint32_t hot_step(uint32_t x){
    uint32_t out;
    __asm__ volatile(
        "eor r0, %1, %1, lsr #33\n"
        "ldr r1, =0xff51afd7\n"
        "mul r0, r0, r1\n"
        "eor r0, r0, r0, lsr #33\n"
        "mov %0, r0\n"
        : "=r"(out)
        : "r"(x)
        : "r0","r1"
    );
    return out;
}

#endif

// ===============================
// BENCH CORE
// ===============================

void raf_bench_main(void){

    uint64_t t0, t1;
    uint64_t acc = g_state;

    for(int i=0;i<100000;i++){
        t0 = now_cycles();
        acc = hot_step(acc);
        t1 = now_cycles();
    }

    g_state = acc;
}

EOC

cat > build.sh << 'EOC'
#!/bin/bash

set -e

ARCH=$(uname -m)

echo "[RAFAELIA] detected arch: $ARCH"

if [[ "$ARCH" == *"aarch64"* ]]; then

    echo "[ARM64 BUILD]"

    clang raf_entry.c raf_core.c \
        -O3 -flto -ffast-math \
        -nostdlib -ffreestanding \
        -march=armv8-a+crypto \
        -o raf_bench

elif [[ "$ARCH" == *"arm"* ]]; then

    echo "[ARM32 BUILD]"

    clang raf_entry.c raf_core.c \
        -O3 -ffast-math \
        -nostdlib -ffreestanding \
        -march=armv7-a \
        -o raf_bench

else
    echo "unsupported"
fi

echo "[OK] build complete"
EOC

chmod +x build.sh

echo "[RAFAELIA] ready."
