#!/data/data/com.termux/files/usr/bin/bash
set -e

# =========================
# CORE NEON OTIMIZADO (8-wide efetivo)
# =========================
cat << 'ASM' > core.s
.global core_run
.type core_run, %function

@ r0 = x
@ r1 = y
@ r2 = d
@ r3 = N
@ r4 = K

core_run:
    push {r4-r11, lr}

    mov r12, r3        @ salva N
    lsl r4, r4, #2     @ K em bytes

    mov r5, r0
    mov r6, r1
    mov r7, r2

    add r10, r0, r12, lsl #2
    add r11, r1, r12, lsl #2

    add r8, r5, r4
    add r9, r6, r4

loop:

    @ PREFETCH (mata gargalo de memória)
    pld [r5, #64]
    pld [r6, #64]
    pld [r8, #64]
    pld [r9, #64]

    @ LOAD 8 elementos (2x unroll)
    vld1.32 {q0}, [r5]!    
    vld1.32 {q1}, [r6]!    

    vld1.32 {q2}, [r8]!    
    vld1.32 {q3}, [r9]!    

    vsub.f32 q4, q2, q0
    vsub.f32 q5, q3, q1

    vmul.f32 q6, q4, q4
    vmla.f32 q6, q5, q5

    vld1.32 {q7}, [r7]
    vadd.f32 q7, q7, q6
    vst1.32 {q7}, [r7]!

    @ SEGUNDA ONDA (pipeline cheio)
    vld1.32 {q8}, [r5]!    
    vld1.32 {q9}, [r6]!    

    vld1.32 {q10}, [r8]!   
    vld1.32 {q11}, [r9]!   

    vsub.f32 q12, q10, q8
    vsub.f32 q13, q11, q9

    vmul.f32 q14, q12, q12
    vmla.f32 q14, q13, q13

    vld1.32 {q15}, [r7]
    vadd.f32 q15, q15, q14
    vst1.32 {q15}, [r7]!

wrap_x:
    cmp r8, r10
    blt wrap_y
    sub r8, r8, r12, lsl #2
    b wrap_x

wrap_y:
    cmp r9, r11
    blt next
    sub r9, r9, r12, lsl #2
    b wrap_y

next:
    subs r3, r3, #8
    bgt loop

    pop {r4-r11, pc}
ASM

# =========================
# MAIN (benchmark real)
# =========================
cat << 'C' > main.c
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

extern void core_run(float*, float*, float*, int, int);

#define N 48
#define RUNS 7

float x[N], y[N], d[N];

void gen() {
    float a = 1.0f, b = 0.0f;
    float ang = 0.13f;

    for(int i=0;i<N;i++){
        x[i] = a;
        y[i] = b;
        d[i] = 0.0f;

        float na = a - b*ang;
        float nb = a*ang + b;

        a = na;
        b = nb;
    }
}

double bench(int K){
    clock_t t0 = clock();

    for(int i=0;i<200000;i++)
        core_run(x,y,d,N,K);

    clock_t t1 = clock();

    return (double)(t1-t0)/CLOCKS_PER_SEC;
}

int cmp(const void *a, const void *b){
    double x = *(double*)a;
    double y = *(double*)b;
    return (x > y) - (x < y);
}

int main(int argc, char** argv){

    int K = 5;
    if(argc > 1) K = atoi(argv[1]);

    if(K >= N) K %= N;

    gen();

    // warmup
    for(int i=0;i<3;i++) bench(K);

    double r[RUNS];

    for(int i=0;i<RUNS;i++)
        r[i] = bench(K);

    qsort(r, RUNS, sizeof(double), cmp);

    double med = r[RUNS/2];
    double ops = (200000.0 * N) / med / 1e6;

    printf("MEDIAN: %.6f s\n", med);
    printf("OPS: %.2f M/s\n", ops);

    return 0;
}
C

# =========================
# BUILD
# =========================
clang -O3 -mfpu=neon -mfloat-abi=softfp main.c core.s -o run

echo ">>> RUN"
./run 5

