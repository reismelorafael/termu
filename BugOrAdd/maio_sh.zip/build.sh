#!/data/data/com.termux/files/usr/bin/bash
set -e

# ============================================================
# EXACORDEX — ESTRUTURA DE PROJETO ARM64
# Moto E7 Power | Termux | ΔRafaelVerboΩ
# Cole tudo de uma vez no bash
# ============================================================

ROOT="$HOME/exacordex"

# ── DIRETÓRIOS ──────────────────────────────────────────────
mkdir -p "$ROOT"/{src,bin,lib}
mkdir -p "$ROOT"/voynich/{todo,processed,done,data}
mkdir -p "$ROOT"/vectra/{todo,processed,done,src}
mkdir -p "$ROOT"/rafaelia/{todo,processed,done,src}
mkdir -p "$ROOT"/logs
mkdir -p "$ROOT"/build

echo "✓ Estrutura criada em $ROOT"
find "$ROOT" -type d | sort | sed 's|'"$ROOT"'|.|'

# ── ARQUIVO DE CONFIGURAÇÃO ──────────────────────────────────
cat > "$ROOT"/config.env << 'ENV'
CC=gcc
CFLAGS="-O2 -Wall -march=armv8-a"
LDFLAGS="-lm"
PERIOD=42
Q16=65536
SPIRAL_Q16=56756
ENV

# ── MAKEFILE RAIZ ───────────────────────────────────────────
cat > "$ROOT"/Makefile << 'MAKE'
CC      ?= gcc
CFLAGS  ?= -O2 -Wall -march=armv8-a -lm
BIN      = bin
SRC      = src

all: $(BIN)/bitomega $(BIN)/vectra_fix $(BIN)/voynich_toro

$(BIN)/bitomega: $(SRC)/bitomega.c
	@mkdir -p $(BIN)
	$(CC) $(CFLAGS) $< -o $@
	@echo "✓ bitomega compilado"

$(BIN)/vectra_fix: $(SRC)/vectra_fix.c
	@mkdir -p $(BIN)
	$(CC) $(CFLAGS) $< -o $@
	@echo "✓ vectra_fix compilado"

$(BIN)/voynich_toro: $(SRC)/voynich_toro.c
	@mkdir -p $(BIN)
	$(CC) $(CFLAGS) $< -o $@
	@echo "✓ voynich_toro compilado"

run-bitomega: $(BIN)/bitomega
	./$(BIN)/bitomega | tee logs/bitomega.log

run-vectra: $(BIN)/vectra_fix
	./$(BIN)/vectra_fix | tee logs/vectra.log

run-voynich: $(BIN)/voynich_toro
	./$(BIN)/voynich_toro | tee logs/voynich.log

run-all: run-bitomega run-vectra run-voynich

clean:
	rm -f $(BIN)/*

.PHONY: all run-bitomega run-vectra run-voynich run-all clean
MAKE

# ── SRC: bitomega.c ─────────────────────────────────────────
cat > "$ROOT"/src/bitomega.c << 'C'
/* bitomega.c — AutomatoQ16.16 ARM64 */
#include <stdio.h>
#include <stdint.h>
#include <math.h>

#define PERIOD   42
#define Q16      65536
#define SPIRAL   56756u   /* floor(sqrt(3)/2 * Q16) */
#define ALPHA    16384u   /* 0.25 em Q16 */
#define STATES   10

typedef struct {
    uint32_t C;   /* coerência Q16.16  */
    uint32_t H;   /* entropia  Q16.16  */
    uint8_t  q;   /* estado 0-9        */
    uint32_t phi; /* fase mod 42       */
} BitOmega;

static uint32_t ema(uint32_t cur, uint32_t in) {
    /* C_{t+1} = 0.75*cur + 0.25*in  (Q16 aritmética) */
    uint64_t a = (uint64_t)cur * 49152u; /* 0.75 * Q16 */
    uint64_t b = (uint64_t)in  * ALPHA;
    return (uint32_t)((a + b) >> 16);
}

static void step(BitOmega *s, uint32_t input) {
    uint32_t Cin = (input & 0xF) * (Q16 / 15);
    uint32_t Hin = ((input >> 4) & 0xF) * (Q16 / 15);
    s->C   = ema(s->C, Cin);
    s->H   = ema(s->H, Hin);
    s->q   = (s->q + (s->C ^ s->H ^ input)) % STATES;
    s->phi = (s->phi + 1) % PERIOD;
}

static const char *state_name(uint8_t q) {
    static const char *names[] = {
        "NEG","ZERO","POS","MIX","VOID",
        "EDGE","FLOW","LOCK","NOISE","META"
    };
    return names[q % STATES];
}

int main(void) {
    BitOmega s = { .C=Q16/2, .H=Q16/2, .q=5, .phi=0 };
    uint32_t attractor_visits[PERIOD] = {0};

    printf("=== BITOMEGA Q16.16 | PERIOD=%d | ARM64 ===\n\n", PERIOD);
    printf("%-4s %-6s %-6s %-6s %-8s %-5s\n",
           "phi","C","H","Delta","state","q");
    printf("%-4s %-6s %-6s %-6s %-8s %-5s\n",
           "---","-----","-----","-----","-------","--");

    for (int i = 0; i < PERIOD * 3; i++) {
        uint32_t input = (uint32_t)(i * 0x9E3779B9u) & 0xFF;
        step(&s, input);
        attractor_visits[s.phi]++;

        uint32_t delta = s.C > s.H ? s.C - s.H : s.H - s.C;
        printf("%-4u %-6.4f %-6.4f %-6.4f %-8s %-5u\n",
               s.phi,
               (double)s.C / Q16,
               (double)s.H / Q16,
               (double)delta / Q16,
               state_name(s.q),
               s.q);
    }

    printf("\n=== ATRATORES VISITADOS (periodo 42) ===\n");
    int unique = 0;
    for (int i = 0; i < PERIOD; i++) {
        if (attractor_visits[i] > 0) {
            printf("  phi=%02d visits=%u\n", i, attractor_visits[i]);
            unique++;
        }
    }
    printf("Total atratores ativos: %d / %d\n", unique, PERIOD);
    return 0;
}
C

# ── SRC: vectra_fix.c ───────────────────────────────────────
cat > "$ROOT"/src/vectra_fix.c << 'C'
/* vectra_fix.c — 5 modos: Fib-Rafael, Toro, BitOmega, phi_ethica, Link */
#include <stdio.h>
#include <stdint.h>
#include <math.h>

#define PERIOD  42
#define Q16     65536.0
#define SPIRAL  (sqrt(3.0)/2.0)   /* 0.866025 */
#define SIN279  (-sin(81.0*M_PI/180.0))

/* ── Modo 1: Fibonacci-Rafael ─────────────────────────────── */
void mode_fib(void) {
    printf("\n=== MODO 1: FIBONACCI-RAFAEL (periodo=%d) ===\n", PERIOD);
    double F = 1.0;
    for (int n = 0; n < PERIOD; n++) {
        double F_next = F * SPIRAL + fabs(M_PI * SIN279);
        printf("  n=%02d F=%.6f\n", n, F);
        F = F_next;
    }
    printf("  Periodo: %d ciclos completados\n", PERIOD);
}

/* ── Modo 2: Toro ─────────────────────────────────────────── */
void mode_toro(void) {
    printf("\n=== MODO 2: TORO 7D (snapshot) ===\n");
    double coords[7];
    double seed = 42.0;
    for (int i = 0; i < 7; i++) {
        coords[i] = fmod(seed * SPIRAL * (i+1), 1.0);
        seed = coords[i];
    }
    const char *names[] = {"u","v","psi","chi","rho","delta","sigma"};
    for (int i = 0; i < 7; i++)
        printf("  %5s = %.6f\n", names[i], coords[i]);
}

/* ── Modo 3: BitOmega simplificado ───────────────────────── */
void mode_bitomega(void) {
    printf("\n=== MODO 3: BITOMEGA (10 estados) ===\n");
    double C = 0.5, H = 0.5;
    int q = 5, phi = 0;
    for (int i = 0; i < PERIOD; i++) {
        double Cin = fmod((i+1)*SPIRAL, 1.0);
        double Hin = fmod((i+1)*fabs(SIN279), 1.0);
        C = 0.75*C + 0.25*Cin;
        H = 0.75*H + 0.25*Hin;
        q = (q + (int)(C*10) + (int)(H*10)) % 10;
        phi = (phi+1) % PERIOD;
        if (i % 7 == 0)
            printf("  phi=%02d C=%.4f H=%.4f q=%d\n", phi,C,H,q);
    }
}

/* ── Modo 4: phi_ethica ──────────────────────────────────── */
void mode_phi(void) {
    printf("\n=== MODO 4: PHI_ETHICA (Lyapunov) ===\n");
    double C = 0.5, H = 0.5;
    for (int i = 0; i < PERIOD; i++) {
        double phi_e = (1.0 - H) * C;  /* min(entropia)=max(coerencia) */
        double E_verbo = SPIRAL;
        double R = C * phi_e * E_verbo;
        C = 0.75*C + 0.25*R;
        if (phi_e > 0.3)
            printf("  i=%02d phi_e=%.4f C=%.4f R=%.4f\n", i, phi_e, C, R);
    }
}

/* ── Modo 5: Linking topológico ──────────────────────────── */
void mode_link(void) {
    printf("\n=== MODO 5: LINKING (numero de enlace) ===\n");
    int link = 0;
    for (int i = 0; i < PERIOD; i++) {
        double theta = 2.0*M_PI*i/PERIOD;
        double cross = cos(theta)*sin(theta+SPIRAL) - sin(theta)*cos(theta+SPIRAL);
        if (cross > 0) link++;
    }
    printf("  Cruzamentos positivos: %d / %d\n", link, PERIOD);
    printf("  Numero de enlace: %d\n", link - PERIOD/2);
}

int main(void) {
    printf("╔═══════════════════════════════════╗\n");
    printf("║  VECTRA FIX | ARM64 | PERIOD=42  ║\n");
    printf("╚═══════════════════════════════════╝\n");
    mode_fib();
    mode_toro();
    mode_bitomega();
    mode_phi();
    mode_link();
    printf("\n✓ Todos os modos concluídos.\n");
    return 0;
}
C

# ── SRC: voynich_toro.c ─────────────────────────────────────
cat > "$ROOT"/src/voynich_toro.c << 'C'
/* voynich_toro.c — Navegação toroidal no espaço de famílias EVA */
#include <stdio.h>
#include <string.h>
#include <math.h>

#define TORUS   10
#define PERIOD  42
#define N_FAM   12

static const char *families[] = {
    "ch","qo","sh","ok","ot","da",
    "ol","ai","yk","op","ct","ar"
};
static const int support[] = {
    5854,5230,3175,2423,2362,2259,
    1594, 788, 588, 350, 508, 505
};

/* strides das 4 sequências toroidais */
static const int strides[4][3] = {
    {1,2,3},    /* 123   */
    {0,1,2,3},  /* 0123  */
    {0,1,1,2,3},/* 01123 */
    {0,0,0,1,1,2,3} /* 0001123 */
};
static const char *seq_names[] = {"123","0123","01123","0001123"};

static double toro_distance(int a, int b) {
    int d = abs(a - b) % TORUS;
    return d > TORUS/2 ? TORUS - d : d;
}

int main(void) {
    printf("╔════════════════════════════════════════╗\n");
    printf("║  VOYNICH TORO | %d famílias | T=%d    ║\n", N_FAM, TORUS);
    printf("╚════════════════════════════════════════╝\n\n");

    /* Mapeia famílias no toro por suporte normalizado */
    printf("=== MAPEAMENTO TOROIDAL DAS FAMÍLIAS ===\n");
    printf("%-6s %-8s %-6s %-6s\n","fam","support","pos_x","pos_y");
    int max_sup = support[0];
    for (int i = 0; i < N_FAM; i++) {
        double norm = (double)support[i] / max_sup;
        int px = (int)(norm * (TORUS-1));
        int py = (int)(fmod(norm * PERIOD, TORUS));
        printf("%-6s %-8d %-6d %-6d\n", families[i], support[i], px, py);
    }

    /* Percurso por cada sequência */
    printf("\n=== PERCURSOS TOROIDAIS ===\n");
    for (int s = 0; s < 4; s++) {
        printf("\nSequência %s:\n", seq_names[s]);
        int stride_len = s == 0 ? 3 : (s == 1 ? 4 : (s == 2 ? 5 : 7));
        int pos = 0;
        double total_dist = 0;
        for (int step = 0; step < PERIOD; step++) {
            int st = strides[s][step % stride_len];
            int next = (pos + st) % N_FAM;
            double d = toro_distance(pos % TORUS, next % TORUS);
            total_dist += d;
            if (step < 8)
                printf("  step%02d: %s -> %s (d=%.1f)\n",
                    step, families[pos % N_FAM], families[next], d);
            pos = next;
        }
        printf("  ... distancia total em %d passos: %.1f\n", PERIOD, total_dist);
        printf("  familia final: %s\n", families[pos % N_FAM]);
    }

    /* Invariante geometrica */
    printf("\n=== INVARIANTE GEOMETRICA ===\n");
    double spiral = sqrt(3.0)/2.0;
    double invariant = 0;
    for (int i = 0; i < N_FAM; i++) {
        double norm = (double)support[i] / max_sup;
        invariant += norm * pow(spiral, i % PERIOD);
    }
    printf("  I = sum(norm_i * spiral^i) = %.6f\n", invariant);
    printf("  SPIRAL = %.6f = sqrt(3)/2\n", spiral);
    printf("  Periodo confirmado: %d\n", PERIOD);
    return 0;
}
C

# ── SCRIPT DE COMPILAÇÃO E RUN ───────────────────────────────
cat > "$ROOT"/build.sh << 'SH'
#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="$HOME/exacordex"
cd "$ROOT"
echo "=== COMPILANDO ARM64 ==="
gcc -O2 -Wall -march=armv8-a src/bitomega.c    -lm -o bin/bitomega    && echo "✓ bitomega"
gcc -O2 -Wall -march=armv8-a src/vectra_fix.c  -lm -o bin/vectra_fix  && echo "✓ vectra_fix"
gcc -O2 -Wall -march=armv8-a src/voynich_toro.c -lm -o bin/voynich_toro && echo "✓ voynich_toro"
echo ""
echo "=== EXECUTANDO ==="
echo "--- bitomega ---"   && ./bin/bitomega    | tee logs/bitomega.log
echo "--- vectra_fix ---" && ./bin/vectra_fix  | tee logs/vectra.log
echo "--- voynich ---"    && ./bin/voynich_toro | tee logs/voynich.log
echo ""
echo "✓ Logs em $ROOT/logs/"
SH
chmod +x "$ROOT"/build.sh

# ── SCRIPT DE WORKFLOW (todo/done/processed) ─────────────────
cat > "$ROOT"/workflow.sh << 'SH'
#!/data/data/com.termux/files/usr/bin/bash
# Mover arquivos entre estados do pipeline
ROOT="$HOME/exacordex"
cmd="$1"; file="$2"; project="${3:-voynich}"

case "$cmd" in
  todo)
    cp "$file" "$ROOT/$project/todo/"
    echo "→ todo: $file"
    ;;
  process)
    mv "$ROOT/$project/todo/$file" "$ROOT/$project/processed/"
    echo "→ processed: $file"
    ;;
  done)
    mv "$ROOT/$project/processed/$file" "$ROOT/$project/done/"
    echo "→ done: $file"
    ;;
  status)
    echo "=== STATUS $project ==="
    echo "TODO:      $(ls $ROOT/$project/todo/ | wc -l) arquivos"
    echo "PROCESSED: $(ls $ROOT/$project/processed/ | wc -l) arquivos"
    echo "DONE:      $(ls $ROOT/$project/done/ | wc -l) arquivos"
    ;;
  *)
    echo "uso: workflow.sh [todo|process|done|status] arquivo projeto"
    ;;
esac
SH
chmod +x "$ROOT"/workflow.sh

# ── README ───────────────────────────────────────────────────
cat > "$ROOT"/README.md << 'MD'
# EXACORDEX — ARM64 Moto E7 Power

## Compilar e rodar tudo
    bash build.sh

## Compilar individual
    make bin/bitomega
    make bin/vectra_fix
    make bin/voynich_toro

## Workflow de arquivos
    bash workflow.sh todo   arquivo.csv voynich
    bash workflow.sh status            voynich

## Estrutura
    src/          codigo fonte C
    bin/          binarios compilados ARM64
    voynich/      todo/ processed/ done/ data/
    vectra/       todo/ processed/ done/ src/
    rafaelia/     todo/ processed/ done/ src/
    logs/         saidas de execucao
    build/        artefatos cmake

## Periodo: 42 | Q16.16 | SPIRAL=sqrt(3)/2
MD

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ESTRUTURA CRIADA — PRONTO PARA COMPILAR ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "  cd $ROOT && bash build.sh"

cd ~/exacordex && bash build.sh

Compila os três binários ARM64 e roda tudo com log. O workflow de `todo/processed/done` funciona com `bash workflow.sh status voynich`.
