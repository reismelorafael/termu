#!/data/data/com.termux/files/usr/bin/bash
set -e

mkdir -p raf_hotfix && cd raf_hotfix

# ===== memset próprio (evita libc) =====
cat > raf_mem.h << 'C'
#pragma once
static inline void raf_memset(void *p, int v, unsigned int n) {
    unsigned char *c = (unsigned char*)p;
    for(unsigned int i=0;i<n;i++) c[i]=(unsigned char)v;
}
C

# ===== tipos =====
cat > raf_types.h << 'C'
#pragma once
typedef unsigned int u32;
typedef unsigned long long u64;
typedef int s32;
typedef long long s64;
typedef s32 q16_t;

#define Q16_ONE 65536
#define Q16_HALF 32768
#define Q16_SQRT3_2 56756
#define Q16_NEG_LN_S (-9430)
C

# ===== syscalls =====
cat > raf_sys.h << 'C'
#pragma once
#include "raf_types.h"

static inline void write_str(const char *s) {
    register u32 r0 asm("r0") = 1;
    register const char *r1 asm("r1") = s;
    register u32 r2 asm("r2") = 0;
    while(s[r2]) r2++;
    register u32 r7 asm("r7") = 4;
    asm volatile("svc #0" : : "r"(r0),"r"(r1),"r"(r2),"r"(r7));
}

static inline void exit0() {
    register u32 r0 asm("r0") = 0;
    register u32 r7 asm("r7") = 1;
    asm volatile("svc #0" : : "r"(r0),"r"(r7));
}
C

# ===== FSM corrigido =====
cat > raf_fsm.h << 'C'
#pragma once
#include "raf_types.h"
#include "raf_mem.h"

typedef struct {
    u32 state;
    q16_t lambda;
} FSMState;

static inline void fsm_init(FSMState *f) {
    raf_memset(f,0,sizeof(*f));
    f->lambda = Q16_NEG_LN_S;
}

static inline void fsm_step(FSMState *f, u32 i) {
    f->state = (f->state + (i&3)) % 10;
    f->lambda += (q16_t)((i*13)&0xFF);
}
C

# ===== entry =====
cat > start.S << 'ASM'
.text
.global _start
_start:
    bl main
    mov r7, #1
    mov r0, #0
    svc #0
ASM

# ===== main =====
cat > main.c << 'C'
#include "raf_sys.h"
#include "raf_fsm.h"

int main() {
    write_str("RAFAELIA ENTERPRISE ARM32 OK\n");

    FSMState f;
    fsm_init(&f);

    for(unsigned int i=0;i<1000;i++) {
        fsm_step(&f,i);
    }

    write_str("FSM OK\n");
    write_str("ΣΩΔΦ ativo\n");

    exit0();
    return 0;
}
C

echo "[*] Compilando..."
gcc -O2 -nostdlib -ffreestanding \
    -march=armv7-a \
    -mfpu=neon \
    start.S main.c \
    -o raf_exec

echo "[*] Rodando..."
./raf_exec
