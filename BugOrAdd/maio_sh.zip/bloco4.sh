# ═══════════════════════════════════════════════════
# BLOCO 4 — TERMUX-API + SENSORES (completo)
# Entrada para o vetor T^7 da DSL RafaelOS
# ═══════════════════════════════════════════════════

source "$HOME/PEDRA_ANGULAR/.env"

echo "── Instalando dependências Python (se necessário)..."
pip install --quiet numpy 2>/dev/null || true

# ── Script sensor 7D: transforma leituras em vetor ────
cat > "$PA/sensors/proc/sensor_to_7d.py" << 'EOF'
#!/usr/bin/env python3
import sys, json, os, math
from datetime import datetime

DIM = 7
# Pesos para as 7 dimensões: [batt, acc_x, acc_y, acc_z, gyro_x, gyro_y, gyro_z]
# Podem ser calibrados depois
W = [0.5, 0.2, 0.2, 0.2, 0.1, 0.1, 0.1]

def normalize(v, min_v, max_v):
    if max_v - min_v == 0:
        return 0.0
    return 2.0 * (v - min_v) / (max_v - min_v) - 1.0  # [-1, 1]

def main():
    out_dir = os.getenv("PA") + "/sensors/raw"
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    timestamp = datetime.utcnow().isoformat() + "Z"
    vector = [0.0] * DIM

    # 1. Bateria (porcentagem -> escala -1..1)
    try:
        batt = json.loads(os.popen("termux-battery-status").read())
        pct = batt.get("percentage", 50)
        vector[0] = normalize(pct, 0, 100)
    except:
        vector[0] = 0.0

    # 2-4. Acelerômetro (últimos valores médios)
    try:
        acc = json.loads(os.popen("termux-sensor -s accelerometer -n 3").read())
        vals = acc.get("accelerometer", {}).get("values", [])
        if len(vals) >= 3:
            avg_x = sum(v[0] for v in vals) / len(vals)
            avg_y = sum(v[1] for v in vals) / len(vals)
            avg_z = sum(v[2] for v in vals) / len(vals)
            vector[1] = normalize(avg_x, -10, 10)
            vector[2] = normalize(avg_y, -10, 10)
            vector[3] = normalize(avg_z, -10, 10)
    except:
        pass

    # 5-7. Giroscópio (se disponível)
    try:
        gyr = json.loads(os.popen("termux-sensor -s gyroscope -n 3").read())
        gvals = gyr.get("gyroscope", {}).get("values", [])
        if len(gvals) >= 3:
            avg_gx = sum(v[0] for v in gvals) / len(gvals)
            avg_gy = sum(v[1] for v in gvals) / len(gvals)
            avg_gz = sum(v[2] for v in gvals) / len(gvals)
            vector[4] = normalize(avg_gx, -5, 5)
            vector[5] = normalize(avg_gy, -5, 5)
            vector[6] = normalize(avg_gz, -5, 5)
    except:
        pass

    # Aplicar pesos
    weighted = [vector[i] * W[i] for i in range(DIM)]

    # Salvar estado atual em JSON
    state = {
        "timestamp": timestamp,
        "raw": vector,
        "weighted": weighted,
        "battery_level": pct,
    }
    with open(os.getenv("PA") + "/sensors/raw/state_7d.json", "w") as f:
        json.dump(state, f)

    # Imprimir na saída padrão para o orquestrador
    print(json.dumps(weighted))

if __name__ == "__main__":
    main()
EOF

chmod +x "$PA/sensors/proc/sensor_to_7d.py"

# ── Script de teste rápido ────────────────────────────
cat > "$PA/scripts/test_7d.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
source "$HOME/PEDRA_ANGULAR/.env"
echo "Coletando estado 7D..."
python3 "$PA/sensors/proc/sensor_to_7d.py"
echo "Arquivo salvo em $PA/sensors/raw/state_7d.json"
EOF
chmod +x "$PA/scripts/test_7d.sh"

echo "── Executando teste do sensor 7D..."
"$PA/scripts/test_7d.sh"

echo ""
echo "════════════════════════════════════"
echo "✓ BLOCO 4 — Sensores 7D concluído"
echo "  Alimentador: $PA/sensors/proc/sensor_to_7d.py"
echo "  Estado     : $PA/sensors/raw/state_7d.json"
echo "════════════════════════════════════"
