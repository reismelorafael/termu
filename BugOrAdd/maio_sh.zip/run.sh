#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "[*] Criando ambiente..."
mkdir -p raf_hotfix && cd raf_hotfix

# ASM entry
cat > start.S << 'ASM'
.text
.global _start
_start:
    bl main
    mov r7, #1
    mov r0, #0
    svc #0
ASM

# C core
cat > main.c << 'C'
typedef unsigned int u32;

/* syscall write */
static inline void write_str(const char *s) {
    register u32 r0 asm("r0") = 1;
    register const char *r1 asm("r1") = s;
    register u32 r2 asm("r2") = 0;
    while(s[r2]) r2++;
    register u32 r7 asm("r7") = 4;
    asm volatile("svc #0" : : "r"(r0),"r"(r1),"r"(r2),"r"(r7));
}

static inline void exit0() {
    register u32 r0 asm("r0") = 0;
    register u32 r7 asm("r7") = 1;
    asm volatile("svc #0" : : "r"(r0),"r"(r7));
}

int main() {
    write_str("RAFAELIA ARM32 OK\n");
    write_str("ΣΩΔΦ ativo\n");
    exit0();
    return 0;
}
C

echo "[*] Compilando..."
gcc -O2 -nostdlib -ffreestanding \
    -march=armv7-a \
    -mfpu=neon \
    -mfloat-abi=softfp \
    start.S main.c \
    -o raf_exec

echo "[*] Executando..."
./raf_exec
