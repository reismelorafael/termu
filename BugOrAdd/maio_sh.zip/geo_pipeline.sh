#!/bin/sh

set -e

WORK=~/geo_pipeline
mkdir -p $WORK
cd $WORK

echo "== [1] GERANDO ASM CORE =="

cat > core.s <<'ASM'
.global _start

.data
state: .word 0

.text

_start:
    bl loop

loop:
    bl tick
    b loop

tick:
    ldr r0, =state
    ldr r1, [r0]

    @ feedback coerente (dinâmica não linear)
    add r2, r1, r1, lsl #1
    eor r2, r2, r1, lsr #3
    add r2, r2, #11

    str r2, [r0]
    bx lr
ASM

echo "== [2] COMPILANDO =="

as -o core.o core.s
ld -o core core.o

echo "== [3] EXECUTANDO (CTRL+C para parar) =="

./core
