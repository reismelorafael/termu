#!/data/data/com.termux/files/usr/bin/bash
set -e

# =========================
# ASM CORE (REGISTER-ONLY PIPELINE)
# =========================
cat << 'ASM' > core.s
.global core_run
.type core_run, %function

@ r0 = iterations

core_run:
    push {r4-r11, lr}

    mov r4, r0

    @ inicializa registradores (sem memória)
    vmov.f32 q0, #1.0
    vmov.f32 q1, #2.0
    vmov.f32 q2, #3.0
    vmov.f32 q3, #4.0

loop:

    @ 4 pipelines independentes
    vadd.f32 q0, q0, q1
    vmul.f32 q1, q1, q2

    vadd.f32 q2, q2, q3
    vmul.f32 q3, q3, q0

    vsub.f32 q0, q0, q2
    vmla.f32 q1, q3, q2

    vsub.f32 q2, q2, q1
    vmla.f32 q3, q0, q1

    subs r4, r4, #1
    bgt loop

    pop {r4-r11, pc}
ASM

# =========================
# MAIN (BENCH LIMPO)
# =========================
cat << 'C' > main.c
#include <stdio.h>
#include <time.h>

extern void core_run(int);

static double now(){
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

int main(){

    int iters = 200000000; // alto pra saturar pipeline

    // warmup
    for(int i=0;i<3;i++)
        core_run(10000000);

    double t0 = now();

    core_run(iters);

    double t1 = now();

    double dt = t1 - t0;

    double ops_per_iter = 8.0; // 8 instruções vetoriais
    double total_ops = iters * ops_per_iter * 4.0; // 4 lanes por q-reg

    double ops_sec = total_ops / dt;

    printf("TIME: %.6f s\n", dt);
    printf("OPS/sec: %.2f M\n", ops_sec / 1e6);

    // estimativa de ciclos (aproximação)
    double cpu_ghz = 1.8; // ajuste pro teu device
    double cycles = dt * cpu_ghz * 1e9;
    double cycles_per_iter = cycles / iters;

    printf("CYCLES/ITER: %.2f\n", cycles_per_iter);

    return 0;
}
C

# =========================
# BUILD OTIMIZADO
# =========================
clang -O3 \
-mcpu=cortex-a7 \
-mfpu=neon \
-mfloat-abi=softfp \
-ffast-math \
-fno-math-errno \
-fno-trapping-math \
-fomit-frame-pointer \
main.c core.s -o run

echo ">>> RUN"
./run

