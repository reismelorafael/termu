#!/bin/sh
set -e
clang rafael_complex.c -O2 -lm -std=c99 -o rafael_complex
clang rafael_stats.c -O2 -lm -std=c99 -o rafael_stats

# Seeds (ajuste conforme CPU/memória)
SEEDS="101 202 303 404 505 606 707 808"

OUTFILES=""
for s in $SEEDS; do
  out="rafael_complex_${s}.csv"
  echo "Running seed $s -> $out"
  ./rafael_complex $s $out
  OUTFILES="$OUTFILES $out"
done

echo "All runs complete. Aggregating..."
./rafael_stats $OUTFILES
echo "Done. CSV files:"
ls -1 rafael_complex_*.csv || true
