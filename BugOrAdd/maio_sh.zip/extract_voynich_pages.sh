#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# extract_voynich_pages.sh
# Extrai todas as páginas do PDF do Voynich como imagens JPEG
# e organiza em ~/voynich_data/images/
# ============================================================

set -e

echo "📦 Instalando dependências (poppler, imagemagick)..."
pkg update -y
pkg install -y poppler imagemagick

echo "📁 Criando diretório de destino..."
mkdir -p ~/voynich_data/images

echo "🖼️ Extraindo imagens do PDF (método pdfimages)..."
cd ~/storage/downloads
# pdfimages extrai todas as imagens brutas do PDF
pdfimages -j Voynich-Manuscript.pdf ~/voynich_data/images/page

echo "🔁 Renomeando arquivos para o padrão voynich_XXX.jpg..."
cd ~/voynich_data/images
count=1
for f in page-*.jpg; do
    if [ -f "$f" ]; then
        newname=$(printf "voynich_%03d.jpg" $count)
        mv "$f" "$newname"
        echo "  $f -> $newname"
        ((count++))
    fi
done

# Fallback: se não encontrou arquivos .jpg, tenta .ppm
if [ $count -eq 1 ]; then
    echo "⚠️ Nenhum arquivo .jpg encontrado. Tentando converter .ppm para .jpg..."
    for f in page-*.ppm; do
        if [ -f "$f" ]; then
            newname=$(printf "voynich_%03d.jpg" $count)
            convert "$f" "$newname"
            rm "$f"
            echo "  $f -> $newname"
            ((count++))
        fi
    done
fi

total=$((count-1))
echo "✅ Extraídas $total imagens."

if [ $total -eq 0 ]; then
    echo "❌ Falha na extração com pdfimages. Tentando método alternativo (convert)..."
    cd ~/storage/downloads
    convert -density 150 "Voynich-Manuscript.pdf" -quality 90 ~/voynich_data/images/voynich_%03d.jpg
    total=$(ls ~/voynich_data/images/voynich_*.jpg 2>/dev/null | wc -l)
    echo "✅ Extraídas $total imagens com convert."
fi

# (Opcional) Converter para RGB padrão (evita cores estranhas)
echo "🎨 Convertendo imagens para espaço de cores sRGB..."
for f in ~/voynich_data/images/voynich_*.jpg; do
    convert "$f" -colorspace sRGB "$f"
done

echo "📊 Resumo final:"
ls -la ~/voynich_data/images/voynich_*.jpg | head -5
echo "..."
echo "Total: $(ls ~/voynich_data/images/voynich_*.jpg 2>/dev/null | wc -l) imagens."

echo "✅ Pronto! As imagens estão em ~/voynich_data/images/"
echo "Agora você pode executar o programa 'voynich_toroidal' para navegar no toro."
