#!/data/data/com.termux/files/usr/bin/bash
set -e

# =========================
# ASM CORE (NEON REAL)
# =========================
cat << 'ASM' > core.s
.global core_run
.type core_run, %function

@ r0 = x
@ r1 = y
@ r2 = d
@ r3 = N
@ r4 = K

core_run:
    push {r4-r8, lr}

    mov r5, #0

loop:

    add r6, r5, r4
    cmp r6, r3
    subge r6, r6, r3

    add r7, r0, r5, lsl #2
    vldr s0, [r7]
    add r7, r1, r5, lsl #2
    vldr s1, [r7]

    add r7, r0, r6, lsl #2
    vldr s2, [r7]
    add r7, r1, r6, lsl #2
    vldr s3, [r7]

    vsub.f32 s4, s2, s0
    vsub.f32 s5, s3, s1

    vmul.f32 s6, s4, s4
    vmla.f32 s6, s5, s5   @ dx² + dy²

    add r7, r2, r5, lsl #2
    vldr s7, [r7]
    vadd.f32 s7, s7, s6
    vstr s7, [r7]

    add r5, r5, #1
    cmp r5, r3
    blt loop

    pop {r4-r8, pc}
ASM

# =========================
# MAIN C (CLI + SVG + PPM)
# =========================
cat << 'C' > main.c
#include <stdio.h>
#include <math.h>
#include <time.h>

extern void core_run(float*, float*, float*, int, int);

#define N 42
#define IMG 512

float x[N], y[N], d[N];

void gen() {
    for(int i=0;i<N;i++){
        float t = 2.0f * 3.14159265f * i / N;
        x[i] = cosf(t);
        y[i] = sinf(t);
        d[i] = 0;
    }
}

void svg() {
    FILE *f = fopen("out.svg","w");
    fprintf(f,"<svg xmlns='http://www.w3.org/2000/svg' width='512' height='512'>\n");

    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            int a = 256 + x[i]*200;
            int b = 256 + y[i]*200;
            int c = 256 + x[j]*200;
            int d = 256 + y[j]*200;
            fprintf(f,"<line x1='%d' y1='%d' x2='%d' y2='%d' stroke='cyan' stroke-opacity='0.02'/>\n",a,b,c,d);
        }
    }

    for(int i=0;i<N;i++){
        int px = 256 + x[i]*200;
        int py = 256 + y[i]*200;
        fprintf(f,"<circle cx='%d' cy='%d' r='2' fill='red'/>\n",px,py);
    }

    fprintf(f,"</svg>");
    fclose(f);
}

void ppm() {
    FILE *f = fopen("out.ppm","w");
    fprintf(f,"P3\n%d %d\n255\n",IMG,IMG);

    for(int y=0;y<IMG;y++){
        for(int x=0;x<IMG;x++){
            int v = (x*y) ^ (x<<2);
            v &= 255;
            fprintf(f,"%d %d %d ",v,v,v);
        }
        fprintf(f,"\n");
    }

    fclose(f);
}

int main(int argc, char** argv){

    int K = 5;
    if(argc > 1) K = atoi(argv[1]);

    gen();

    clock_t t0 = clock();

    for(int i=0;i<200000;i++)
        core_run(x,y,d,N,K);

    clock_t t1 = clock();

    double dt = (double)(t1-t0)/CLOCKS_PER_SEC;

    printf("TIME: %.6f s\n",dt);
    printf("OPS: %.2f M/s\n",(200000.0*N)/dt/1e6);

    svg();
    ppm();

    return 0;
}
C

# =========================
# BUILD
# =========================
clang -O3 -mfpu=neon -mfloat-abi=softfp main.c core.s -o run

echo ">>> RUN"
./run 5

