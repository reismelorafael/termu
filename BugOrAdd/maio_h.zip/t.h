typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef signed int s32;
typedef signed long long s64;
